#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
"""Build the PUB03B Resgate Aéreo TAP from the source package, without a ROM."""
from argparse import ArgumentParser
from hashlib import sha256
from pathlib import Path, PurePosixPath
import json
import os
import shutil
import struct
import subprocess
import sys
import zlib

PACKAGE = Path(__file__).resolve().parents[1]
RESOURCES = {
    "fb": (1, 24582, 256, 192), "heli": (2, 18438, 192, 192),
    "tiles": (3, 18438, 192, 192), "map": (4, 768, None, None),
    "combat": (5, 16902, 192, 176), "wait": (6, 768, None, None),
    "rope": (7, 1158, 36, 64),
}
INCBIN = {
    "heli": "heli_composite.rle", "tiles": "tiles_1.bitmap.rle",
    "combat": "pub03_combat.rle", "rope": "rope_candidate.rle",
}
AUX_START = 0x5e00
PROGRAM_START = 0x7b00


def digest(b):
    return sha256(b).hexdigest()


def save(path, b):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("xb") as f:
        f.write(b)


def decode(data):
    out, i = bytearray(), 0
    while i < len(data):
        t = data[i]
        n = (t & 127) + 1
        if t & 128:
            out.extend(bytes([data[i + 1]]) * n)
            i += 2
        else:
            assert i + n + 1 <= len(data)
            out.extend(data[i + 1:i + n + 1])
            i += n + 1
    return bytes(out)


def cut_rle(stream, limit):
    i = 0
    while i < len(stream):
        size = 2 if stream[i] & 128 else stream[i] + 2
        if i + size > limit:
            break
        i += size
    return i


def blocks(data):
    i, out = 0, []
    while i < len(data):
        size = int.from_bytes(data[i:i+2], "little")
        block = data[i+2:i+2+size]
        assert len(block) == size and size > 2
        checksum = 0
        for b in block:
            checksum ^= b
        assert checksum == 0
        out.append(block)
        i += 2 + size
    assert len(out) == 6 and [v[0] for v in out] == [0,255,0,255,0,255]
    return out


def main():
    p = ArgumentParser(description=__doc__)
    p.add_argument("--assembler", required=True, type=Path)
    p.add_argument("--out", required=True, type=Path, help="New build directory")
    args = p.parse_args()
    out = args.out.resolve()
    out.mkdir(exist_ok=False)
    want = json.loads((PACKAGE / "BUILD-IDENTITIES.json").read_text(encoding="utf-8"))
    events = []
    env = dict(os.environ, PYTHONUTF8="1", PYTHONDONTWRITEBYTECODE="1")

    def run(command, cwd, name):
        cmd = list(map(str, command))
        task = subprocess.run(cmd, cwd=cwd, capture_output=True, env=env)
        log = task.stdout + task.stderr
        save(out / "logs" / (name + ".log"), log)
        events.append({"argv": cmd, "exit": task.returncode, "log": f"logs/{name}.log"})
        if task.returncode:
            raise RuntimeError(log.decode("utf-8", errors="replace"))

    generator = PACKAGE / "tools/new_art.py"
    assert digest(generator.read_bytes()) == want["new_art_sha256"]
    generated = out / "generated"
    run([sys.executable,generator,generated], out, "art")
    assert {p.name for p in generated.iterdir()} == set(want["generated_assets"])
    for name, dg in want["generated_assets"].items():
        assert digest((generated / name).read_bytes()) == dg, name
    streams, lengths, crcs = {}, {}, {}
    for name, (handle,length,w,h) in RESOURCES.items():
        raw=(generated/f"{name}.raw").read_bytes()
        streams[name]=(generated/f"{name}.rle").read_bytes()
        assert len(raw)==length and decode(streams[name])==raw
        if w:
            assert struct.unpack("<BBHH",raw[:6])==(1,1,w,h)
        else:
            assert max(raw)<144
        crc=f"{zlib.crc32(raw):08x}"
        assert want["resource_crc32"][name]==crc
        lengths[name]=length
        crcs[name]=crc
    prefix=streams["fb"]+streams["map"]+streams["wait"]
    limit=min(420,0x6800-AUX_START-len(prefix))
    assert limit>0
    pos=cut_rle(streams["combat"],limit)
    aux=prefix + streams["combat"][:pos]
    assert 0<len(aux)<=0x6800-AUX_START and digest(aux)==want["aux_sha256"]
    for key, name in INCBIN.items():
        data=streams[key][pos:] if key=="combat" else streams[key]
        save(out/"assets"/name,data)
    for relative,hash in want["sources"].items():
        name=PurePosixPath(relative)
        assert not name.is_absolute() and ".." not in name.parts and name.parts[0]=="src"
        b=(PACKAGE / relative).read_bytes()
        assert digest(b)==hash
        save(out/relative,b)
    assert not list(out.rglob("*.rom"))
    main_bin=out/"build/resgate_ra05e.bin"
    main_bin.parent.mkdir()
    aux_bin=main_bin.parent/"pub03b_aux.bin"
    save(aux_bin,aux)
    run([args.assembler.resolve(),f"--raw={main_bin}","rope_rescue_candidate.asm"], out/"src", "sjasmplus")
    run([sys.executable,PACKAGE/"tools/make_loaders_sdk.py",main_bin,"0x7b00"], out, "code-tap")
    run([sys.executable,PACKAGE/"tools/make_walk_tap.py",main_bin.with_suffix(".tap"),aux_bin,"0x5e00","0x7b00"], out, "autorun-tap")
    tap=main_bin.with_name("resgate_ra05e_autorun.tap")
    raw=tap.read_bytes()
    b=blocks(raw)
    assert b[3][1:-1]==aux and b[5][1:-1]==main_bin.read_bytes()
    assert struct.unpack("<HH",b[2][12:16])==(len(aux),AUX_START)
    assert struct.unpack("<HH",b[4][12:16])==(main_bin.stat().st_size,PROGRAM_START)
    assert len(raw)==want["tap_bytes"] and digest(raw)==want["tap_sha256"]
    report = {"tap": "build/resgate_ra05e_autorun.tap", "tap_sha256":digest(raw),
              "bytes":len(raw), "block_lengths":[len(v) for v in b],
              "assets":lengths,"resource_crc32":crcs,
              "original_assembler_sha256":digest(args.assembler.resolve().read_bytes()),
              "commands":events, "rom_input":False}
    save(out/"BUILD_RECEIPT.json",(json.dumps(report,indent=2)+"\n").encode())
    print(f"TAP {len(raw)} bytes sha256 {digest(raw)}")


if __name__ == "__main__":
    main()
