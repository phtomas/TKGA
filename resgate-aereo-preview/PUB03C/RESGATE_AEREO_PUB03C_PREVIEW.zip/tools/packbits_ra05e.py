"""PackBits encoder copied from historic RA05E tools/build_rope_candidate.py."""
def encode(data):
    size = len(data)
    cost = [0]*(size+1)
    choice = [0]*size
    for i in range(size-1,-1,-1):
        limit = min(128,size-i)
        count = min(range(1,limit+1), key=lambda n: n+cost[i+n])
        best = 1+count+cost[i+count]
        run = 1
        while run < limit and data[i+run] == data[i]:
            run += 1
        for n in range(2,run+1):
            if 2+cost[i+n] < best:
                best, count = 2+cost[i+n], -n
        cost[i], choice[i] = best, count
    packed = bytearray()
    i = 0
    while i < size:
        n = choice[i]
        if n < 0:
            packed.extend((127-n,data[i]))
        else:
            packed.append(n-1)
            packed.extend(data[i:i+n])
        i += abs(n)
    return bytes(packed)
