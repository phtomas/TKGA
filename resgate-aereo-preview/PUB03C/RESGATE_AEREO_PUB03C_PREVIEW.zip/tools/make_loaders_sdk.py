"""Build a fresh 48K SNA and CODE TAP from a binary ORG 0x8000. Python 3, no dependencies."""
from pathlib import Path
import struct,sys
p=Path(sys.argv[1]);code=p.read_bytes();origin=int(sys.argv[2],0) if len(sys.argv)>2 else 0x8000
assert 0x7b00<=origin and origin+len(code)<=0x10000
ram=bytearray(49152);ram[origin-0x4000:origin-0x4000+len(code)]=code
header=bytearray(27);header[23:25]=struct.pack('<H',0x7ffd);header[25]=1
sp=origin-3
header[23:25]=struct.pack('<H',sp)
ram[sp-0x4000:sp-0x4000+2]=struct.pack('<H',origin)
p.with_suffix('.sna').write_bytes(header+ram)
def block(data):
 checksum=0
 for byte in data:checksum^=byte
 return struct.pack('<H',len(data)+1)+data+bytes([checksum])
name=p.stem[:10].ljust(10).encode('ascii')
head=bytes([0,3])+name+struct.pack('<HHH',len(code),origin,0x8000)
p.with_suffix('.tap').write_bytes(block(head)+block(bytes([255])+code))
