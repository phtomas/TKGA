"""BASIC -> auxiliary CODE at5E00 -> main CODE at8000, through ordinary ROM."""
from pathlib import Path
import struct,sys,functools,operator
R=Path(__file__).resolve().parents[1];p=Path(sys.argv[1])
def block(b):return struct.pack('<H',len(b)+1)+b+bytes([functools.reduce(operator.xor,b,0)])
def number(n):return str(n).encode()+b'\x0e\x00\x00'+struct.pack('<H',n)+b'\x00'
load=b'\xef""\xaf'
origin=int(sys.argv[4],0) if len(sys.argv)>4 else 0x8000
body=b'\xfd'+number(origin-1)+b':'+load+b':'+load+b':\xf9\xc0'+number(origin)+b'\r'
line=struct.pack('>H',10)+struct.pack('<H',len(body))+body
address=int(sys.argv[3],0) if len(sys.argv)>3 else 0x5e00
assert 0x5ccb+len(line)<address
header=b'\x00\x00RA05C BOOT'+struct.pack('<HHH',len(line),10,len(line))
aux=(Path(sys.argv[2]) if len(sys.argv)>2 else R/'build/walk_aux.bin').read_bytes()
assert address+len(aux)<=0x6800
aux_header=b'\0\3RA05C AUX '+struct.pack('<HHH',len(aux),address,0x8000)
assert len(header)==len(aux_header)==18
out=p.with_name(p.stem+'_autorun.tap');out.write_bytes(block(header)+block(b'\xff'+line)+block(aux_header)+block(b'\xff'+aux)+p.read_bytes())
print(out,len(out.read_bytes()))
