"""Original indexed art drawn from the Resgate gameplay geometry for PUB03B.

The only project code dependencies are the PUB03 glyph table and PackBits encoder.
No reference image, pixel dump, ROM, or previous atlas is read by this module.
"""
from pathlib import Path
import json
import struct
import sys
from PIL import Image, ImageDraw
from packbits_ra05e import encode
from pub03_hud_font import glyph

PALETTE = [
    "000000", "111827", "202d49", "344667", "586889", "f3f2df",
    "c5d8da", "adede1", "4eb3aa", "245965", "f9b95a", "d47742",
    "a64f52", "693f50", "39434f", "121f33",
]
COLORS = [v for rgb in PALETTE for v in bytes.fromhex(rgb)]


def canvas(width, height, background=0):
    im = Image.new("P", (width, height), background)
    im.putpalette(COLORS + [0] * (768 - len(COLORS)))
    return im


def letters(im, x, y, label, color=5):
    pixels = im.load()
    for column, char in enumerate(label):
        for row, mask in enumerate(glyph(char)):
            for bit in range(8):
                if mask & (128 >> bit):
                    pixels[x + 8 * column + bit, y + row] = color


def person(im, x, y, direction, step):
    d = ImageDraw.Draw(im)
    d.rectangle((x + 7, y + 2, x + 14, y + 7), fill=10)
    d.rectangle((x + 8, y + 5, x + 13, y + 10), fill=6)
    d.rectangle((x + 6, y + 11, x + 15, y + 19), fill=7)
    d.rectangle((x + 8, y + 12, x + 13, y + 21), fill=8)
    d.line([(x + 13, y + 13), (x + 13 + 3 * direction, y + 17)], fill=5, width=2)
    foot_y = y + 25
    d.line([(x + 9, y + 20), (x + (5 if step else 9), foot_y)], fill=6, width=2)
    d.line([(x + 13, y + 20), (x + (17 if step else 13), foot_y)], fill=6, width=2)


def helicopter(orientation, phase, damaged=False):
    im = canvas(64, 64)
    d = ImageDraw.Draw(im)
    if orientation == 2:
        d.polygon([(13, 37), (18, 30), (45, 30), (50, 37), (47, 48),
                   (37, 52), (26, 52), (16, 48)], fill=12)
        d.polygon([(20, 34), (43, 34), (47, 42), (39, 46), (24, 46),
                   (17, 42)], fill=9)
        for x in (21, 34):
            d.rectangle((x, 35, x + 8, 39), fill=7)
        d.line([(32, 34), (32, 44)], fill=5)
        d.line([(16, 51), (47, 51)], fill=11, width=2)
    else:
        body_offset = 3 if orientation in (1, 3) else 0
        d.polygon([(9, 38), (18, 40), (25, 32), (46 + body_offset, 32),
                   (54, 38), (53, 48), (45, 51), (26, 51), (17, 45),
                   (9, 44)], fill=12)
        d.polygon([(34, 34), (45 + body_offset, 34), (51, 40), (45, 44),
                   (33, 44)], fill=8)
        d.line([(36, 35), (44, 35)], fill=7, width=2)
        d.line([(8, 37), (8, 44)], fill=10, width=2)
        d.line([(23, 47), (50, 47)], fill=11, width=2)
        if orientation < 2:
            im = im.transpose(Image.Transpose.FLIP_LEFT_RIGHT)
            d = ImageDraw.Draw(im)
    d.line([(23, 52), (20, 58), (17, 58), (46, 58)], fill=5, width=2)
    d.line([(41, 52), (44, 58)], fill=6, width=2)
    d.line([(32, 26), (32, 32)], fill=6, width=2)
    d.line([(6 if phase else 1, 25), (57 if phase else 62, 25)], fill=6, width=2)
    d.point([(32, 49), (34, 49)], fill=10)
    if damaged:
        d.polygon([(38, 29), (41, 20), (44, 24), (48, 19),
                   (46, 28), (51, 31)], fill=11)
    return im


def helicopter_atlas():
    atlas = canvas(192, 192)
    for i, (heading, phase, damaged) in enumerate([
        (0, 0, False), (0, 1, False), (1, 0, False),
        (2, 0, False), (2, 1, False), (3, 0, False),
        (4, 0, False), (4, 1, False), (2, 0, True),
    ]):
        atlas.paste(helicopter(heading, phase, damaged), (64 * (i % 3), 64 * (i // 3)))
    return atlas


def combat_atlas():
    im = canvas(192, 176)
    d = ImageDraw.Draw(im)
    d.rounded_rectangle((7, 44, 57, 59), radius=5, fill=14)
    d.rectangle((14, 43, 49, 51), fill=9)
    d.polygon([(17, 43), (27, 36), (40, 36), (46, 43)], fill=8)
    d.rectangle((39, 37, 61, 39), fill=6)
    for x in range(13, 55, 9):
        d.rectangle((x, 53, x + 4, 56), fill=6)
    d.polygon([(72, 57), (85, 39), (80, 34), (97, 33),
               (100, 16), (107, 33), (123, 28), (115, 45),
               (121, 57), (106, 54), (97, 63)], fill=11)
    d.polygon([(87, 55), (97, 42), (102, 28), (108, 44), (112, 56)], fill=10)
    for x, sign in ((0, 1), (16, -1)):
        middle = x + 8
        d.line([(middle - 5, 68), (middle + 5, 68)], fill=10, width=2)
        d.point([(middle + sign * 5, 67)], fill=5)
    for i in range(2):
        letters(im, 64 + 8 * i, 64, str(i))
    states = ("AGUARDA", "CAMINHA", "A BORDO", "COMPLETA", "IÇANDO")
    for i, label in enumerate(states):
        for score in range(2):
            n = i * 2 + score
            x, y = 64 * (n % 3), 72 + 24 * (n // 3)
            d.rectangle((x, y, x + 63, y + 23), fill=1)
            lines = ("MISSAO", "COMPLETA", "RESG:1") if i == 3 else (
                f"A:{score} AB:{int(i == 2)}", "RESG:0", label,
            )
            for k, phrase in enumerate(lines):
                letters(im, x, y + 8 * k, phrase)
    for x, direction, step in [(64, -1, 0), (88, -1, 1), (112, 1, 0), (136, 1, 1)]:
        person(im, x, 150, direction, step)
    return im


def landscape():
    im = canvas(1024, 192, 15)
    d = ImageDraw.Draw(im)
    d.rectangle((0, 48, 1023, 175), fill=2)
    d.rectangle((0, 96, 1023, 175), fill=3)
    for offset in range(0, 1024, 128):
        d.polygon([(offset, 154), (offset + 26, 115), (offset + 53, 132),
                   (offset + 79, 103), (offset + 127, 147), (offset + 127, 175),
                   (offset, 175)], fill=4)
        d.line([(offset + 69, 114), (offset + 79, 103),
                (offset + 89, 112)], fill=6, width=2)
        for x, y in ((13, 16), (60, 34), (109, 20)):
            d.point((offset + x, y), fill=6)
        d.line([(offset + 96, 169), (offset + 96, 159),
                (offset + 103, 157)], fill=14, width=2)
    d.ellipse((204, 20, 229, 45), fill=6)
    d.ellipse((213, 18, 231, 40), fill=15)
    d.rectangle((0, 176, 1023, 191), fill=14)
    d.line([(0, 176), (1023, 176)], fill=6, width=2)
    for x in range(0, 1024, 16):
        d.line([(x + 3, 184), (x + 7, 184)], fill=4)
    d.rectangle((32, 132, 127, 175), fill=9)
    d.polygon([(32, 138), (44, 132), (116, 132), (127, 138),
               (127, 142), (32, 142)], fill=7)
    d.rectangle((67, 146, 101, 175), fill=1)
    d.rectangle((40, 148, 59, 156), fill=7)
    d.line([(38, 172), (61, 172)], fill=10, width=2)
    letters(im, 40, 160, "BASE", 6)
    for x in range(128, 170, 10):
        d.rectangle((x, 173, x + 4, 174), fill=10)
    d.rectangle((560, 124, 639, 175), fill=13)
    d.rectangle((560, 125, 639, 132), fill=11)
    d.rectangle((568, 137, 594, 148), fill=15)
    d.rectangle((604, 137, 628, 148), fill=15)
    for x in (*range(570, 594, 6), *range(606, 629, 6)):
        d.line([(x, 137), (x, 148)], fill=6)
    d.rectangle((590, 154, 614, 175), fill=1)
    letters(im, 604, 159, "ALVO", 6)
    d.line([(568, 124), (568, 112), (584, 112)], fill=10, width=2)
    waiting = im.copy()
    person(waiting, 526, 150, 1, 0)
    return im, waiting


def tiles_and_maps():
    world, waiting = landscape()
    atlas = canvas(192, 192)
    by_tile = {}
    maps = []
    for scene in (world, waiting):
        indices = bytearray()
        for y in range(0, 192, 16):
            for x in range(0, 1024, 16):
                tile = scene.crop((x, y, x + 16, y + 16))
                raw = tile.tobytes()
                if raw not in by_tile:
                    i = len(by_tile)
                    assert i < 144, "Tile atlas capacity exceeded"
                    by_tile[raw] = i
                    atlas.paste(tile, (16 * (i % 12), 16 * (i // 12)))
                indices.append(by_tile[raw])
        assert len(indices) == 768
        maps.append(bytes(indices))
    return atlas, maps, len(by_tile)


def rope_atlas():
    im = canvas(36, 64)
    d = ImageDraw.Draw(im)
    for i in range(1, 9):
        x, tip = 4 * i, 4 * i - 1
        d.line([(x + 1, 0), (x + 1, tip)], fill=5)
        d.point([(x + 2, y) for y in range(1, tip, 4)], fill=8)
        d.line([(x + 1, tip), (x + 3, tip)], fill=10)
    return im


def backdrop():
    im = canvas(256, 192, 15)
    d = ImageDraw.Draw(im)
    d.rectangle((0, 0, 255, 23), fill=1)
    letters(im, 64, 0, "RESGATE AEREO")
    d.line([(64, 13), (165, 13)], fill=8)
    return im


def packed_bitmap(im, mode=1):
    width, height = im.size
    raw = im.tobytes()
    assert width % 2 == 0 and max(raw) < 16
    return struct.pack("<BBHH", 1, mode, width, height) + bytes(
        (raw[i] << 4) | raw[i + 1] for i in range(0, len(raw), 2)
    )


def generate(output):
    output.mkdir(parents=True, exist_ok=False)
    atlas, maps, used = tiles_and_maps()
    sources = {
        "fb": packed_bitmap(backdrop()),
        "heli": packed_bitmap(helicopter_atlas()),
        "tiles": packed_bitmap(atlas),
        "map": maps[0],
        "combat": packed_bitmap(combat_atlas()),
        "wait": maps[1],
        "rope": packed_bitmap(rope_atlas()),
    }
    for name, data in sources.items():
        (output / f"{name}.raw").write_bytes(data)
        (output / f"{name}.rle").write_bytes(encode(data))
    (output / "palette.json").write_text(
        json.dumps({"colors": [{"rgb": "#" + color} for color in PALETTE]}, indent=2),
        encoding="utf8",
    )
    print(json.dumps({"tile_count": used, "overlays": ["base", "shelter", "walker"], "lengths": {
        key: len(value) for key, value in sources.items()
    }}))


if __name__ == "__main__":
    generate(Path(sys.argv[1]))
