
read16:
 LD BC,$80F7
 OUT (C),A
 INC B
 IN A,(C)
 LD L,A
 IN A,(C)
 LD H,A
 RET
detect:
 XOR A
 CALL read16
 LD DE,$4B54
 OR A
 SBC HL,DE
 JR NZ,missing
 IN A,(C)
 CP $47
 JR NZ,missing
 IN A,(C)
 CP $41
 JR NZ,missing
 OR A
 RET
missing: SCF
 RET
start_wait:
 LD HL,($7010)
 LD (wait_start),HL
 RET
guard:
 PUSH AF
 PUSH BC
 PUSH DE
 PUSH HL
 LD A,$40
 CALL read16
 BIT 5,L
 JP NZ,wire_error
 LD HL,($7010)
 LD DE,(wait_start)
 OR A
 SBC HL,DE
 LD A,H
 CP $20
 JP NC,timed_out
 POP HL
 POP DE
 POP BC
 POP AF
 RET
wire_error:
 LD A,$43
 CALL read16
 LD A,L
 LD ($6803),A
 JP failed
timed_out:
 LD A,$FE
 LD ($6803),A
 JP failed
send_packet:
 PUSH AF
 LD A,(frame_commands)
 INC A
 LD (frame_commands),A
 POP AF
 LD E,(IX+0)
 LD D,(IX+1)
 INC IX
 INC IX
 CALL start_wait
credit_cmd:
 CALL guard
 LD A,$41
 CALL read16
 PUSH HL
 LD BC,($7020)
 OR A
 SBC HL,BC
 POP HL
 JR NC,cmd_min_ok
 LD ($7020),HL
cmd_min_ok:
 OR A
 SBC HL,DE
 CALL C,idle
 JR C,credit_cmd
 LD HL,($6828)
 ADD HL,DE
 LD ($6828),HL
 LD BC,$82F7
command_byte:
 LD A,(IX+0)
 OUT (C),A
 INC IX
 DEC DE
 LD A,D
 OR E
 JR NZ,command_byte
 RET
put_data:
 PUSH AF
 CALL start_wait
credit_data:
 CALL guard
 LD A,$42
 CALL read16
 PUSH HL
 LD BC,($7022)
 OR A
 SBC HL,BC
 POP HL
 JR NC,data_min_ok
 LD ($7022),HL
data_min_ok:
 LD A,H
 OR L
 CALL Z,idle
 JR Z,credit_data
 LD HL,($682A)
 INC HL
 LD ($682A),HL
 LD A,H
 OR L
 JR NZ,data_count_ok
 LD HL,($682C)
 INC HL
 LD ($682C),HL
data_count_ok:
 POP AF
 LD BC,$83F7
 OUT (C),A
 RET
wait_upload:
 CALL start_wait
wait_upload_loop:
 CALL guard
 LD A,$47
 CALL read16
 LD A,L
 CP 1
 CALL NZ,idle
 JR NZ,wait_upload_loop
 RET
upload_bytes:
 LD A,(IX+0)
 CALL put_data
 INC IX
 DEC DE
 LD A,D
 OR E
 JR NZ,upload_bytes
 RET
wait_fence:
 CALL start_wait
wait_fence_loop:
 CALL guard
 LD A,$45
 CALL read16
 OR A
 SBC HL,DE
 CALL NZ,idle
 JR NZ,wait_fence_loop
 RET
wait_present:
 CALL start_wait
wait_present_loop:
 CALL guard
 LD A,$40
 CALL read16
 BIT 0,H
 CALL Z,idle
 JR Z,wait_present_loop
 LD A,$46
 CALL read16
 LD DE,($7004)
 OR A
 SBC HL,DE
 JP NZ,protocol_error
 LD HL,($7004)
 CALL ack_hl
 LD A,$40
 CALL read16
 BIT 0,H
 JP NZ,protocol_error
 LD A,$43
 CALL read16
 LD A,L
 LD ($6803),A
 OR A
 JP NZ,failed
 LD HL,($7006)
 INC HL
 LD ($7006),HL
 RET
ack_hl:
 PUSH HL
 LD BC,$80F7
 LD A,$81
 OUT (C),A
 LD BC,$85F7
 POP HL
 LD A,L
 OUT (C),A
 LD A,H
 OUT (C),A
 RET
protocol_error:
 LD A,$FD
 LD ($6803),A
failed:
 LD A,$EE
 LD ($6802),A
 LD A,2
 OUT ($FE),A
 DI
 HALT
 JP failed
wait_start: DW 0

idle:
 PUSH AF
 IF PROFILE
idle_enter_marker:
 LD BC,$80F7
 LD A,$40
 OUT (C),A
 ENDIF
 HALT
 IF PROFILE
idle_leave_marker:
 LD BC,$80F7
 LD A,$40
 OUT (C),A
 ENDIF
 POP AF
 RET
