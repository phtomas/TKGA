; Rendering separates mandatory pose/physics from optional rotor phase/effect/HUD.
render_combat_scene:
 CALL render_rescue_map
 CALL render_walker
 CALL choose_heli_frame
 CALL render_scroll
 CALL render_heli_position
 IF COMBAT
 CALL render_target_position
 CALL render_shots
 ENDIF
 LD A,(heli_ori_gpu)
 LD B,A
 LD A,(orientation)
 CP B
 JR NZ,mandatory_pose
 LD A,(heli_damage_gpu)
 LD B,A
 LD A,(damage)
 CP B
 JR Z,pose_ready
mandatory_pose:
 CALL apply_heli_frame
pose_ready:
 IF COMBAT
 CALL render_target_frame
 ENDIF
 LD A,(heli_gpu)
 LD B,A
 LD A,(heli_want)
 CP B
 JR Z,animation_ready
 LD A,(frame_commands)
 CP 7
 CALL C,apply_heli_frame
animation_ready:
 IF COMBAT
 CALL render_rescue_hud
 ENDIF
 XOR A
 LD B,A
 LD A,(heli_gpu)
 LD C,A
 LD A,(heli_want)
 CP C
 JR Z,no_heli_pending
 INC B
no_heli_pending:
 IF COMBAT
 LD A,(target_gpu)
 LD C,A
 LD A,(target_want)
 CP C
 JR Z,no_target_pending
 INC B
no_target_pending:
 LD A,(rescue_hud_gpu)
 LD C,A
 LD A,(rescue_hud_want)
 CP C
 JR Z,no_score_pending
 INC B
no_score_pending:
 LD A,(walk_frame_gpu)
 LD C,A
 LD A,(walk_frame_want)
 CP C
 JR Z,no_walk_pending
 INC B
no_walk_pending:
 ENDIF
 LD A,B
 OR A
 LD A,0
 JR Z,pending_store
 LD A,(pending_age)
 INC A
pending_store:
 LD (pending_age),A
 LD B,A
 LD A,(max_pending)
 CP B
 RET NC
 LD A,B
 LD (max_pending),A
 RET

choose_heli_frame:
 LD A,(damage)
 OR A
 LD A,8
 JR NZ,heli_frame_selected
 LD A,(orientation)
 LD L,A
 LD H,0
 LD DE,heli_frame_base
 ADD HL,DE
 LD B,(HL)
 LD A,(orientation)
 CP 1
 JR Z,heli_quarter_frame
 CP 3
 JR Z,heli_quarter_frame
 LD A,(ticks)
 RRCA
 RRCA
 AND 1
 ADD A,B
 JR heli_frame_selected
heli_quarter_frame:
 LD A,B
heli_frame_selected:
 LD (heli_want),A
 RET
heli_frame_base: DB 0,2,3,5,6

render_heli_position:
 LD A,(pos_x)
 LD B,A
 LD A,(heli_gpu_x)
 CP B
 JR NZ,heli_position_dirty
 LD A,(pos_y)
 LD B,A
 LD A,(heli_gpu_y)
 CP B
 RET Z
heli_position_dirty:
 LD A,(pos_x)
 LD L,A
 LD H,0
 LD (heli_gpu_x),HL
 LD A,(pos_y)
 LD (heli_gpu_y),A
 LD D,A
 XOR A
 JP gpu_position
apply_heli_frame:
 LD A,(heli_want)
 LD (heli_gpu),A
 LD L,A
 LD A,(orientation)
 LD (heli_ori_gpu),A
 LD A,(damage)
 LD (heli_damage_gpu),A
 XOR A
 JP gpu_frame

render_target_position:
 LD A,(target_state)
 CP 3
 JR NZ,target_position_needed
 LD A,(target_gpu)
 CP 2
 RET Z
target_position_needed:
 LD HL,640
 LD DE,(camera_x)
 OR A
 SBC HL,DE
 BIT 7,H
 JR Z,target_positive
 LD A,H
 CP $FF
 JR NZ,target_hidden
 LD A,L
 CP 193
 JR NC,target_x_ready
 JR target_hidden
target_positive:
 LD A,H
 OR A
 JR Z,target_x_ready
target_hidden:
 LD HL,$FFC0
target_x_ready:
 LD DE,(target_gpu_x)
 PUSH HL
 OR A
 SBC HL,DE
 POP HL
 RET Z
 LD (target_gpu_x),HL
 LD D,112
 LD A,5
 JP gpu_position

render_shots:
 LD IY,shots
 XOR A
 LD (pool_index),A
render_shot_loop:
 LD A,(IY+0)
 OR A
 JR Z,inactive_shot_position
 LD A,(IY+12)
 LD B,A
 LD A,(IY+11)
 CP B
 JR Z,shot_frame_ready
 LD A,B
 LD (IY+11),A
 LD L,A
 LD A,(pool_index)
 INC A
 CALL gpu_frame
shot_frame_ready:
 LD L,(IY+2)
 LD H,(IY+3)
 LD DE,(camera_x)
 OR A
 SBC HL,DE
 LD D,(IY+4)
 JR shot_position_check
inactive_shot_position:
 LD HL,$FFC0
 LD D,0
shot_position_check:
 LD A,(IY+8)
 CP L
 JR NZ,shot_position_dirty
 LD A,(IY+9)
 CP H
 JR NZ,shot_position_dirty
 LD A,(IY+10)
 CP D
 JR Z,next_render_shot
shot_position_dirty:
 LD (IY+8),L
 LD (IY+9),H
 LD (IY+10),D
 LD A,(pool_index)
 INC A
 CALL gpu_position
next_render_shot:
 LD DE,16
 ADD IY,DE
 LD A,(pool_index)
 INC A
 LD (pool_index),A
 CP POOL
 JP C,render_shot_loop
 RET

render_target_frame:
 LD A,(target_gpu)
 LD B,A
 LD A,(target_want)
 CP B
 RET Z
 LD A,(frame_commands)
 CP 7
 RET NC
 LD A,(target_want)
 LD (target_gpu),A
 LD L,A
 LD A,5
 CALL gpu_frame
 LD A,(target_state)
 CP 1
 JR NZ,target_not_new_explosion
 LD A,2
 LD (target_state),A
 LD A,12
 LD (target_timer),A
 LD A,9
 JR target_frame_event
target_not_new_explosion:
 CP 3
 LD A,10
 JR Z,target_frame_event
 LD A,12
target_frame_event:
 LD HL,640
 LD B,112
 LD C,255
 JP log_event
render_score:
 LD A,(score_gpu)
 LD B,A
 LD A,(score)
 CP B
 RET Z
 LD A,(frame_commands)
 CP 7
 RET NC
 LD A,(score)
 LD (score_gpu),A
 LD L,A
 LD A,6
 CALL gpu_frame
 LD A,11
 LD HL,0
 LD B,0
 LD C,255
 JP log_event

; A=sprite id, HL=signed screen X, D=Y. All Y nonnegative.
gpu_position:
 LD (position_packet+6),A
 LD (position_packet+8),HL
 LD A,D
 LD (position_packet+10),A
 XOR A
 LD (position_packet+11),A
 LD IX,position_packet
 JP send_packet
; A=sprite id,L=frame. No changes to definitions/resources in flight.
gpu_frame:
 LD (frame_packet+6),A
 LD A,L
 LD (frame_packet+8),A
 XOR A
 LD (frame_packet+9),A
 LD IX,frame_packet
 JP send_packet
