v_mask EQU $7158
v_edges EQU $7159
sampled_v EQU $715A
sampled_v_edge EQU $715B
ERGO_PICK_MIN EQU 456
ERGO_PICK_MAX EQU 496
ERGO_DOOR_MIN EQU 480
ERGO_DOOR_MAX EQU 554
ERGO_CAM_LEFT EQU 80
ERGO_CAM_RIGHT EQU 112
ERGO_PROFILE_ID EQU 3
LAYERS EQU 1
POOL EQU 2
COMBAT EQU 1
AUTO EQU 0
PROFILE EQU 0
quarter_flags EQU $7060
frame_commands EQU $7061
far_deferred EQU $7062
world_x EQU $7040
camera_x EQU $7042
old_scroll EQU $7044
old_far EQU $7046
auto_tick EQU $7050
auto_remaining EQU $7052
auto_pointer EQU $7054
auto_prev EQU $7056
auto_done EQU $7057
pos_x EQU $7000
pos_y EQU $7001
vx EQU $7002
orientation EQU $7003
tag EQU $7004
acks EQU $7006
vy EQU $7008
damage EQU $7009
ticks EQU $7010
update_tick EQU $7030
active_body EQU $7032
active_rotor EQU $7033
old_body EQU $7034
old_rotor EQU $7035
old_heading EQU $7036
phase EQU $7037
raw_rows EQU $7100
key_mask EQU $7108
key_edges EQU $7109
sampled_keys EQU $7110
sampled_edges EQU $7111
turn_held EQU $7112
turn_delay EQU $7113
last_turn EQU $7114
telemetry EQU $7200
 INCLUDE "combat_ram.inc"
 INCLUDE "rescue_ram.inc"
 INCLUDE "walk_ram.inc"
 ORG $7B00
 DI
 LD SP,$7AFF
 XOR A
 LD HL,$6800
 LD DE,$6801
 LD BC,$0BFF
 LD (HL),A
 LDIR
 LD HL,$7500
 LD DE,$7501
 LD BC,511
 XOR A
 LD (HL),A
 LDIR
 CALL boot_banner
 LD HL,$FFFF
 LD ($7020),HL
 LD ($7022),HL
 LD HL,$7800
 LD DE,$7801
 LD BC,256
 LD (HL),$77
 LDIR
 LD A,$C3
 LD ($7777),A
 LD HL,isr
 LD ($7778),HL
 LD A,$78
 LD I,A
 IM 2
 EI
 CALL detect
 JP C,failed
 LD A,1
 CALL read16
 LD DE,257
 OR A
 SBC HL,DE
 JP NZ,protocol_error
 LD A,2
 CALL read16
 LD DE,257
 OR A
 SBC HL,DE
 JP NZ,protocol_error
 LD A,5
 CALL read16
 LD DE,2
 OR A
 SBC HL,DE
 JP C,protocol_error
 LD A,7
 CALL read16
 LD DE,64
 OR A
 SBC HL,DE
 JP C,protocol_error
 LD A,8
 CALL read16
 LD DE,1
 OR A
 SBC HL,DE
 JP C,protocol_error
 LD A,10
 CALL read16
 LD DE,256
 OR A
 SBC HL,DE
 JP C,protocol_error
 LD A,11
 CALL read16
 LD DE,207
 OR A
 SBC HL,DE
 JP C,protocol_error
 LD A,12
 CALL read16
 LD DE,7
 OR A
 SBC HL,DE
 JP C,protocol_error
 LD A,13
 CALL read16
 LD DE,2
 OR A
 SBC HL,DE
 JP C,protocol_error
 LD A,16
 CALL read16
 LD DE,16
 OR A
 SBC HL,DE
 JP C,protocol_error
 LD A,23
 CALL read16
 LD DE,64
 OR A
 SBC HL,DE
 JP C,protocol_error
 LD A,24
 CALL read16
 LD DE,56
 OR A
 SBC HL,DE
 JP C,protocol_error
 LD A,25
 CALL read16
 LD DE,1
 OR A
 SBC HL,DE
 JP C,protocol_error
 LD A,4
 CALL read16
 BIT 0,L
 JP Z,protocol_error
 LD A,1
 LD (phase),A
 IF LAYERS
 LD A,3
 CALL read16
 BIT 1,L
 JP Z,protocol_error
 LD A,$14
 CALL read16
 BIT 1,L
 JP Z,protocol_error
 LD A,$15
 CALL read16
 LD DE,64
 OR A
 SBC HL,DE
 JP C,protocol_error
 LD A,$0E
 CALL read16
 LD A,L
 CP LAYERS
 JP C,protocol_error
 ENDIF
 CALL dump_caps
 LD A,$0B
 CALL read16
 LD DE,256
 OR A
 SBC HL,DE
 JP C,protocol_error
 LD A,$0D
 CALL read16
 LD DE,POOL+4
 OR A
 SBC HL,DE
 JP C,protocol_error
 LD IX,create_fb
 CALL send_packet
 LD IX,begin_fb
 CALL send_packet
 CALL wait_upload
 LD IX,fb_blob
 LD DE,24582
 CALL upload_packed
 LD IX,end_fb
 CALL send_packet
 LD IX,fence_fb
 CALL send_packet
 LD DE,1
 CALL wait_fence
 LD IX,palette
 CALL send_packet
 LD IX,bind
 CALL send_packet
 LD IX,mode
 CALL send_packet
 LD HL,1
 LD (tag),HL
 LD IX,present_intro
 CALL send_packet
 CALL wait_present
 LD HL,2
 LD (tag),HL
 LD IX,create_heli
 CALL send_packet
 LD IX,begin_heli
 CALL send_packet
 CALL wait_upload
 LD IX,heli_blob
 LD DE,18438
 CALL upload_packed
 LD IX,end_heli
 CALL send_packet
 LD IX,fence_heli
 CALL send_packet
 LD DE,2
 CALL wait_fence
 LD IX,create_tiles
 CALL send_packet
 LD IX,begin_tiles
 CALL send_packet
 CALL wait_upload
 LD IX,tiles_blob
 LD DE,18438
 CALL upload_packed
 LD IX,end_tiles
 CALL send_packet
 LD IX,fence_tiles
 CALL send_packet
 LD DE,3
 CALL wait_fence
 LD IX,create_map
 CALL send_packet
 LD IX,begin_map
 CALL send_packet
 CALL wait_upload
 LD IX,map_blob
 LD DE,768
 CALL upload_packed
 LD IX,end_map
 CALL send_packet
 LD IX,fence_map
 CALL send_packet
 LD DE,4
 CALL wait_fence
 LD IX,create_combat
 CALL send_packet
 LD IX,begin_combat
 CALL send_packet
 CALL wait_upload
 LD IX,25540
 LD DE,4543
 CALL upload_packed
 LD IX,combat_blob
 LD DE,12359
 CALL upload_packed
 LD IX,end_combat
 CALL send_packet
 LD IX,fence_combat
 CALL send_packet
 LD DE,5
 CALL wait_fence
 LD IX,create_wait
 CALL send_packet
 LD IX,begin_wait
 CALL send_packet
 CALL wait_upload
 LD IX,wait_blob
 LD DE,768
 CALL upload_packed
 LD IX,end_wait
 CALL send_packet
 LD IX,fence_wait
 CALL send_packet
 LD DE,7
 CALL wait_fence
 LD IX,tileset
 CALL send_packet
 LD IX,mapbind
 CALL send_packet
 LD IX,layerconfig
 CALL send_packet
 LD IX,layerscroll
 CALL send_packet
 LD IX,layerenable
 CALL send_packet
 LD IX,actor_0_def
 CALL send_packet
 LD IX,actor_0_attr
 CALL send_packet
 LD IX,actor_0_frame
 CALL send_packet
 LD IX,actor_0_pos
 CALL send_packet
 LD IX,actor_0_enable
 CALL send_packet
 LD IX,actor_1_def
 CALL send_packet
 LD IX,actor_1_attr
 CALL send_packet
 LD IX,actor_1_frame
 CALL send_packet
 LD IX,actor_1_pos
 CALL send_packet
 LD IX,actor_1_enable
 CALL send_packet
 LD IX,actor_2_def
 CALL send_packet
 LD IX,actor_2_attr
 CALL send_packet
 LD IX,actor_2_frame
 CALL send_packet
 LD IX,actor_2_pos
 CALL send_packet
 LD IX,actor_2_enable
 CALL send_packet
 LD IX,actor_5_def
 CALL send_packet
 LD IX,actor_5_attr
 CALL send_packet
 LD IX,actor_5_frame
 CALL send_packet
 LD IX,actor_5_pos
 CALL send_packet
 LD IX,actor_5_enable
 CALL send_packet
 LD IX,actor_6_def
 CALL send_packet
 LD IX,actor_6_attr
 CALL send_packet
 LD IX,actor_6_frame
 CALL send_packet
 LD IX,actor_6_pos
 CALL send_packet
 LD IX,actor_6_enable
 CALL send_packet
 LD IX,actor_7_def
 CALL send_packet
 LD IX,actor_7_attr
 CALL send_packet
 LD IX,actor_7_frame
 CALL send_packet
 LD IX,actor_7_pos
 CALL send_packet
 LD IX,actor_7_enable
 CALL send_packet
 LD IX,rope_create
 CALL send_packet
 LD IX,rope_begin
 CALL send_packet
 CALL wait_upload
 LD IX,rope_blob
 LD DE,1158
 CALL upload_packed
 LD IX,rope_end
 CALL send_packet
 LD IX,rope_fence
 CALL send_packet
 LD DE,8
 CALL wait_fence
 LD IX,rope_def
 CALL send_packet
 LD IX,rope_attr
 CALL send_packet
 LD IX,rope_frame
 CALL send_packet
 LD IX,rope_pos
 CALL send_packet
 LD IX,rope_enable
 CALL send_packet
 LD IX,fence_scene
 CALL send_packet
 LD DE,9
 CALL wait_fence
 CALL init_combat
 CALL center
 LD HL,96
 LD (heli_gpu_x),HL
 LD A,72
 LD (heli_gpu_y),A
 LD A,3
 LD (heli_gpu),A
 LD A,2
 LD (heli_ori_gpu),A
 XOR A
 LD (heli_damage_gpu),A
 LD (target_gpu),A
 LD (score_gpu),A
 LD HL,$FFC0
 LD (target_gpu_x),HL
 LD A,112
 LD (target_gpu_y),A
 LD IY,shots
 LD B,4
preset_shot:
 LD (IY+8),$C0
 LD (IY+9),$FF
 LD (IY+10),0
 LD (IY+11),0
 LD DE,16
 ADD IY,DE
 DJNZ preset_shot
 LD HL,0
 LD (old_scroll),HL
 IF AUTO
 LD HL,script_table
 LD (auto_pointer),HL
 ENDIF
 LD HL,$FFC0
 LD (walk_x_gpu),HL
 XOR A
 LD (walk_frame_gpu),A
 LD A,6
 LD (rescue_map_gpu),A
 XOR A
 LD (rescue_hud_gpu),A
 LD (rescue_hud_want),A
 XOR A
 LD (stop_requested),A
 LD A,3
 LD (phase),A
main:
 XOR A
 LD (frame_commands),A
 LD HL,(ticks)
 LD (update_tick),HL
 LD HL,(logic_counter)
 INC HL
 LD (logic_counter),HL
 IF PROFILE
update_begin_marker:
 LD BC,$80F7
 LD A,$40
 OUT (C),A
 ENDIF
 IF AUTO
 DI
 CALL script_controls
 ENDIF
 CALL update_controls
 CALL combat_update
 CALL rope_update
 IF PROFILE
update_end_marker:
 LD BC,$80F7
 LD A,$40
 OUT (C),A
 ENDIF
 CALL render_combat_scene
 CALL render_rope
 IF PROFILE
render_end_marker:
 LD BC,$80F7
 LD A,$40
 OUT (C),A
 ENDIF
 LD HL,(tag)
 LD (present_packet+6),HL
 LD IX,present_packet
 CALL send_packet
 CALL wait_present
 IF PROFILE
ack_end_marker:
 LD BC,$80F7
 LD A,$40
 OUT (C),A
 ENDIF
 LD A,(frame_commands)
 CP 9
 JR C,no_budget_overrun
 LD HL,(budget_overruns)
 INC HL
 LD (budget_overruns),HL
no_budget_overrun:
 LD B,A
 LD A,(max_commands)
 CP B
 JR NC,maxcmd_ok
 LD A,B
 LD (max_commands),A
maxcmd_ok:
 CALL publish_telemetry
 IF AUTO
 LD A,(auto_done)
 OR A
 JP NZ,finished
 ELSE
 LD A,(stop_requested)
 OR A
 JP NZ,finished
 ENDIF
 LD HL,(tag)
 INC HL
 LD (tag),HL
 LD A,H
 OR L
 JP Z,tag_exhausted
pace:
 LD HL,(ticks)
 LD DE,(update_tick)
 OR A
 SBC HL,DE
 LD A,L
 CP 1
 JP NC,main
 CALL idle
 JR pace
tag_exhausted:
 LD A,$D0
 LD ($6802),A
 HALT
 JR tag_exhausted
finished:
 LD A,$A5
 LD ($6802),A
 DI
 HALT
 JP finished
render_scroll:
 LD HL,(camera_x)
 LD DE,(old_scroll)
 OR A
 SBC HL,DE
 RET Z
 LD HL,(camera_x)
 LD (scroll_main+7),HL
 LD (old_scroll),HL
 LD IX,scroll_main
 JP send_packet
 INCLUDE "input_rope_candidate.inc"
 INCLUDE "combat_rescue_logic.inc"
 INCLUDE "rescue_walk_logic.inc"
 INCLUDE "walk_rope_candidate.inc"
 INCLUDE "rope_rescue.inc"
 INCLUDE "combat_walk_render.inc"
 INCLUDE "rescue_rope_render.inc"
 INCLUDE "transport_world.inc"
publish_telemetry:
 DI
 LD HL,(telemetry)
 INC HL
 LD (telemetry),HL
 PUSH HL
 LD HL,(acks)
 LD (telemetry+2),HL
 LD HL,(tag)
 LD (telemetry+4),HL
 LD HL,(ticks)
 LD (telemetry+6),HL
 LD A,(pos_x)
 LD (telemetry+8),A
 LD A,(pos_y)
 LD (telemetry+9),A
 LD A,(vx)
 LD (telemetry+10),A
 LD A,(vy)
 LD (telemetry+11),A
 LD A,(orientation)
 LD (telemetry+12),A
 LD A,(damage)
 LD (telemetry+13),A
 LD A,(sampled_keys)
 LD (telemetry+14),A
 LD A,(sampled_edges)
 LD (telemetry+15),A
 LD HL,($6828)
 LD (telemetry+24),HL
 LD HL,raw_rows
 LD DE,telemetry+16
 LD BC,8
 LDIR
 LD HL,$682A
 LD DE,telemetry+26
 LD BC,4
 LDIR
 LD A,($6803)
 LD (telemetry+30),A
 LD A,(phase)
 LD (telemetry+31),A
 LD HL,(world_x)
 LD (telemetry+32),HL
 LD HL,(camera_x)
 LD (telemetry+34),HL
 LD HL,(logic_counter)
 LD (telemetry+36),HL
 LD A,(heli_gpu)
 LD (telemetry+38),A
 LD A,(heli_want)
 LD (telemetry+39),A
 LD A,(frame_commands)
 LD (telemetry+40),A
 LD A,(sampled_fire)
 LD (telemetry+42),A
 LD A,(sampled_fire_edges)
 LD (telemetry+43),A
 LD A,(cooldown)
 LD (telemetry+44),A
 LD A,(target_state)
 LD (telemetry+45),A
 LD A,(target_gpu)
 LD (telemetry+46),A
 LD A,(score_gpu)
 LD (telemetry+47),A
 LD HL,(score)
 LD (telemetry+48),HL
 LD HL,(total_hits)
 LD (telemetry+50),HL
 LD HL,(generation)
 LD (telemetry+52),HL
 LD HL,(shots_total)
 LD (telemetry+54),HL
 LD HL,(front_reject)
 LD (telemetry+56),HL
 LD HL,(pool_reject)
 LD (telemetry+58),HL
 LD A,(target_timer)
 LD (telemetry+60),A
 LD A,(pending_age)
 LD (telemetry+61),A
 LD A,(max_pending)
 LD (telemetry+62),A
 LD A,(max_commands)
 LD (telemetry+63),A
 LD HL,(target_gpu_x)
 LD (telemetry+128),HL
 LD A,(target_gpu_y)
 LD (telemetry+130),A
 LD HL,(heli_gpu_x)
 LD (telemetry+136),HL
 LD A,(heli_gpu_y)
 LD (telemetry+138),A
 LD HL,(update_tick)
 LD (telemetry+140),HL
 LD HL,(event_seq)
 LD (telemetry+160),HL
 LD HL,(event_epoch)
 LD (telemetry+162),HL
 LD HL,(ttl_expired)
 LD (telemetry+164),HL
 LD HL,(offscreen_expired)
 LD (telemetry+166),HL
 LD HL,(world_expired)
 LD (telemetry+168),HL
 LD HL,(budget_overruns)
 LD (telemetry+170),HL
 LD A,(heli_ori_gpu)
 LD (telemetry+172),A
 LD A,(heli_damage_gpu)
 LD (telemetry+173),A
 LD HL,(auto_tick)
 LD (telemetry+174),HL
 LD A,POOL
 LD (telemetry+41),A
 LD HL,shots
 LD DE,telemetry+64
 LD BC,64
 LDIR
 LD HL,last_event
 LD DE,telemetry+144
 LD BC,16
 LDIR
 LD A,(rescue_state)
 LD (telemetry+176),A
 LD A,(reset_stage)
 LD (telemetry+177),A
 LD A,(sampled_c)
 LD (telemetry+178),A
 LD A,(sampled_c_edge)
 LD (telemetry+179),A
 LD A,(rescue_dwell)
 LD (telemetry+180),A
 LD A,(rescued_count)
 LD (telemetry+181),A
 LD A,(mission_done)
 LD (telemetry+182),A
 LD A,(rescue_reject)
 LD (telemetry+183),A
 LD HL,(rescue_rejects)
 LD (telemetry+184),HL
 LD A,(rescue_map_gpu)
 LD (telemetry+186),A
 LD A,(rescue_hud_gpu)
 LD (telemetry+187),A
 LD A,(rescue_hud_want)
 LD (telemetry+188),A
 LD HL,(rescue_hotspot)
 LD (telemetry+189),HL
 LD A,$C5
 LD (telemetry+191),A
 LD A,(walk_phase)
 LD (telemetry+192),A
 LD HL,(walk_x)
 LD (telemetry+193),HL
 LD HL,(walk_goal)
 LD (telemetry+195),HL
 LD A,(walk_age)
 LD (telemetry+197),A
 LD A,(walk_frame_gpu)
 LD (telemetry+198),A
 LD HL,(walk_x_gpu)
 LD (telemetry+199),HL
 LD A,(walk_frame_want)
 LD (telemetry+201),A
 LD A,(walk_phase_before_input)
 LD (telemetry+202),A
 LD A,(walk_direction)
 LD (telemetry+203),A
 LD A,(sampled_v)
 LD (telemetry+204),A
 LD A,(sampled_v_edge)
 LD (telemetry+205),A
 LD A,(rope_phase)
 LD (telemetry+206),A
 LD A,(rope_length)
 LD (telemetry+207),A
 POP HL
 INC HL
 LD (telemetry),HL
 EI
 RET
dump_caps:
 LD IX,$7300
 LD D,0
caps_loop:
 LD A,D
 PUSH DE
 CALL read16
 LD (IX+0),L
 LD (IX+1),H
 INC IX
 INC IX
 POP DE
 INC D
 LD A,D
 CP 26
 JR C,caps_loop
 LD A,6
 CALL read16
 LD ($7370),HL
 IN A,(C)
 LD ($7372),A
 IN A,(C)
 LD ($7373),A
 RET
boot_banner:
 XOR A
 LD HL,$4000
 LD DE,$4001
 LD BC,6143
 LD (HL),A
 LDIR
 LD HL,$5800
 LD DE,$5801
 LD BC,767
 LD (HL),7
 LDIR
 LD DE,$4000
 LD IX,boot_line1
 CALL text
 LD DE,$4020
 LD IX,boot_line2
 CALL text
 LD DE,$4040
 LD IX,boot_line3
 CALL text
 LD DE,$4060
 LD IX,boot_line4
 JP text
text:
 LD A,(IX+0)
 OR A
 RET Z
 INC IX
 CALL character
 JR text
character:
 PUSH HL
 PUSH BC
 DEC A
 LD L,A
 LD H,0
 ADD HL,HL
 ADD HL,HL
 ADD HL,HL
 LD BC,pub03_font
 ADD HL,BC
 LD B,8
char_row:
 LD A,(HL)
 LD (DE),A
 INC HL
 INC D
 DJNZ char_row
 LD A,D
 SUB 8
 LD D,A
 INC E
 POP BC
 POP HL
 RET
boot_line1: DB 19,7,20,9,4,21,7,1,4,7,19,7,16,1,2,1,21,12,9,4,0 ; RESGATE AEREO - TKGA
boot_line2: DB 18,3,4,1,22,17,3,6,16,23,15,1,16,3,17,1,13,7,8,21,3,19,11,9,10,21,0 ; Q/A UP/DOWN O/P LEFT/RIGHT
boot_line3: DB 25,3,24,1,21,22,19,15,1,6,1,6,4,14,4,9,7,1,19,1,5,7,15,21,7,19,0 ; Z/X TURN D DAMAGE R CENTER
boot_line4: DB 13,16,4,6,11,15,9,1,4,20,20,7,21,20,1,2,1,17,13,7,4,20,7,1,23,4,11,21,0 ; LOADING ASSETS - PLEASE WAIT
create_fb: DW 12
 DB 16,0,8,0,1,0,4,0,6,96,0,0
begin_fb: DW 15
 DB 18,0,11,0,1,0,0,0,0,0,6,96,0,0,1
end_fb: DW 10
 DB 19,0,6,0,1,0,246,58,60,41
fence_fb: DW 6
 DB 3,0,2,0,1,0
fb_blob EQU 24064
palette: DW 55
 DB 32,0,51,0,0,0,16,0,0,0,17,24,39,32,45,73,52,70,103,88,104,137,243,242,223,197,216,218,173,237,225,78,179,170,36,89,101,249,185,90,212,119,66,166,79,82,105,63,80,57,67,79,18,31,51
bind: DW 8
 DB 48,0,4,0,1,1,0,0
mode: DW 6
 DB 1,0,2,0,1,0
present_intro: DW 7
 DB 4,0,3,0,1,0,0
create_heli: DW 12
 DB 16,0,8,0,2,0,1,0,6,72,0,0
begin_heli: DW 15
 DB 18,0,11,0,2,0,0,0,0,0,6,72,0,0,1
end_heli: DW 10
 DB 19,0,6,0,2,0,47,246,36,106
fence_heli: DW 6
 DB 3,0,2,0,2,0
heli_blob: INCBIN "../assets/heli_composite.rle"
create_tiles: DW 12
 DB 16,0,8,0,3,0,1,0,6,72,0,0
begin_tiles: DW 15
 DB 18,0,11,0,3,0,0,0,0,0,6,72,0,0,1
end_tiles: DW 10
 DB 19,0,6,0,3,0,101,96,1,215
fence_tiles: DW 6
 DB 3,0,2,0,3,0
tiles_blob: INCBIN "../assets/tiles_1.bitmap.rle"
create_map: DW 12
 DB 16,0,8,0,4,0,3,0,0,3,0,0
begin_map: DW 15
 DB 18,0,11,0,4,0,0,0,0,0,0,3,0,0,1
end_map: DW 10
 DB 19,0,6,0,4,0,166,125,210,208
fence_map: DW 6
 DB 3,0,2,0,4,0
map_blob EQU 24793
create_combat: DW 12
 DB 16,0,8,0,5,0,1,0,6,66,0,0
begin_combat: DW 15
 DB 18,0,11,0,5,0,0,0,0,0,6,66,0,0,1
end_combat: DW 10
 DB 19,0,6,0,5,0,225,126,243,114
fence_combat: DW 6
 DB 3,0,2,0,5,0
combat_blob: INCBIN "../assets/pub03_combat.rle"
tileset: DW 11
 DB 64,0,7,0,0,3,0,16,16,4,0
mapbind: DW 11
 DB 65,0,7,0,0,6,0,64,0,12,0
layerconfig: DW 9
 DB 66,0,5,0,0,0,4,0,0
layerscroll: DW 9
 DB 67,0,5,0,0,0,0,0,0
layerenable: DW 6
 DB 68,0,2,0,0,1
actor_0_def: DW 16
 DB 80,0,12,0,0,0,2,0,0,0,0,0,64,0,64,0
actor_0_attr: DW 10
 DB 83,0,6,0,0,0,8,0,0,0
actor_0_frame: DW 8
 DB 82,0,4,0,0,0,3,0
actor_0_pos: DW 10
 DB 81,0,6,0,0,0,96,0,72,0
actor_0_enable: DW 7
 DB 85,0,3,0,0,0,1
actor_1_def: DW 16
 DB 80,0,12,0,1,0,5,0,0,0,64,0,16,0,8,0
actor_1_attr: DW 10
 DB 83,0,6,0,1,0,8,0,0,0
actor_1_frame: DW 8
 DB 82,0,4,0,1,0,0,0
actor_1_pos: DW 10
 DB 81,0,6,0,1,0,192,255,0,0
actor_1_enable: DW 7
 DB 85,0,3,0,1,0,1
actor_2_def: DW 16
 DB 80,0,12,0,2,0,5,0,0,0,64,0,16,0,8,0
actor_2_attr: DW 10
 DB 83,0,6,0,2,0,8,0,0,0
actor_2_frame: DW 8
 DB 82,0,4,0,2,0,0,0
actor_2_pos: DW 10
 DB 81,0,6,0,2,0,192,255,0,0
actor_2_enable: DW 7
 DB 85,0,3,0,2,0,1
actor_5_def: DW 16
 DB 80,0,12,0,5,0,5,0,0,0,0,0,64,0,64,0
actor_5_attr: DW 10
 DB 83,0,6,0,5,0,8,0,0,0
actor_5_frame: DW 8
 DB 82,0,4,0,5,0,0,0
actor_5_pos: DW 10
 DB 81,0,6,0,5,0,192,255,112,0
actor_5_enable: DW 7
 DB 85,0,3,0,5,0,1
actor_6_def: DW 16
 DB 80,0,12,0,6,0,5,0,0,0,72,0,64,0,24,0
actor_6_attr: DW 10
 DB 83,0,6,0,6,0,8,0,0,0
actor_6_frame: DW 8
 DB 82,0,4,0,6,0,0,0
actor_6_pos: DW 10
 DB 81,0,6,0,6,0,0,0,0,0
actor_6_enable: DW 7
 DB 85,0,3,0,6,0,1
fence_scene: DW 6
 DB 3,0,2,0,9,0
position_packet: DW 10
 DB 81,0,6,0,0,0,0,0,0,0
frame_packet: DW 8
 DB 82,0,4,0,0,0,0,0
present_packet: DW 7
 DB 4,0,3,0,2,0,0
scroll_main: DW 9
 DB 67,0,5,0,0,0,0,0,0
create_wait: DW 12
 DB 16,0,8,0,6,0,3,0,0,3,0,0
begin_wait: DW 15
 DB 18,0,11,0,6,0,0,0,0,0,0,3,0,0,1
end_wait: DW 10
 DB 19,0,6,0,6,0,57,74,227,26
fence_wait: DW 6
 DB 3,0,2,0,7,0
wait_blob EQU 25166
rescue_map_packet: DW 11
 DB 65,0,7,0,0,6,0,64,0,12,0
rescue_disable_packet: DW 6
 DB 68,0,2,0,0,0
rescue_enable_packet: DW 6
 DB 68,0,2,0,0,1

actor_7_def: DW 16
 DB 80,0,12,0,7,0,5,0,64,0,144,0,24,0,32,0
actor_7_attr: DW 10
 DB 83,0,6,0,7,0,8,0,0,0
actor_7_frame: DW 8
 DB 82,0,4,0,7,0,0,0
actor_7_pos: DW 10
 DB 81,0,6,0,7,0,192,255,144,0
actor_7_enable: DW 7
 DB 85,0,3,0,7,0,1
rope_create: DW 12
 DB 16,0,8,0,7,0,1,0,134,4,0,0
rope_begin: DW 15
 DB 18,0,11,0,7,0,0,0,0,0,134,4,0,0,1
rope_end: DW 10
 DB 19,0,6,0,7,0,249,182,64,207
rope_fence: DW 6
 DB 3,0,2,0,8,0
rope_def: DW 16
 DB 80,0,12,0,3,0,7,0,0,0,0,0,4,0,64,0
rope_attr: DW 10
 DB 83,0,6,0,3,0,8,0,0,0
rope_frame: DW 8
 DB 82,0,4,0,3,0,0,0
rope_pos: DW 10
 DB 81,0,6,0,3,0,128,0,120,0
rope_enable: DW 7
 DB 85,0,3,0,3,0,1
rope_blob: INCBIN "../assets/rope_candidate.rle"
pub03_font:
 DB 0,0,0,0,0,0,0,0 ;  
 DB 0,0,0,56,0,0,0,0 ; -
 DB 4,8,8,16,32,32,64,0 ; /
 DB 16,40,68,124,68,68,68,0 ; A
 DB 28,32,64,64,64,32,28,0 ; C
 DB 112,72,68,68,68,72,112,0 ; D
 DB 124,64,64,112,64,64,124,0 ; E
 DB 124,64,64,112,64,64,64,0 ; F
 DB 60,64,64,76,68,68,60,0 ; G
 DB 68,68,68,124,68,68,68,0 ; H
 DB 56,16,16,16,16,16,56,0 ; I
 DB 68,72,80,96,80,72,68,0 ; K
 DB 64,64,64,64,64,64,124,0 ; L
 DB 68,108,84,84,68,68,68,0 ; M
 DB 68,100,84,76,68,68,68,0 ; N
 DB 56,68,68,68,68,68,56,0 ; O
 DB 120,68,68,120,64,64,64,0 ; P
 DB 56,68,68,68,84,72,52,0 ; Q
 DB 120,68,68,120,80,72,68,0 ; R
 DB 60,64,64,56,4,4,120,0 ; S
 DB 124,16,16,16,16,16,16,0 ; T
 DB 68,68,68,68,68,68,56,0 ; U
 DB 68,68,68,84,84,108,68,0 ; W
 DB 68,68,40,16,40,68,68,0 ; X
 DB 124,4,8,16,32,64,124,0 ; Z
 ASSERT $ <= $10000
