; Experimental rope cycle. Positions are world coordinates until publication.
rope_phase EQU $715C ; 0 stowed, 1 lowering, 2 contact dwell, 3 lifting
rope_length EQU $715D ; units of four pixels
rope_limit EQU $715E
rope_delay EQU $715F
rope_screen EQU $7160
rope_y EQU $7162
rope_frame_gpu EQU $7163
rope_pos_ready EQU $7164
walker_y_gpu EQU $7165

rope_update:
 LD A,(reset_stage)
 OR A
 JP NZ,rope_clear
 LD A,(rope_phase)
 CP 3
 JR Z,rope_lift
 OR A
 JR NZ,rope_check_active
 LD A,(sampled_v_edge)
 OR A
 JP Z,rescue_update
 CALL rope_hover_valid
 JP NZ,rescue_update
 LD A,1
 LD (rope_phase),A
 LD A,4
 LD (rope_delay),A
 LD A,(pos_y)
 LD B,A
 LD A,104 ; 152 hand contact minus 48 door offset
 SUB B
 SRL A
 SRL A
 LD (rope_limit),A
 RET
rope_check_active:
 LD A,(sampled_v_edge)
 OR A
 JR NZ,rope_clear
 CALL rope_hover_valid
 JR NZ,rope_clear
 CALL rope_count_down
 RET NZ
 LD A,(rope_phase)
 CP 2
 JR Z,rope_attach
 LD A,(rope_length)
 INC A
 LD (rope_length),A
 LD B,A
 LD A,(rope_limit)
 CP B
 JR NZ,rope_next_step
 LD A,2
 LD (rope_phase),A
 LD A,8
 LD (rope_delay),A
 LD A,52
 JP rescue_event
rope_attach:
 XOR A
 LD (walk_age),A
 LD (walk_direction),A
 LD HL,525
 LD (walk_x),HL
 LD A,3
 LD (rope_phase),A
 LD (walk_phase),A
 LD A,1
 LD (rescue_state),A
rope_next_step:
 LD A,4
 LD (rope_delay),A
 RET
rope_lift:
 CALL rope_count_down
 RET NZ
 LD A,(rope_length)
 DEC A
 LD (rope_length),A
 JR NZ,rope_next_step
 CALL rope_clear
 XOR A
 LD (walk_phase),A
 LD A,2
 LD (rescue_state),A
 LD A,33
 JP rescue_event
rope_clear:
 XOR A
 LD (rope_phase),A
 LD (rope_length),A
 LD (rope_pos_ready),A
 RET
rope_count_down:
 LD HL,rope_delay
 DEC (HL)
 RET
rope_hover_valid:
 LD A,(rescue_state)
 LD B,A
 LD A,(walk_phase)
 OR B
 LD B,A
 LD A,(damage)
 OR B
 LD B,A
 LD A,(sampled_keys)
 AND 15
 OR B
 RET NZ
 LD A,(orientation)
 CP 2
 RET NZ
 LD A,(pos_y)
 SUB 72
 CP 11 ; both frontal rotor frames clear the prison roof through Y82
 JR NC,rope_invalid
 LD HL,(world_x)
 LD DE,502 ; front door x = anchor + 32, passenger center x537
 OR A
 SBC HL,DE
 JR C,rope_invalid
 LD DE,7
 OR A
 SBC HL,DE
 JR NC,rope_invalid
 XOR A
 RET
rope_invalid:
 OR 1
 RET

; Publication uses only spare commands before PRESENT. The first nonzero
; frame needs a matching position. Never expose a frame at the old position.
render_rope:
 LD A,(rope_length)
 LD B,A
 LD A,(rope_frame_gpu)
 CP B
 RET Z
 LD A,(frame_commands)
 CP 7
 RET NC
 LD A,B
 OR A
 JR Z,rope_publish_frame
 LD A,(rope_pos_ready)
 OR A
 JR NZ,rope_publish_frame
 LD A,(frame_commands)
 CP 6
 RET NC
 LD HL,(world_x)
 LD DE,31
 ADD HL,DE
 LD DE,(camera_x)
 OR A
 SBC HL,DE
 LD A,(pos_y)
 ADD A,48
 LD D,A
 LD A,3
 CALL gpu_position
 LD A,1
 LD (rope_pos_ready),A
rope_publish_frame:
 LD A,(rope_length)
 LD (rope_frame_gpu),A
 LD L,A
 LD A,3
 JP gpu_frame

rope_walker_y:
 LD A,(walk_phase)
 CP 3
 LD A,144
 RET NZ
 LD A,(rope_limit)
 LD B,A
 LD A,(rope_length)
 SUB B
 ADD A,A
 ADD A,A
 ADD A,144
 RET
