; Only real Spectrum IN matrix reads feed this state. No automatic flight path.
; ISR samples at 50 Hz; rising edges are latched until main consumes them.
sample_keyboard:
 LD D,0
 LD BC,$FBFE
 IN A,(C)
 LD (raw_rows),A
 BIT 0,A
 JR NZ,no_q
 SET 0,D
no_q:
 BIT 3,A
 JR NZ,no_r
 SET 7,D
no_r:
 LD BC,$FDFE
 IN A,(C)
 LD (raw_rows+1),A
 BIT 0,A
 JR NZ,no_a
 SET 1,D
no_a:
 BIT 2,A
 JR NZ,no_d
 SET 6,D
no_d:
 LD BC,$DFFE
 IN A,(C)
 LD (raw_rows+2),A
 BIT 1,A
 JR NZ,no_o
 SET 2,D
no_o:
 BIT 0,A
 JR NZ,no_p
 SET 3,D
no_p:
 LD BC,$FEFE
 IN A,(C)
 LD (raw_rows+3),A
 BIT 1,A
 JR NZ,no_z
 SET 4,D
no_z:
 BIT 2,A
 JR NZ,no_x
 SET 5,D
no_x:
 PUSH DE
 LD A,(raw_rows+3)
 CPL
 AND 8
 RRCA
 RRCA
 RRCA
 LD D,A
 LD A,(c_mask)
 CPL
 AND D
 LD B,A
 LD A,(c_edges)
 OR B
 LD (c_edges),A
 LD A,D
 LD (c_mask),A
 LD A,(raw_rows+3)
 CPL
 AND 16
 RRCA
 RRCA
 RRCA
 RRCA
 LD D,A
 LD A,(v_mask)
 CPL
 AND D
 LD B,A
 LD A,(v_edges)
 OR B
 LD (v_edges),A
 LD A,D
 LD (v_mask),A
 POP DE
 ; PC arrows map to Spectrum 5/6/7/8, possibly with Caps Shift.
 ; Accept these numbers independently of Caps so both Fuse settings work.
 LD BC,$F7FE
 IN A,(C)
 LD (raw_rows+4),A
 BIT 4,A
 JR NZ,no_5
 SET 2,D
no_5:
 LD BC,$EFFE
 IN A,(C)
 LD (raw_rows+5),A
 BIT 4,A
 JR NZ,no_6
 SET 1,D
no_6:
 BIT 3,A
 JR NZ,no_7
 SET 0,D
no_7:
 BIT 2,A
 JR NZ,no_8
 SET 3,D
no_8:
 LD A,(key_mask)
 CPL
 AND D
 LD B,A
 LD A,(key_edges)
 OR B
 LD (key_edges),A
 LD A,D
 LD (key_mask),A
 JP sample_fire


update_controls:
 DI
 LD A,(key_mask)
 LD (sampled_keys),A
 LD A,(key_edges)
 LD (sampled_edges),A
 XOR A
 LD (key_edges),A
 LD A,(c_mask)
 LD (sampled_c),A
 LD A,(c_edges)
 LD (sampled_c_edge),A
 XOR A
 LD (c_edges),A
 LD A,(v_mask)
 LD (sampled_v),A
 LD A,(v_edges)
 LD (sampled_v_edge),A
 XOR A
 LD (v_edges),A
 LD A,(fire_mask)
 LD (sampled_fire),A
 LD A,(fire_edges)
 LD (sampled_fire_edges),A
 XOR A
 LD (fire_edges),A
 EI
 XOR A
 LD (reset_stage),A
 LD A,(reset_pending)
 OR A
 JR NZ,apply_staged_reset
 LD A,(sampled_edges)
 BIT 7,A
 JR Z,no_staged_reset
 LD A,1
 LD (reset_stage),A
 LD (reset_pending),A
 XOR A
 LD (vx),A
 LD (vy),A
 LD IY,shots
 LD B,4
reset_cleanup:
 LD (IY+0),A
 LD DE,16
 ADD IY,DE
 DJNZ reset_cleanup
 XOR A
 LD (walk_phase),A
 LD A,38
 CALL rescue_event
 RET
apply_staged_reset:
 CALL center
 XOR A
 LD (reset_pending),A
 LD (vx),A
 LD (vy),A
 LD A,2
 LD (reset_stage),A
 RET
no_staged_reset:
 LD A,(sampled_edges)
 BIT 6,A
 JR Z,damage_done
 LD A,(damage)
 XOR 1
 LD (damage),A
damage_done:
 ; Velocity is derived from held motion keys; opposing inputs cancel.
 ; Heading never writes velocity, and velocity never writes heading.
 XOR A
 LD (vx),A
 LD (vy),A
 LD A,(sampled_edges)
 LD B,A
 LD A,(sampled_keys)
 OR B
 AND 12
 CP 4
 JR Z,velocity_left
 CP 8
 JR NZ,x_velocity_done
 LD A,1
 JR save_vx
velocity_left:
 LD A,$FF
save_vx:
 LD (vx),A
x_velocity_done:
 LD A,(sampled_edges)
 LD B,A
 LD A,(sampled_keys)
 OR B
 AND 3
 CP 1
 JR Z,velocity_up
 CP 2
 JR NZ,y_velocity_done
 LD A,1
 JR save_vy
velocity_up:
 LD A,$FF
save_vy:
 LD (vy),A
y_velocity_done:
 LD A,(walk_phase)
 CP 3
 JP Z,position_update
 LD A,(sampled_edges)
 LD B,A
 LD A,(sampled_keys)
 OR B
 AND $30
 CP $10
 JR Z,heading_left
 CP $20
 JR Z,heading_right
 XOR A
 LD (turn_held),A
 JR position_update
heading_left:
 LD D,$FF
 JR heading_repeat
heading_right:
 LD D,1
heading_repeat:
 LD A,(sampled_edges)
 AND $30
 JR NZ,heading_initial
 LD A,(turn_held)
 CP D
 JR NZ,heading_initial
 LD A,(ticks)
 LD B,A
 LD A,(last_turn)
 LD C,A
 LD A,B
 SUB C
 LD B,A
 LD A,(turn_delay)
 CP B
 JR C,heading_due
 JR Z,heading_due
 JR position_update
heading_initial:
 LD A,D
 LD (turn_held),A
 LD A,12 ; first repeat after >=240 ms emulated
 LD (turn_delay),A
 JR apply_heading
heading_due:
 LD A,6 ; subsequent repeats after >=120 ms emulated
 LD (turn_delay),A
apply_heading:
 LD A,(ticks)
 LD (last_turn),A
 LD A,(orientation)
 ADD A,D
 CP 5
 JR NC,position_update
 LD (orientation),A
position_update:
 LD A,(walk_phase)
 LD (walk_phase_before_input),A
 OR A
 JR Z,walk_not_locked
 XOR A
 LD (vx),A
 LD (vy),A
 RET
walk_not_locked:
 LD HL,(world_x)
 LD A,(vx)
 OR A
 JR Z,world_x_checked
 BIT 7,A
 JR NZ,world_left
 INC HL
 JR world_clip
world_left:
 DEC HL
world_clip:
 PUSH HL
 LD DE,961
 OR A
 SBC HL,DE
 POP HL
 JR C,world_x_checked
 LD A,(vx)
 BIT 7,A
 LD HL,0
 JR NZ,world_x_checked
 LD HL,960
world_x_checked:
 LD (world_x),HL
 LD DE,(camera_x)
 OR A
 SBC HL,DE
 LD A,H
 OR A
 JR NZ,follow_right
 LD A,L
 CP ERGO_CAM_RIGHT+1
 JR NC,follow_right
 CP ERGO_CAM_LEFT
 JR NC,camera_done
 LD HL,(world_x)
 LD DE,ERGO_CAM_LEFT
 OR A
 SBC HL,DE
 JR NC,save_camera
 LD HL,0
 JR save_camera
follow_right:
 LD HL,(world_x)
 LD DE,ERGO_CAM_RIGHT
 OR A
 SBC HL,DE
 PUSH HL
 LD DE,769
 OR A
 SBC HL,DE
 POP HL
 JR C,save_camera
 LD HL,768
save_camera:
 LD (camera_x),HL
camera_done:
 LD HL,(world_x)
 LD DE,(camera_x)
 OR A
 SBC HL,DE
 LD A,L
 LD (pos_x),A
 LD A,(vy)
 LD B,A
 LD A,(pos_y)
 ADD A,B
 CP 20
 JR C,y_top
 CP 113
 JR C,y_in_range
 LD A,112
 JR y_clipped
y_top:
 LD A,20
y_clipped:
 LD B,A
 XOR A
 LD (vy),A
 LD A,B
y_in_range:
 LD (pos_y),A
 RET
center:
 LD HL,96
 LD (world_x),HL
 LD HL,0
 LD (camera_x),HL
 LD A,96
 LD (pos_x),A
 LD A,72
 LD (pos_y),A
 LD A,2
 LD (orientation),A
 XOR A
 LD (damage),A
 CALL reset_combat
 CALL reset_rescue
 RET

isr:
 PUSH AF
 PUSH BC
 PUSH DE
 PUSH HL
 LD HL,(ticks)
 INC HL
 LD (ticks),HL
 CALL sample_keyboard
 POP HL
 POP DE
 POP BC
 POP AF
 EI
 RETI

sample_fire:
 LD BC,$7FFE
 IN A,(C)
 LD (raw_rows+6),A
 CPL
 AND 1
 LD D,A
 LD A,(fire_mask)
 CPL
 AND D
 LD B,A
 LD A,(fire_edges)
 OR B
 LD (fire_edges),A
 LD A,D
 LD (fire_mask),A
 LD BC,$BFFE
 IN A,(C)
 LD (raw_rows+7),A
 BIT 0,A
 RET NZ
 LD A,1
 LD (stop_requested),A
 RET
