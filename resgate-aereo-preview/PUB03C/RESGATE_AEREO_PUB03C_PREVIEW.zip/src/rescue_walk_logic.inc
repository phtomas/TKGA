; Four states: waiting0, boarding1, aboard2, delivered3.
; C rising edge starts an action; ten valid held updates complete it.
reset_rescue:
 XOR A
 LD (walk_phase),A
 LD (walk_age),A
 XOR A
 LD (rescue_state),A
 LD (rescue_dwell),A
 LD (rescued_count),A
 LD (mission_done),A
 LD (rescue_reject),A
 LD A,30
 JP rescue_event

rescue_update:
 LD A,(reset_stage)
 OR A
 RET NZ
 LD A,(walk_phase)
 OR A
 JP NZ,walk_update
 LD A,(sampled_c_edge)
 OR A
 JR Z,rescue_continue
 LD A,(rescue_state)
 CP 3
 LD A,4
 JP Z,rescue_denied
 CALL rescue_valid
 OR A
 JP NZ,rescue_denied
 LD A,(rescue_state)
 OR A
 JR NZ,start_delivery
 LD A,1
 LD (rescue_state),A
 LD A,31
 JR start_action
start_delivery:
 LD A,34
start_action:
 PUSH AF
 XOR A
 LD (rescue_dwell),A
 LD (rescue_reject),A
 POP AF
 CALL rescue_event
 JR action_progress
rescue_continue:
 LD A,(rescue_state)
 CP 1
 JR Z,action_progress
 CP 2
 RET NZ
 LD A,(rescue_dwell)
 OR A
 RET Z
action_progress:
 LD A,(sampled_c)
 OR A
 JR Z,action_cancel
 CALL rescue_valid
 OR A
 JR NZ,action_cancel_reason
 LD A,(rescue_dwell)
 INC A
 LD (rescue_dwell),A
 CP DWELL_UPDATES
 RET C
 XOR A
 LD (rescue_dwell),A
 LD A,(rescue_state)
 CP 1
 JP Z,start_board_walk
 JP start_exit_walk

action_cancel:
 LD A,5 ; released before dwell completed
action_cancel_reason:
 LD (rescue_reject),A
 LD A,(rescue_state)
 CP 1
 LD A,35
 JR NZ,cancel_event
 XOR A
 LD (rescue_state),A
 LD A,32
cancel_event:
 PUSH AF
 XOR A
 LD (rescue_dwell),A
 POP AF
 JP rescue_event
rescue_denied:
 LD (rescue_reject),A
 LD HL,(rescue_rejects)
 INC HL
 LD (rescue_rejects),HL
 LD A,37
 JP rescue_event

; Return A=0 valid,1 far/misaligned,2 high,3 motion.
; No input intent, even at a clipping boundary: release motion keys first.
rescue_valid:
 LD A,(sampled_keys)
 AND 15
 LD B,A
 LD A,(vx)
 OR B
 LD B,A
 LD A,(vy)
 OR B
 LD A,3
 RET NZ
 LD A,(pos_y)
 CP 112
 LD A,2
 RET NZ
 LD HL,(world_x)
 LD A,(rescue_state)
 CP 2
 JR Z,valid_base
 LD DE,PICK_MIN
 OR A
 SBC HL,DE
 JR C,invalid_far
 LD DE,PICK_MAX-PICK_MIN+1
 OR A
 SBC HL,DE
 JR NC,invalid_far
 ; Door hotspot, not the transparent whole64x64 AABB.
 LD A,(orientation)
 LD E,A
 LD D,0
 LD HL,door_offsets
 ADD HL,DE
 LD E,(HL)
 LD HL,(world_x)
 ADD HL,DE
 LD (rescue_hotspot),HL
 LD DE,ERGO_DOOR_MIN ; spatial threshold only; actual door goal unchanged
 OR A
 SBC HL,DE
 JR C,invalid_far
 LD DE,ERGO_DOOR_MAX-ERGO_DOOR_MIN+1
 OR A
 SBC HL,DE
 JR NC,invalid_far
 XOR A
 RET
valid_base:
 LD DE,BASE_MIN
 OR A
 SBC HL,DE
 JR C,invalid_far
 LD DE,BASE_MAX-BASE_MIN+1
 OR A
 SBC HL,DE
 JR NC,invalid_far
 XOR A
 RET
invalid_far:
 LD A,1
 RET
door_offsets: DB 24,32,32,32,40

rescue_event:
 PUSH AF
 LD C,255
 LD HL,(world_x)
 LD A,(pos_y)
 LD B,A
 LD A,(rescue_reject)
 LD C,A
 POP AF
 JP log_event
