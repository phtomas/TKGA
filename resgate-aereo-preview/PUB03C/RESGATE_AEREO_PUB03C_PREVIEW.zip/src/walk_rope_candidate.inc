; Cell24x32: native person is centered at x12; foot on Y176.
; phase1 approach, phase2 exit; positions always world coordinates.
start_board_walk:
 LD A,1
 LD (walk_phase),A
 XOR A
 LD (walk_age),A
 LD (walk_direction),A
 LD HL,525
 LD (walk_x),HL
 CALL current_door_goal
 LD (walk_goal),HL
 LD A,40
 JP rescue_event

start_exit_walk:
 LD A,2
 LD (walk_phase),A
 XOR A
 LD (walk_age),A
 LD (walk_direction),A
 CALL current_door_goal
 LD (walk_x),HL
 LD HL,HANGAR_CENTER-12
 LD (walk_goal),HL
 LD A,41
 JP rescue_event

current_door_goal:
 LD A,(orientation)
 LD E,A
 LD D,0
 LD HL,door_offsets
 ADD HL,DE
 LD E,(HL)
 LD HL,(world_x)
 ADD HL,DE
 LD DE,12
 OR A
 SBC HL,DE
 RET

walk_update:
 LD A,(walk_age)
 CP 255
 JR Z,walk_age_ready
 INC A
 LD (walk_age),A
walk_age_ready:
 LD A,(walk_phase)
 CP 1
 JR NZ,walk_goal_ready
 CALL current_door_goal
 LD (walk_goal),HL
walk_goal_ready:
 LD HL,(walk_x)
 LD DE,(walk_goal)
 PUSH HL
 OR A
 SBC HL,DE
 POP HL
 JR Z,walk_at_door
 JR C,walk_right
 XOR A
 LD (walk_direction),A
 DEC HL
 JR walk_store
walk_right:
 LD A,2
 LD (walk_direction),A
 INC HL
walk_store:
 LD (walk_x),HL
 RET
walk_at_door:
 LD A,(walk_age)
 CP MIN_WALK_UPDATES
 RET C
 LD A,(walk_phase)
 CP 1
 JR NZ,walk_delivered
 XOR A
 LD (walk_phase),A
 LD A,2
 LD (rescue_state),A
 LD A,33
 JP rescue_event
walk_delivered:
 XOR A
 LD (walk_phase),A
 LD A,3
 LD (rescue_state),A
 LD A,1
 LD (rescued_count),A
 LD (mission_done),A
 LD A,36
 JP rescue_event

render_walker:
 LD A,(walk_phase)
 OR A
 LD HL,$FFC0
 JR Z,walker_position
 LD HL,(walk_x)
 LD DE,(camera_x)
 OR A
 SBC HL,DE
walker_position:
 CALL rope_walker_y
 LD B,A
 LD A,(walker_y_gpu)
 CP B
 JR NZ,walker_move
 LD DE,(walk_x_gpu)
 PUSH HL
 OR A
 SBC HL,DE
 POP HL
 JR Z,walker_animation
walker_move:
 LD (walk_x_gpu),HL
 LD A,B
 LD (walker_y_gpu),A
 LD D,A
 LD A,7
 CALL gpu_position
walker_animation:
 LD A,(walk_phase)
 OR A
 LD A,0
 JR Z,walker_frame_ready
 LD A,(walk_age)
 AND 8
 RRCA
 RRCA
 RRCA
 LD B,A
 LD A,(walk_direction)
 ADD A,B
walker_frame_ready:
 LD (walk_frame_want),A
 LD B,A
 LD A,(walk_frame_gpu)
 CP B
 RET Z
 LD A,(walk_phase)
 OR A
 JR Z,walker_optional_frame
 LD A,(walk_frame_gpu)
 XOR B
 AND 2
 JR NZ,walker_apply_frame
walker_optional_frame:
 LD A,(frame_commands)
 CP 7
 RET NC
walker_apply_frame:
 LD A,B
 LD (walk_frame_gpu),A
 LD L,A
 LD A,7
 JP gpu_frame
