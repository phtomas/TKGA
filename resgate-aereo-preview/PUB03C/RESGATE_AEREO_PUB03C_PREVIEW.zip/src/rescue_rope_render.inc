; Select an immutable preloaded map. No tile upload/mutation during play.
render_rescue_map:
 CALL render_hud_position
 LD A,(walk_phase)
 OR A
 LD A,4
 JR NZ,rescue_map_wanted
 LD A,(rescue_state)
 CP 2
 LD A,6
 JR C,rescue_map_wanted
 LD A,4
rescue_map_wanted:
 LD B,A
 LD A,(rescue_map_gpu)
 CP B
 RET Z
 LD A,B
 LD (rescue_map_gpu),A
 LD (rescue_map_packet+7),A
 LD IX,rescue_disable_packet
 CALL send_packet
 LD IX,rescue_map_packet
 CALL send_packet
 LD IX,rescue_enable_packet
 JP send_packet

; One composite HUD sprite replaces the RA05A score sprite.
; No added enabled sprite or per-line load.
render_rescue_hud:
 LD A,(walk_phase)
 CP 3
 LD A,4
 JR Z,walking_hud_state
 LD A,(walk_phase)
 CP 2
 LD A,1
 JR Z,walking_hud_state
 LD A,(rescue_state)
walking_hud_state:
 ADD A,A
 LD B,A
 LD A,(score)
 ADD A,B
 LD (rescue_hud_want),A
 LD B,A
 LD A,(rescue_hud_gpu)
 CP B
 RET Z
 LD A,(frame_commands)
 CP 7
 RET NC
 LD A,B
 LD (rescue_hud_gpu),A
 LD L,A
 LD A,(score)
 LD (score_gpu),A
 LD A,6
 JP gpu_frame

; Completion becomes a persistent central panel. Reset pre-cleans its position.
render_hud_position:
 LD B,0
 LD A,(reset_stage)
 CP 1
 JR Z,hud_pos_wanted
 LD A,(rescue_state)
 CP 3
 JR NZ,hud_pos_wanted
 LD B,96
hud_pos_wanted:
 LD A,(hud_position_gpu)
 CP B
 RET Z
 LD A,B
 LD (hud_position_gpu),A
 LD L,A
 LD H,0
 LD D,0
 OR A
 JR Z,hud_pos_ready
 LD D,64
hud_pos_ready:
 LD A,6
 JP gpu_position
