; RA05B state: outside keyboard, telemetry, code and IM2 areas.
rescue_state EQU $7120
c_mask EQU $7121
c_edges EQU $7122
sampled_c EQU $7123
sampled_c_edge EQU $7124
rescue_dwell EQU $7125
rescued_count EQU $7126
mission_done EQU $7127
rescue_reject EQU $7128
rescue_rejects EQU $7129
rescue_map_gpu EQU $712B
rescue_hud_gpu EQU $712C
rescue_hud_want EQU $712D
rescue_hotspot EQU $712E
auto_c_prev EQU $7130
reset_pending EQU $7133
reset_stage EQU $7134
hud_position_gpu EQU $7135
PERSON_X EQU 528
PERSON_Y EQU 150
; Conservative 64px helicopter footprint remains outside prison/base buildings.
PICK_MIN EQU ERGO_PICK_MIN
PICK_MAX EQU ERGO_PICK_MAX
BASE_MIN EQU 128
BASE_MAX EQU 144
DWELL_UPDATES EQU 10
