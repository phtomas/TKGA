; PackBits to normal TKGA DATA stream. IX input, DE exact output length.
upload_packed:
 LD A,(IX+0)
 INC IX
 LD B,A
 AND 127
 INC A
 LD C,A
 BIT 7,B
 JR Z,packed_literal
 LD A,(IX+0)
 INC IX
 LD B,C
 LD C,A
packed_run:
 LD A,C
 PUSH BC
 CALL put_data
 POP BC
 DEC DE
 DJNZ packed_run
 JR packed_next
packed_literal:
 LD B,C
packed_literal_loop:
 LD A,(IX+0)
 INC IX
 PUSH BC
 CALL put_data
 POP BC
 DEC DE
 DJNZ packed_literal_loop
packed_next:
 LD A,D
 OR E
 JR NZ,upload_packed
 RET

; Log event A=code,C=slot,HL=worldX,B=Y. Separate ring seqlock, CPU-owned only.
log_event:
 PUSH AF
 PUSH BC
 PUSH DE
 PUSH HL
 PUSH IX
 LD (event_code),A
 LD (event_x),HL
 LD A,B
 LD (event_y),A
 LD A,C
 LD (event_slot),A
 LD HL,(event_epoch)
 INC HL
 LD (event_epoch),HL
 LD HL,(event_seq)
 INC HL
 LD (event_seq),HL
 LD A,L
 AND 31
 LD L,A
 LD H,0
 ADD HL,HL
 ADD HL,HL
 ADD HL,HL
 ADD HL,HL
 LD DE,$7500
 ADD HL,DE
 PUSH HL
 POP IX
 LD HL,(event_seq)
 LD (IX+0),L
 LD (IX+1),H
 LD HL,(logic_counter)
 LD (IX+2),L
 LD (IX+3),H
 LD A,(event_code)
 LD (IX+4),A
 LD A,(event_slot)
 LD (IX+5),A
 LD HL,(event_x)
 LD (IX+6),L
 LD (IX+7),H
 LD A,(event_y)
 LD (IX+8),A
 LD A,(orientation)
 LD (IX+9),A
 LD A,(target_state)
 LD (IX+10),A
 LD A,(score)
 LD (IX+11),A
 LD HL,(generation)
 LD (IX+12),L
 LD (IX+13),H
 LD A,(rescue_state)
 LD (IX+14),A
 LD A,(rescued_count)
 LD (IX+15),A
 PUSH IX
 POP HL
 LD DE,last_event
 LD BC,16
 LDIR
 LD HL,(event_epoch)
 INC HL
 LD (event_epoch),HL
 POP IX
 POP HL
 POP DE
 POP BC
 POP AF
 RET

init_combat:
 LD HL,$FFFF
 LD (heli_gpu_x),HL
 LD (target_gpu_x),HL
 LD A,255
 LD (heli_gpu),A
 LD (heli_gpu_y),A
 LD (heli_ori_gpu),A
 LD (heli_damage_gpu),A
 LD (target_gpu),A
 LD (score_gpu),A
 LD IY,shots
 LD B,4
init_shot_loop:
 XOR A
 LD (IY+0),A
 LD (IY+11),A
 LD (IY+8),$FF
 LD (IY+9),$7F
 LD DE,16
 ADD IY,DE
 DJNZ init_shot_loop
 RET

reset_combat:
 XOR A
 LD (score),A
 LD (score+1),A
 LD (target_state),A
 LD (target_want),A
 LD (target_timer),A
 LD (cooldown),A
 LD (pending_age),A
 LD IY,shots
 LD B,4
reset_shot_loop:
 LD (IY+0),A
 LD DE,16
 ADD IY,DE
 DJNZ reset_shot_loop
 LD HL,(generation)
 INC HL
 LD (generation),HL
 LD HL,(world_x)
 LD A,(pos_y)
 LD B,A
 LD C,255
 LD A,1
 CALL log_event
 RET

combat_update:
 LD A,(reset_stage)
 OR A
 RET NZ
 IF COMBAT
 LD A,(target_state)
 CP 2
 JR NZ,target_timer_done
 LD A,(target_timer)
 OR A
 JR Z,end_explosion
 DEC A
 LD (target_timer),A
 JR NZ,target_timer_done
end_explosion:
 LD A,3
 LD (target_state),A
 LD A,2
 LD (target_want),A
 LD A,8
 LD HL,640
 LD B,112
 LD C,255
 CALL log_event
target_timer_done:
 LD A,(cooldown)
 OR A
 JR Z,cooldown_done
 DEC A
 LD (cooldown),A
cooldown_done:
 CALL move_shots
 CALL maybe_fire
 ENDIF
 RET

move_shots:
 LD IY,shots
 XOR A
 LD (pool_index),A
move_shot_loop:
 LD A,(IY+0)
 OR A
 JP Z,next_moving_shot
 LD L,(IY+2)
 LD H,(IY+3)
 LD E,(IY+1)
 LD D,0
 BIT 7,E
 JR Z,shot_sign_ready
 DEC D
shot_sign_ready:
 ADD HL,DE
 LD (IY+2),L
 LD (IY+3),H
 BIT 7,H
 JP NZ,shot_world_end
 PUSH HL
 LD DE,1024
 OR A
 SBC HL,DE
 POP HL
 JP NC,shot_world_end
 LD A,(target_state)
 OR A
 JR NZ,shot_no_hit
 ; Target world AABB [648,698)x[156,174), projectile [x,x+16)x[y,y+8).
 LD DE,16
 ADD HL,DE
 LD DE,648
 OR A
 SBC HL,DE
 JR C,shot_no_hit
 JR Z,shot_no_hit
 LD L,(IY+2)
 LD H,(IY+3)
 LD DE,698
 OR A
 SBC HL,DE
 JR NC,shot_no_hit
 LD A,(IY+4)
 CP 174
 JR NC,shot_no_hit
 ADD A,8
 CP 157
 JR C,shot_no_hit
 XOR A
 LD (IY+0),A
 LD A,1
 LD (target_state),A
 LD (target_want),A
 LD (score),A
 LD HL,(total_hits)
 INC HL
 LD (total_hits),HL
 LD HL,(logic_counter)
 LD (target_hit_tick),HL
 LD A,4
 JP shot_event
shot_no_hit:
 LD A,(IY+5)
 DEC A
 LD (IY+5),A
 JR Z,shot_ttl_end
 LD L,(IY+2)
 LD H,(IY+3)
 LD DE,(camera_x)
 OR A
 SBC HL,DE
 BIT 7,H
 JR Z,shot_positive_screen
 LD A,H
 CP $FF
 JR NZ,shot_offscreen_end
 LD A,L
 CP 160 ; x < -96 => right edge before viewport-64
 JR C,shot_offscreen_end
 JP next_moving_shot
shot_positive_screen:
 LD DE,321
 OR A
 SBC HL,DE
 JR NC,shot_offscreen_end
 JP next_moving_shot
shot_ttl_end:
 LD HL,(ttl_expired)
 INC HL
 LD (ttl_expired),HL
 LD A,5
 JR kill_shot
shot_world_end:
 LD HL,(world_expired)
 INC HL
 LD (world_expired),HL
 LD A,6
 JR kill_shot
shot_offscreen_end:
 LD HL,(offscreen_expired)
 INC HL
 LD (offscreen_expired),HL
 LD A,7
kill_shot:
 LD (IY+14),A
 PUSH AF
 XOR A
 LD (IY+0),A
 POP AF
shot_event:
 LD L,(IY+2)
 LD H,(IY+3)
 LD B,(IY+4)
 PUSH AF
 LD A,(pool_index)
 LD C,A
 POP AF
 CALL log_event
next_moving_shot:
 LD DE,16
 ADD IY,DE
 LD A,(pool_index)
 INC A
 LD (pool_index),A
 CP POOL
 JP C,move_shot_loop
 RET

maybe_fire:
 LD A,(sampled_fire_edges)
 LD B,A
 LD A,(sampled_fire)
 OR B
 OR A
 RET Z
 LD A,(orientation)
 CP 2
 JR NZ,fire_side
 LD HL,(front_reject)
 INC HL
 LD (front_reject),HL
 LD A,(sampled_fire_edges)
 OR A
 RET Z
 LD A,3
 LD C,255
 LD HL,(world_x)
 LD B,0
 JP log_event
fire_side:
 LD A,(cooldown)
 OR A
 RET NZ
 LD A,(orientation)
 CP 2
 LD A,3
 LD B,0
 JR NC,fire_dir_ready
 LD A,$FD
 LD B,1
fire_dir_ready:
 LD (fire_direction),A
 LD A,B
 LD (fire_frame),A
 LD IY,shots
 XOR A
 LD (pool_index),A
find_free_shot:
 LD A,(IY+0)
 OR A
 JR Z,spawn_shot
 LD DE,16
 ADD IY,DE
 LD A,(pool_index)
 INC A
 LD (pool_index),A
 CP POOL
 JR C,find_free_shot
 LD HL,(pool_reject)
 INC HL
 LD (pool_reject),HL
 RET
spawn_shot:
 LD A,(orientation)
 LD L,A
 LD H,0
 LD DE,muzzle_x
 ADD HL,DE
 LD E,(HL)
 LD D,0
 LD HL,(world_x)
 ADD HL,DE
 LD A,(fire_frame)
 OR A
 JR Z,muzzle_world_ready
 LD DE,16
 OR A
 SBC HL,DE
muzzle_world_ready:
 BIT 7,H
 RET NZ
 PUSH HL
 LD DE,1024
 OR A
 SBC HL,DE
 POP HL
 RET NC
 LD (IY+2),L
 LD (IY+3),H
 LD A,(orientation)
 LD E,A
 LD D,0
 LD HL,muzzle_y
 ADD HL,DE
 LD A,(pos_y)
 ADD A,(HL)
 SUB 4
 LD (IY+4),A
 LD A,1
 LD (IY+0),A
 LD A,(fire_direction)
 LD (IY+1),A
 LD A,(fire_frame)
 LD (IY+12),A
 LD A,48
 LD (IY+5),A
 LD A,(orientation)
 LD (IY+13),A
 XOR A
 LD (IY+14),A
 LD HL,(logic_counter)
 LD (IY+6),L
 LD (IY+7),H
 LD HL,(shots_total)
 INC HL
 LD (shots_total),HL
 LD A,8
 LD (cooldown),A
 LD A,2
 LD L,(IY+2)
 LD H,(IY+3)
 LD B,(IY+4)
 PUSH AF
 LD A,(pool_index)
 LD C,A
 POP AF
 CALL log_event
 RET
muzzle_x: DB 8,10,0,54,56
muzzle_y: DB 50,47,0,47,50
