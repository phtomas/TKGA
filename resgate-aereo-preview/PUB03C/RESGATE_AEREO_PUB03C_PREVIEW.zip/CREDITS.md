# Créditos

**Resgate Aéreo — criação, concepção, coordenação e desenvolvimento dirigido por José Albuquerque**, com assistência de IA.

Tipografia original 5×7 da PUB03 e arte procedural criada para PUB03B. Os PNGs e o GIF mostram saídas reais de emulação, com atribuição e identificação por hash. A distribuição PUB03C adiciona receita independente e avisos de copyleft. Preserve os avisos, a indicação de alterações e os créditos conforme as licenças aplicáveis. Fuse, libspectrum, SjASMPlus, Pillow e demais dependências têm seus créditos upstream.
