# Licenças desta distribuição

| Componente | Licença |
|---|---|
| Código próprio Assembly e Python em src/ e tools/ | GPL-3.0-or-later |
| Arte independente da PUB03B, recursos visuais isolados, capturas em media/ e documentação nova | CC BY-SA 4.0, mantido o crédito |
| TAP integrado em dist/resgate-aereo-pub03b.tap | GPLv3 para a adaptação integrada desta distribuição, com os avisos sobre a arte de origem preservados |

A adaptação do jogo organiza os desenhos originais em cenas, estados visuais e animações e os integra ao panorama, à corda, ao HUD e ao código que os utiliza. Parte dos recursos do jogo fica no bloco auxiliar e parte fica embutida no mesmo bloco CODE que o programa. O licenciamento da adaptação integrada usa a compatibilidade unidirecional da CC BY-SA 4.0 para a versão 3 da GPL. A mera compressão ou conversão técnica não é tratada como a adaptação. O crédito e a licença CC BY-SA 4.0 da arte separada permanecem. Nenhuma licença adicional é reivindicada sobre recursos de terceiros. [Compatibilidade oficial](https://creativecommons.org/compatible-licenses/) · [Condições para a adaptação integrada](https://wiki.creativecommons.org/wiki/ShareAlike_compatibility%3A_GPLv3) · [Texto CC BY-SA](https://creativecommons.org/licenses/by-sa/4.0/legalcode.en)

A fonte correspondente contém o ASM, o gerador procedural e sua fonte de desenho, a tipografia, os codificadores e a receita que produz os bytes do TAP. A GPL rege as obrigações do distribuidor. O uso e as alterações privadas podem permanecer privados. [Texto GPLv3](LICENSES/GPL-3.0.txt)

SjASMPlus, Python, Pillow, Fuse e suas dependências mantêm os termos próprios. Para reproduzir o runtime, utilize insumos lícitos e obtenha uma ROM de uso autorizado. A arte RA01, glifos da ROM, ROM, ferramentas binárias e assets antigos ficaram fora da seleção.
