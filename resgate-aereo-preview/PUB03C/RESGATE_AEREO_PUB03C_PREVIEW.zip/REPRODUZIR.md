# Reconstruir e executar o TAP

Use Python 3, Pillow da versão em [requirements.txt](requirements.txt) e um SjASMPlus 1.21.0 obtido do projeto do montador. A pasta de saída precisa estar livre. [SjASMPlus](https://github.com/z00m128/sjasmplus) · [Pillow](https://pypi.org/project/pillow/)

    python tools/build.py --assembler CAMINHO_SJASMPLUS --out BUILD_NOVO

O script regenera 15 arquivos a partir do gerador de arte e da própria tipografia, confronta o hash de cada recurso, verifica dados INDEX4/PackBits, tamanhos, CRC32 e os seis blocos TAP. O loader carrega o auxiliar em 0x5E00 e o código em 0x7B00. O arquivo resultante é BUILD_NOVO/build/resgate_ra05e_autorun.tap, 22.227 bytes. Confira o SHA com [BUILD-IDENTITIES.json](BUILD-IDENTITIES.json) e a cópia em dist. O processo de build é independente de ROM.

Para executar, reconstrua o Fuse-TKGA experimental da PUB03C com sua própria receita. Use a ROM 48K de uso lícito, as dependências locais do emulador e o TAP deste ZIP. No diretório em que o Fuse encontre seus próprios recursos use:

    fuse.exe --machine 48 --tkga-experimental --tape dist/resgate-aereo-pub03b.tap --auto-load

A opção de auto-load deve estar habilitada. Nas condições do ensaio o primeiro quadro e a entrada do jogo exigem dezenas de segundos em tempo emulado porque os recursos são enviados pelo Z80. Após o boot, use os [controles](README.md). O runner diagnóstico usado para registrar o roteiro e o Fuse privado das capturas pertencem ao histórico de validação da PUB03B.
