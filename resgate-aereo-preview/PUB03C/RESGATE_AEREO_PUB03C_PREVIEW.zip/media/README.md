# Capturas reais da PUB03B

cover.png, screen-startup.png e screen-gameplay.png registram o TAP interativo. fixture-screen-lift.png e fixture-voo-e-icamento.gif registram a fixture automatizada, em outro TAP com o mesmo jogo e a mesma arte. O GIF é silencioso, formado por RGB observado e temporização emulada. A mídia dispensa autorização sobre a prancha RA01 porque o traço visual é da arte procedural PUB03B. O recibo distingue as duas identidades. [Dados de captura](CAPTURE-IDENTITIES.json) · [Créditos](../CREDITS.md)
