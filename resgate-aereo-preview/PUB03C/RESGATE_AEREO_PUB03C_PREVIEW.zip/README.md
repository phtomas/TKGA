# Resgate Aéreo · prévia PUB03B, distribuição PUB03C

**Prévia experimental de voo e resgate para Fuse-TKGA.** A arte e a tipografia foram desenhadas para esta variante. O arquivo em dist é um TAP autorun. Use a extensão Fuse-TKGA PUB03C, uma ROM Spectrum 48K de uso lícito fornecida pelo testador e a receita de [execução](REPRODUZIR.md).

- Q/A sobe ou desce. O/P desloca lateralmente. Z/X gira.
- V aciona a corda e cancela antes do contato, quando aplicável.
- C é usado no resgate pousado e na entrega na base. R reinicia.
- Pouse à direita do hangar para completar a entrega.

Boot e entrada do jogo foram ensaiados em emulação. O roteiro automatizado confirma voo, içamento, caminhada, entrega e reset no escopo do [recibo](TEST-RECEIPT.json). A nova variante tem teclado humano e TK físico registrados como NOT_RUN. O GIF mostra uma variante automatizada, identificada por SHA em [CAPTURE-IDENTITIES](media/CAPTURE-IDENTITIES.json).

[Licenças](LICENSES.md) · [Créditos](CREDITS.md) · [Reconstruir o TAP](REPRODUZIR.md)
