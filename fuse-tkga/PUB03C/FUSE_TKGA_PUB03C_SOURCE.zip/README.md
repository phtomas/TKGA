# Fuse-TKGA · prévia de código-fonte PUB03C

Extensão experimental da TKGA para o emulador Fuse 1.6.0 com libspectrum 1.5.0. A convenção de portas do emulador é experimental. O Core PC10 fornece a implementação da ABI lógica RC1.1.

Use [REPRODUZIR](REPRODUZIR.md) para obter os dois tarballs oficiais, verificar os hashes, aplicar os patches e montar a aplicação Win32. O ZIP distribui fontes, patches e receitas. Prepare localmente os binários de teste e forneça uma cópia lícita da ROM Spectrum 48K para executar os exemplos. Veja [licenças](LICENSES.md), [créditos](CREDITS.md) e [ensaios](TEST-RECEIPT.json).
