; F4B/F4C canonical A then B, independent of test harness and host RAM gates.
; Reuses validated F5A IM2 emulated interrupts for one second of visible A.
 INCLUDE "../../sdk/tkga_fuse_exp.inc"
 ORG $8000
 DI
 LD SP,$7FFF
 CALL detect
 JP C,failed
 XOR A
 LD (ticks),A
 LD HL,$7E00
 LD DE,$7E01
 LD BC,256
 LD (HL),$7D
 LDIR
 LD A,$C3
 LD ($7D7D),A
 LD HL,isr
 LD ($7D7E),HL
 LD A,$7E
 LD I,A
 IM 2
 EI
 LD IX,create1
 CALL send_packet
 LD IX,begin1
 CALL send_packet
wait_upload1:
 LD A,$40
 CALL read16
 LD A,$47
 CALL read16
 LD A,L
 CP 1
 JP NZ,wait_upload1
 LD IX,blob1
 LD DE,38
data1:
 LD A,(IX+0)
 CALL put_data
 INC IX
 DEC DE
 LD A,D
 OR E
 JR NZ,data1
 LD IX,end1
 CALL send_packet
 LD IX,fence1
 CALL send_packet
 LD DE,1
 CALL wait_fence
 LD IX,create2
 CALL send_packet
 LD IX,begin2
 CALL send_packet
wait_upload2:
 LD A,$40
 CALL read16
 LD A,$47
 CALL read16
 LD A,L
 CP 1
 JP NZ,wait_upload2
 LD IX,blob2
 LD DE,38
data2:
 LD A,(IX+0)
 CALL put_data
 INC IX
 DEC DE
 LD A,D
 OR E
 JR NZ,data2
 LD IX,end2
 CALL send_packet
 LD IX,fence2
 CALL send_packet
 LD DE,2
 CALL wait_fence
 LD IX,config0
 CALL send_packet
 LD IX,config1
 CALL send_packet
 LD IX,config2
 CALL send_packet
 LD IX,config3
 CALL send_packet
 LD IX,config4
 CALL send_packet
 LD IX,config5
 CALL send_packet
 LD IX,config6
 CALL send_packet
 LD IX,present_a
 CALL send_packet
 LD DE,$1234
 CALL wait_present
 LD A,(ticks)
 LD (started),A
dwell:
 HALT
 LD A,(ticks)
 LD HL,started
 SUB (HL)
 CP 50
 JR C,dwell
 LD HL,$1234
 CALL ack_hl
 LD A,$40
 CALL read16
 BIT 0,H
 JP NZ,failed
 LD IX,bind_b
 CALL send_packet
 LD IX,present_b
 CALL send_packet
 LD DE,$1235
 CALL wait_present
 LD HL,$1235
 CALL ack_hl
 LD A,$40
 CALL read16
 BIT 0,H
 JP NZ,failed
 LD A,$43
 CALL read16
 LD A,L
 OR A
 JP NZ,failed
 LD A,5
 OUT ($FE),A
done:
 HALT
 JR done
failed:
 LD A,2
 OUT ($FE),A
 DI
 HALT
 JP failed
wait_fence:
 LD A,$40
 CALL read16
 LD A,$45
 CALL read16
 OR A
 SBC HL,DE
 JR NZ,wait_fence
 RET
wait_present:
 LD A,$40
 CALL read16
 BIT 0,H
 JR Z,wait_present
 LD A,$46
 CALL read16
 OR A
 SBC HL,DE
 JR NZ,wait_present
 LD A,$43
 CALL read16
 LD A,L
 OR A
 JP NZ,failed
 RET
isr:
 PUSH AF
 LD A,(ticks)
 INC A
 LD (ticks),A
 POP AF
 EI
 RETI
ticks: DB 0
started: DB 0
 INCLUDE "../../sdk/helpers.inc"
create1: DW 12
 DB 16,0,8,0,1,0,4,0,38,0,0,0
begin1: DW 15
 DB 18,0,11,0,1,0,0,0,0,0,38,0,0,0,0
end1: DW 10
 DB 19,0,6,0,1,0,0,0,0,0
fence1: DW 6
 DB 3,0,2,0,1,0
blob1: DB 1,1,8,0,8,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
create2: DW 12
 DB 16,0,8,0,2,0,4,0,38,0,0,0
begin2: DW 15
 DB 18,0,11,0,2,0,0,0,0,0,38,0,0,0,0
end2: DW 10
 DB 19,0,6,0,2,0,0,0,0,0
fence2: DW 6
 DB 3,0,2,0,2,0
blob2: DB 1,1,8,0,8,0,51,51,34,34,51,51,34,34,51,51,34,34,51,51,34,34,51,51,68,68,51,51,68,68,51,51,68,68,17,51,68,68
config0: DW 22
 DB 32,0,18,0,0,0,5,0,0,0,255,0,0,0,255,0,0,0,255,255,255,0
config1: DW 8
 DB 48,0,4,0,1,1,0,0
config2: DW 6
 DB 1,0,2,0,1,0
config3: DW 8
 DB 49,0,4,0,1,0,0,255
config4: DW 16
 DB 50,0,12,0,1,0,0,0,0,4,0,8,0,255,0,0
config5: DW 16
 DB 50,0,12,0,1,0,0,0,0,2,0,3,0,0,255,0
config6: DW 16
 DB 50,0,12,0,1,7,0,6,0,1,0,1,0,255,255,0
present_a: DW 7
 DB 4,0,3,0,52,18,0
bind_b: DW 8
 DB 48,0,4,0,1,2,0,0
present_b: DW 7
 DB 4,0,3,0,53,18,0
