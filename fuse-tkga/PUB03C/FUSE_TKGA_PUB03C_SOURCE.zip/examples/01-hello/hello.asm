; Hello: full signature, versions and feature CAPS as hexadecimal screen text.
; Spectrum 48K ROM character set; no TKGA commands or host injection.
 INCLUDE "../../sdk/tkga_fuse_exp.inc"
 ORG $8000
 DI
 LD SP,$7FFF
 XOR A
 LD HL,$4000
 LD DE,$4001
 LD BC,6143
 LD (HL),A
 LDIR
 LD HL,$5800
 LD DE,$5801
 LD BC,767
 LD (HL),7
 LDIR
 CALL detect
 JP C,absent
 LD DE,$4000
 LD IX,title
 CALL text
 LD DE,$4020
 LD IX,if_text
 CALL text
 LD A,TKGA_FUSE_EXP_REG_IF_VERSION
 CALL read16
 CALL hex16
 LD DE,$4040
 LD IX,cmd_text
 CALL text
 LD A,TKGA_FUSE_EXP_REG_CMDSET_VERSION
 CALL read16
 CALL hex16
 LD DE,$4060
 LD IX,caps_text
 CALL text
 LD A,TKGA_FUSE_EXP_REG_CAPS_FEATURES
 CALL read16
 CALL hex16
 LD A,5
 OUT ($FE),A
stop:
 HALT
 JP stop
absent:
 LD DE,$4000
 LD IX,no_text
 CALL text
 LD A,2
 OUT ($FE),A
 JP stop
text:
 LD A,(IX+0)
 OR A
 RET Z
 INC IX
 CALL character
 JR text
; DE points at first pixel byte, text occupies rows within first screen third.
character:
 PUSH HL
 PUSH BC
 LD L,A
 LD H,0
 ADD HL,HL
 ADD HL,HL
 ADD HL,HL
 LD BC,$3C00
 ADD HL,BC
 LD B,8
char_row:
 LD A,(HL)
 LD (DE),A
 INC HL
 INC D
 DJNZ char_row
 LD A,D
 SUB 8
 LD D,A
 INC E
 POP BC
 POP HL
 RET
hex16:
 LD A,H
 CALL hex8
 LD A,L
hex8:
 PUSH AF
 RRCA
 RRCA
 RRCA
 RRCA
 CALL nibble
 POP AF
nibble:
 AND 15
 ADD A,'0'
 CP ':'
 JR C,digit
 ADD A,7
digit:
 JP character
title: DB "TKGA SIGNATURE OK",0
if_text: DB "IF VERSION: ",0
cmd_text: DB "CMDSET: ",0
caps_text: DB "CAPS: ",0
no_text: DB "TKGA NOT AVAILABLE",0
 INCLUDE "../../sdk/helpers.inc"
