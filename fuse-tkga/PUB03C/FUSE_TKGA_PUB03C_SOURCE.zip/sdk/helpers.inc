; EXPERIMENTAL / NOT FINAL TKX HARDWARE ABI
; F5A algorithms with test counters removed. Single producer, interrupts do not use TKGA.
; read16: A=selector -> HL; destroys AF,BC. STATUS first refreshes dynamic values.
read16:
 LD BC,TKGA_FUSE_EXP_PORT_REG_SELECT8
 OUT (C),A
 INC B
 IN A,(C)
 LD L,A
 IN A,(C)
 LD H,A
 RET
; detect: validates ALL four bytes, carry=absent; destroys AF,BC,HL,DE.
detect:
 XOR A
 CALL read16
 LD DE,$4B54
 OR A
 SBC HL,DE
 JR NZ,missing
 IN A,(C)
 CP $47
 JR NZ,missing
 IN A,(C)
 CP $41
 JR NZ,missing
 OR A
 RET
missing:
 SCF
 RET
; IX -> DW wire_length followed by complete packet. Destroys AF,BC,DE,HL,IX.
send_packet:
 LD E,(IX+0)
 LD D,(IX+1)
 INC IX
 INC IX
credit_cmd:
 LD A,TKGA_FUSE_EXP_REG_STATUS
 CALL read16
 LD A,TKGA_FUSE_EXP_REG_CMD_FREE
 CALL read16
 OR A
 SBC HL,DE
 JR C,credit_cmd
 LD BC,TKGA_FUSE_EXP_PORT_CMD_WRITE8
command_byte:
 LD A,(IX+0)
 OUT (C),A
 INC IX
 DEC DE
 LD A,D
 OR E
 JR NZ,command_byte
 RET
; A=data byte. Preserves DE,IX; destroys AF,BC,HL. Stack holds byte while waiting.
put_data:
 PUSH AF
credit_data:
 LD A,TKGA_FUSE_EXP_REG_STATUS
 CALL read16
 LD A,TKGA_FUSE_EXP_REG_DATA_FREE
 CALL read16
 LD A,H
 OR L
 JR Z,credit_data
 POP AF
 LD BC,TKGA_FUSE_EXP_PORT_DATA_WRITE8
 OUT (C),A
 RET
; HL=tag; select ONCE, low then high, no reads/reselection between bytes.
ack_hl:
 PUSH HL
 LD BC,TKGA_FUSE_EXP_PORT_REG_SELECT8
 LD A,TKGA_FUSE_EXP_REG_FRAME_ACK
 OUT (C),A
 LD BC,TKGA_FUSE_EXP_PORT_REG_WRITE8
 POP HL
 LD A,L
 OUT (C),A
 LD A,H
 OUT (C),A
 RET
