# Créditos

**TKGA/TKX — concepção, coordenação e desenvolvimento dirigido por José Albuquerque**, com assistência de IA. Preserve a atribuição da produção original junto aos avisos de licença e alterações. Os titulares e colaboradores identificados no upstream permanecem creditados em [Fuse AUTHORS](licenses/fuse/AUTHORS) e [libspectrum AUTHORS](licenses/libspectrum/AUTHORS).

O frontend, o Core e os exemplos RC1.1 são contribuições do projeto TKGA. A identificação por arquivo está no manifesto. Philip Kendall, Alistair Cree e demais autores upstream conservam seus avisos nos arquivos afetados. O crédito de coordenação do TKGA identifica sua contribuição ao projeto.
