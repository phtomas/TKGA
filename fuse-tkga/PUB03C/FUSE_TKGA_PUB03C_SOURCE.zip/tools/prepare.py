#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-2.0-or-later
"""Prepare the exact Fuse/core inputs from this source package and official tarballs."""
from argparse import ArgumentParser
from hashlib import sha256
from pathlib import Path, PurePosixPath
import json
import subprocess
import tarfile

PACKAGE = Path(__file__).resolve().parents[1]


def digest(data):
    return sha256(data).hexdigest()


def write(p, data):
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open("xb") as f:
        f.write(data)


def entries(path):
    result = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        dg, item = line.split("  ", 1)
        rel = PurePosixPath(item)
        assert len(dg) == 64 and not rel.is_absolute() and '..' not in rel.parts
        assert item not in result
        result[item] = dg
    return result


def extract(tar, sha, prefix, dest):
    assert digest(tar.read_bytes()) == sha, tar.name
    excluded = []
    with tarfile.open(tar) as archive:
        for member in archive:
            name = PurePosixPath(member.name)
            assert name.parts[0] == prefix and '..' not in name.parts and not name.is_absolute()
            rel = name.relative_to(prefix)
            if member.isdir():
                continue
            assert member.isfile()
            if rel.suffix.lower() in {".rom", ".sna", ".z80"}:
                excluded.append(rel.as_posix())
                continue
            write(dest / rel.as_posix(), archive.extractfile(member).read())
    return excluded


def main():
    p = ArgumentParser(description=__doc__)
    p.add_argument("--upstream", required=True, type=Path, help="Folder holding the two official tarballs")
    p.add_argument("--patch-exe", required=True, type=Path, help="Installed patch executable/org")
    p.add_argument("--out", required=True, type=Path, help="New output folder")
    args = p.parse_args()
    out = args.out.resolve()
    out.mkdir(exist_ok=False)
    rules = json.loads((PACKAGE / "VERIFICACAO_COMBINACAO.json").read_text(encoding="utf-8"))
    archive_hashes = entries(PACKAGE / "UPSTREAM_SHA256SUMS.txt")
    patches = entries(PACKAGE / "PATCH_SHA256SUMS.txt")
    core = entries(PACKAGE / "CORE_SHA256SUMS.txt")
    assert len(core) == 12
    result = {"upstream": {}, "patches": [], "core": {}}
    for item, directory in [("fuse-1.6.0", "fuse-src"), ("libspectrum-1.5.0", "libspectrum-src")]:
        archive = item + ".tar.gz"
        omitted = extract(args.upstream / archive, archive_hashes[archive], item, out / directory)
        result["upstream"][archive] = {"sha256": archive_hashes[archive], "omitted": omitted}
    fs = out / "fuse-src"
    for index, name in enumerate(rules["patch_order"]):
        data = (PACKAGE / name).read_bytes()
        assert digest(data) == patches[name]
        task = subprocess.run([str(args.patch_exe.resolve()), "-p1"], input=data, cwd=fs, capture_output=True)
        write(out / f"patch-{index + 1}.log", task.stdout + task.stderr)
        assert task.returncode == 0, name
        result["patches"].append({"file": name, "sha256": patches[name], "exit": task.returncode})
        if index == 0:
            assert len(rules["dp01_paths"]) == 21
            for file, dg in rules["dp01_paths"].items():
                assert digest((fs / file).read_bytes()) == dg, file
    for file, dg in rules["pub03c_paths"].items():
        assert digest((fs / file).read_bytes()) == dg, file
    for file in rules["generated_upstream"]:
        old = fs / file
        data = old.read_bytes()
        assert digest(data) == rules["generated_upstream"][file], file
        write(out / "upstream-generated" / file, data)
        old.unlink()
    for file, dg in core.items():
        assert file.startswith("core/")
        data = (PACKAGE / file).read_bytes()
        assert digest(data) == dg
        write(out / "tkga-core" / file.removeprefix("core/"), data)
        result["core"][file] = dg
    assert not list((out / "tkga-core").rglob("*.txt"))
    assert not list(fs.rglob("*.rom"))
    write(out / "PREPARE_RECEIPT.json", (json.dumps(result, indent=2) + "\n").encode())
    print("PATCH", len(rules["dp01_paths"]), "CORE", len(core), "applied and verified")


if __name__ == "__main__":
    main()
