#!/usr/bin/env bash
# SPDX-License-Identifier: GPL-2.0-or-later
# Derived from the local PUB03 Win32 recipe. All paths come from arguments/env.
set -euo pipefail
source="$1"
build="$2"
prefix="$3"
: "${PUB03B_WINDRES:?point to GNU windres available in your MinGW toolchain}"
export LC_ALL=C
export CC=i686-w64-mingw32-clang CXX=i686-w64-mingw32-clang++
export AR=i686-w64-mingw32-ar RANLIB=i686-w64-mingw32-ranlib
export CFLAGS='-g -O2 -std=gnu11 -DWINVER=0x0500 -D_WIN32_WINNT=0x0501 -D_WIN32_IE=0x501 -include ws2tcpip.h'
export CXXFLAGS='-g -O2'
export WINDRES="$PUB03B_WINDRES --preprocessor=\"i686-w64-mingw32-clang -E -xc -DRC_INVOKED\""
export TKGA_CORE_DIR="$source/tkga-core"
test -f "$TKGA_CORE_DIR/src/bootstrap.cpp"
test -f "$TKGA_CORE_DIR/include/tkga/abi.def"
test ! -f "$TKGA_CORE_DIR/include/tkga/abi_def.txt"
test ! -e "$prefix"
if [ ! -f "$prefix/lib/libspectrum.dll.a" ]; then
  mkdir -p "$build/libspectrum"
  (cd "$source/libspectrum-src" && autoreconf -fi)
  (
    cd "$build/libspectrum"
    mkdir -p test
    "$source/libspectrum-src/configure" --host=i686-w64-mingw32 --prefix="$prefix" \
      --with-fake-glib --without-libgcrypt --without-libaudiofile --without-zlib \
      --without-bzip2 --disable-dependency-tracking --enable-shared
    make -j8 WINDRES="$WINDRES"
    make WINDRES="$WINDRES" install
  )
fi
export PATH="$prefix/bin:$PATH"
export LIBSPECTRUM_CFLAGS="-I$prefix/include"
export LIBSPECTRUM_LIBS="$prefix/lib/libspectrum.dll.a"
src_win="$(cygpath -m "$source/fuse-src")"
export CFLAGS="$CFLAGS -ffile-prefix-map=$src_win=source/fuse-src"
(cd "$source/fuse-src" && autoreconf -fi)
mkdir "$build/fuse"
(
 cd "$build/fuse"
 "$source/fuse-src/configure" --host=i686-w64-mingw32 --with-win32 --without-libpng \
   --without-libxml2 --without-joystick --without-sdl --without-sdl2 --without-gtk \
   --without-x --disable-dependency-tracking --enable-tkga-experimental
 make -j8 -f Makefile -f - pub03b-generated <<'MAKE'
.PHONY: pub03b-generated
pub03b-generated: $(BUILT_SOURCES) config.h
MAKE
 grep -q 'tkga_experimental' settings.h
 make -j8 fuse.exe z80/coretest.exe
 z80/.libs/coretest.exe "$source/fuse-src/z80/tests/tests.in" > z80/pub03b-tests.actual
 test -f .libs/fuse.exe
)