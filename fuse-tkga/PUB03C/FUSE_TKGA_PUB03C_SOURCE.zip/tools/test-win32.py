#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-2.0-or-later
"""Rebuild Hello and FirstFrame and compare Win32 emulator output with authored test oracles."""
from argparse import ArgumentParser
from hashlib import sha256
from pathlib import Path
import json
import shutil
import struct
import subprocess
import ctypes as C, ctypes.wintypes as W, os,time,threading
from PIL import Image

u=C.windll.user32;g=C.windll.gdi32
u.GetDC.argtypes=[W.HWND];u.GetDC.restype=W.HDC
u.GetWindowDC.argtypes=[W.HWND];u.GetWindowDC.restype=W.HDC
u.ReleaseDC.argtypes=[W.HWND,W.HDC]
u.GetClientRect.argtypes=[W.HWND,C.POINTER(W.RECT)]
u.GetWindowRect.argtypes=[W.HWND,C.POINTER(W.RECT)]
u.IsWindowVisible.argtypes=[W.HWND]
u.GetWindowThreadProcessId.argtypes=[W.HWND,C.POINTER(W.DWORD)]
u.GetClassNameW.argtypes=[W.HWND,W.LPWSTR,C.c_int]
u.GetWindowTextW.argtypes=[W.HWND,W.LPWSTR,C.c_int]
g.CreateCompatibleDC.argtypes=[W.HDC];g.CreateCompatibleDC.restype=W.HDC
g.SelectObject.argtypes=[W.HDC,W.HGDIOBJ];g.SelectObject.restype=W.HGDIOBJ
g.DeleteObject.argtypes=[W.HGDIOBJ];g.DeleteDC.argtypes=[W.HDC]
g.BitBlt.argtypes=[W.HDC,C.c_int,C.c_int,C.c_int,C.c_int,W.HDC,C.c_int,C.c_int,W.DWORD]
class BMI(C.Structure):
 _fields_=[('size',W.DWORD),('width',W.LONG),('height',W.LONG),('planes',W.WORD),('bits',W.WORD),('compression',W.DWORD),('image',W.DWORD),('xppm',W.LONG),('yppm',W.LONG),('used',W.DWORD),('important',W.DWORD),('colour',W.DWORD)]
g.CreateDIBSection.argtypes=[W.HDC,C.POINTER(BMI),W.UINT,C.POINTER(C.c_void_p),W.HANDLE,W.DWORD];g.CreateDIBSection.restype=W.HBITMAP
callback=C.WINFUNCTYPE(W.BOOL,W.HWND,W.LPARAM)
u.EnumWindows.argtypes=[callback,W.LPARAM]
def window(pid):
 found=[]
 @callback
 def visit(hwnd,param):
  ident=W.DWORD();u.GetWindowThreadProcessId(hwnd,C.byref(ident))
  name=C.create_unicode_buffer(256);u.GetClassNameW(hwnd,name,256)
  if ident.value==pid and name.value=='Fuse' and u.IsWindowVisible(hwnd):found.append(hwnd)
  return True
 u.EnumWindows(visit,0)
 return found[0] if found else None
def capture(hwnd,client=False):
 rect=W.RECT();(u.GetClientRect if client else u.GetWindowRect)(hwnd,C.byref(rect))
 if not client:
  dwm=C.windll.dwmapi
  dwm.DwmGetWindowAttribute.argtypes=[W.HWND,W.DWORD,C.c_void_p,W.DWORD]
  dwm.DwmGetWindowAttribute(hwnd,9,C.byref(rect),C.sizeof(rect))
 w,h=rect.right-rect.left,rect.bottom-rect.top
 dc=u.GetDC(hwnd if client else None);mem=g.CreateCompatibleDC(dc)
 bmi=BMI();bmi.size=40;bmi.width=w;bmi.height=-h;bmi.planes=1;bmi.bits=32
 ptr=C.c_void_p();bmp=g.CreateDIBSection(dc,C.byref(bmi),0,C.byref(ptr),None,0)
 assert bmp and ptr.value,(w,h,C.GetLastError())
 old=g.SelectObject(mem,bmp)
 assert g.BitBlt(mem,0,0,w,h,dc,0 if client else rect.left,0 if client else rect.top,0x00cc0020)
 image=Image.frombytes('RGB',(w,h),C.string_at(ptr,w*h*4),'raw','BGRX')
 g.SelectObject(mem,old);g.DeleteObject(bmp);g.DeleteDC(mem);u.ReleaseDC(hwnd if client else None,dc)
 return image


PACKAGE = Path(__file__).resolve().parents[1]
CASES = {"classic":None, "hello":"examples/01-hello/hello.asm",
         "first-frame":"examples/02-first-frame/first-frame.asm"}
SPECTRUM_REQUESTS = ["TKGA SIGNATURE OK","IF VERSION: 0101","CMDSET: 0101","CAPS: 001F"]


def file_hash(path):
    return sha256(path.read_bytes()).hexdigest()


def bitmap_hash(image):
    return sha256(image.tobytes()).hexdigest()


def write_sna(path, code):
    assert len(code)<=0x7ffd
    header=bytearray(27)
    header[23:25]=struct.pack("<H",0x7ffd)
    header[25]=1
    ram=bytearray(49152)
    ram[0x4000:0x4000+len(code)]=code
    ram[0x3ffd:0x3fff]=struct.pack("<H",0x8000)
    with path.open("xb") as f:
        f.write(header+ram)


def hello_mask(rom):
    assert len(rom)==16*1024
    out=bytearray(256*192)
    for y,line in enumerate(SPECTRUM_REQUESTS):
        for x,c in enumerate(line):
            for row,byte in enumerate(rom[0x3c00+ord(c)*8:0x3c08+ord(c)*8]):
                for j in range(8):
                    if byte & (128>>j):
                        out[(8*y+row)*256+8*x+j]=1
    return bytes(out)


def mask(rgb):
    return bytes(1 if sum(rgb[i:i+3])>100 else 0 for i in range(0,len(rgb),3))


def first_frame_hashes():
    palette={".":(0,0,0),"R":(255,0,0),"G":(0,255,0),
             "B":(0,0,255),"Y":(255,255,0)}
    starts=["GGRRBBBB"]*3+["RRRRBBBB"]*3+["RRRRBBBY","RRRRBBBB"]
    ends=["BBBBGGGG"]*4+["BBBBYYYY"]*3+["RRBBYYYY"]
    out={}
    for name,cells in (("A", starts),("B", ends)):
        pixels=bytes(v for row in cells for c in row for v in palette[c])
        inside=Image.frombytes("RGB",(8,8),pixels).resize((240,240),Image.Resampling.NEAREST)
        im=Image.new("RGB",(320,240))
        im.paste(inside,(40,0))
        out[bitmap_hash(im)]=name
    return out


def main():
    p=ArgumentParser(description=__doc__)
    p.add_argument("--exe", type=Path, required=True)
    p.add_argument("--libspectrum", type=Path, required=True)
    p.add_argument("--runtime-dir", type=Path, required=True)
    p.add_argument("--assembler", type=Path, required=True)
    p.add_argument("--rom", type=Path, required=True, help="A legally obtained Spectrum 48K ROM furnished by the tester")
    p.add_argument("--out", type=Path, required=True)
    p.add_argument("--case",choices=CASES.keys(),action="append")
    args=p.parse_args()
    for field in ("exe","libspectrum","runtime_dir","assembler","rom","out"):
        setattr(args,field,getattr(args,field).resolve())
    out=args.out
    out.mkdir(exist_ok=False)
    rom=args.rom.read_bytes()
    expected_hello=hello_mask(rom)
    expected_frames=first_frame_hashes()
    cases=args.case or list(CASES)
    assert len(cases)==len(set(cases))
    records=[]
    for name in cases:
        case=out/name
        case.mkdir()
        roms=case/"roms"; roms.mkdir()
        for source,target in ((args.exe,case/"fuse.exe"),(args.libspectrum,case/"libspectrum-9.dll"),(args.rom,roms/"48.rom")):
            shutil.copyfile(source,target)
        for dll in ("libc++.dll","libunwind.dll","libwinpthread-1.dll"):
            shutil.copyfile(args.runtime_dir/dll,case/dll)
        rel=CASES[name]; compile_cmd=None
        argv=[str(case/"fuse.exe"),"--machine","48","--speed","100","--rate","1","--no-sound",
              "--no-autosave-settings","--no-confirm-actions","--tkga-experimental" if rel else "--no-tkga-experimental"]
        if rel:
            source=PACKAGE/rel
            binary=case/(name+".bin")
            compile_cmd=[str(args.assembler),f"--raw={binary}",source.name]
            proc=subprocess.run(compile_cmd,cwd=source.parent,capture_output=True)
            (case/"assembler.log").write_bytes(proc.stdout+proc.stderr)
            assert proc.returncode==0
            image=case/(name+".sna")
            write_sna(image,binary.read_bytes())
            argv+=["--snapshot",str(image)]
        preferences=case/"profile"; preferences.mkdir()
        local_appdata=preferences/"AppData"; local_appdata.mkdir()
        env={k:v for k,v in os.environ.items() if not k.startswith("FUSE_TKGA_")}
        env.update(PATH=str(Path(os.environ["SystemRoot"])/"System32"),
                   USERPROFILE=str(preferences),APPDATA=str(local_appdata),FUSE_TKGA_F3A_FRAMES="330")
        si=subprocess.STARTUPINFO()
        si.dwFlags|=subprocess.STARTF_USESHOWWINDOW
        si.wShowWindow=4
        frames={}
        deadline=time.monotonic()+14
        with (case/"runtime.log").open("xb") as log:
            proc=subprocess.Popen(argv,cwd=case,env=env,stdout=log,stderr=subprocess.STDOUT,startupinfo=si)
            try:
                while proc.poll() is None and time.monotonic()<deadline:
                    hwnd=window(proc.pid)
                    if hwnd:
                        raw=capture(hwnd,True)
                        if raw.width>=320 and raw.height>=240:
                            im=raw.crop((0,0,320,240))
                            field=im.crop((32,24,288,216))
                            digest=bitmap_hash(im)
                            if name=="first-frame":
                                key=expected_frames.get(digest)
                            elif name=="hello":
                                key="signature-versions-caps" if mask(field.tobytes())==expected_hello else None
                            else:
                                colors=field.getcolors(256)
                                key="rom-boot-screen" if colors and len(colors)>1 else None
                            if key and key not in frames:
                                frames[key]=digest
                                im.save(case/(key+".png"))
                    time.sleep(.025)
            finally:
                try:
                    proc.wait(timeout=1)
                except subprocess.TimeoutExpired:
                    proc.terminate()
                    proc.wait(timeout=5)
        required={"classic":{"rom-boot-screen"},"hello":{"signature-versions-caps"},"first-frame":{"A","B"}}[name]
        result={"case":name,"status":"PASS" if required<=frames.keys() and proc.returncode==0 else "FAIL",
                "exit":proc.returncode,"frames":frames,"build":compile_cmd,"run":argv,
                "fuse_sha256":file_hash(args.exe),"libspectrum_sha256":file_hash(args.libspectrum)}
        records.append(result)
        print(name,result["status"],proc.returncode,list(frames),flush=True)
    with (out/"RESULTS.json").open("x",encoding="utf-8") as file:
        json.dump(records,file,indent=2)
    return 0 if all(r["status"]=="PASS" for r in records) else 1


if __name__=="__main__":
    raise SystemExit(main())
