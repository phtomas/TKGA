# Reconstrução e testes

Ambiente ensaiado: Windows, MSYS2 com Bash, Autotools, Perl e Make, Clang/LLVM-MinGW i686, GNU windres do MinGW e patch instalado. Python 3 é usado pelo preparador e Pillow pelo runner Win32. SjASMPlus 1.21.0 monta os exemplos. Use versões e hashes do recibo ao reproduzir o ambiente. Dependências são obtidas separadamente. [MSYS2](https://www.msys2.org/) · [LLVM-MinGW](https://github.com/mstorsjo/llvm-mingw/releases) · [SjASMPlus](https://github.com/z00m128/sjasmplus)

1. Baixe os tarballs oficiais Fuse 1.6.0 e libspectrum 1.5.0 de seus projetos. Confira [UPSTREAM_SHA256SUMS.txt](UPSTREAM_SHA256SUMS.txt) antes de extrair. [Fuse](https://sourceforge.net/projects/fuse-emulator/files/fuse/1.6.0/) · [libspectrum](https://sourceforge.net/projects/fuse-emulator/files/libspectrum/1.5.0/)
2. Execute o preparador na raiz do pacote. Dê caminhos próprios ao diretório dos tarballs, ao patch instalado e à pasta nova de fontes.

       python tools/prepare.py --upstream CAMINHO_TARBALLS --patch-exe CAMINHO_PATCH --out FONTES_NOVAS

3. Em Bash MSYS2, ponha as ferramentas i686-w64-mingw32-* no PATH. Passe caminhos absolutos no formato do shell para FONTES_NOVAS e para o GNU windres i686 disponível. BUILD é um diretório vazio, e PREFIXO ainda não existe. A receita compila também o libspectrum de origem conhecida.

       mkdir BUILD
       export PUB03B_WINDRES=/c/caminho/para/gnu/windres.exe
       bash tools/build-win32.sh /c/caminho/FONTES_NOVAS /c/caminho/BUILD /c/caminho/BUILD/prefix

4. Rode o teste Win32 com uma ROM 48K de uso lícito, um montador existente, o executável recém-gerado e as DLLs locais do compilador i686. No Windows, o teste inicia uma janela de emulação para ler o RGB do cliente. Use uma pasta de saída nova em cada rodada.

       python tools/test-win32.py --exe BUILD/fuse/.libs/fuse.exe --libspectrum BUILD/prefix/bin/libspectrum-9.dll --runtime-dir RUNTIME_I686 --assembler SJASMPLUS --rom ROM48_DO_USUARIO --out TESTE_INICIAL

   Caso um teste de início falhe, preserve TESTE_INICIAL e repita somente o caso correspondente em outro diretório com --case hello ou --case first-frame. Compare os recibos e o SHA do executável. As ROMs/DLLs copiadas pelo teste ficam na pasta de teste local.

5. Golden Z80: em PowerShell ou outro terminal com Python, compare os arquivos bruto Win32 e upstream, preservando todos os bytes originais. Exemplo na raiz do pacote com os caminhos de compilação descritos acima.

       python -c "import pathlib,sys; a,b=map(lambda x:pathlib.Path(x).read_bytes(),sys.argv[1:]); assert a.replace(b'\r\n',b'\n')==b; print(len(b.splitlines()))" BUILD/fuse/z80/pub03b-tests.actual FONTES_NOVAS/fuse-src/z80/tests/tests.expected

O Core deste pacote contém 12 arquivos. O SDK C11 de serialização da Developer Preview inicial tem outro escopo. [Repositório TKGA inicial](https://github.com/phtomas/TKGA)
