#ifndef TKGA_H
#define TKGA_H
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif

/* Host return values are NOT RC1.1 wire error codes. PC0/PC1 foundation only. */
#define TKGA_HOST_OK UINT8_C(0)
#define TKGA_HOST_INVALID_ARGUMENT UINT8_C(1)
#define TKGA_HOST_ALLOCATION_FAILED UINT8_C(2)
#define TKGA_HOST_NOT_IMPLEMENTED UINT8_C(3)
#define TKGA_HOST_REJECTED UINT8_C(4)
#define TKGA_IF_VERSION UINT16_C(0x0101)
#define TKGA_CMDSET_VERSION UINT16_C(0x0101)

enum tkga_register_selector {
#define TKGA_ABI(id, name, width, access, snapshot) TKGA_REG_##name = id,
#include "tkga/abi.def"
#undef TKGA_ABI
};
enum tkga_opcode {
#define TKGA_COMMAND(opcode, name) TKGA_CMD_##name = opcode,
#include "tkga/commands.def"
#undef TKGA_COMMAND
};

typedef struct tkga_device tkga_device;
typedef struct tkga_register_info {
    uint8_t selector;
    uint8_t width_bytes;
    uint8_t writable;
    uint8_t dynamic_snapshot;
} tkga_register_info;

/* Field serialization is never sizeof(struct): no platform-sized wire values. */
typedef struct tkga_profile {
    uint16_t features;
    uint8_t formats;
    uint16_t max_handles;
    uint32_t max_resource_bytes;
    uint16_t cmd_capacity;
    uint16_t data_capacity;
    uint16_t max_cmd_payload;
    uint16_t max_width;
    uint16_t max_height;
    uint16_t max_sprites;
    uint16_t sprites_per_line;
    uint8_t max_layers;
    uint16_t palette_banks;
    uint16_t palette_entries;
    uint8_t target_mask;
    uint8_t tile_geometries;
    uint16_t map_max_width;
    uint16_t map_max_height;
    uint16_t max_sprite_width;
    uint16_t max_sprite_height;
    uint8_t present;
} tkga_profile;

uint8_t tkga_default_profile(tkga_profile *out_profile);
uint8_t tkga_get_register_info(uint8_t selector, tkga_register_info *out_info);
uint8_t tkga_create(const tkga_profile *profile, tkga_device **out_device);
void tkga_destroy(tkga_device *device);
/* Logical endpoints. No physical addresses. Domain execution awaits PC2-PC7. */
uint8_t tkga_cmd_write8(tkga_device *device, uint8_t value);
uint8_t tkga_data_write8(tkga_device *device, uint8_t value);
uint8_t tkga_reg_select8(tkga_device *device, uint8_t selector);
uint8_t tkga_reg_read8(tkga_device *device, uint8_t *out_value);
uint8_t tkga_reg_write8(tkga_device *device, uint8_t value);
/* Deterministic engine quantum; diagnostic host scheduling, not wire ABI. */
uint8_t tkga_step(tkga_device *device);
/* Diagnostic resource readback, NOT a wire endpoint or bypass into validity. */
uint8_t tkga_resource_readback(tkga_device *device, uint16_t handle,
    uint8_t *out_bytes, uint32_t capacity, uint32_t *out_length, uint8_t *out_valid);
/* Diagnostic only: explicit working binding presence and RGB expansion. */
uint8_t tkga_target_handle(tkga_device *device, uint8_t role,
    uint16_t *out_handle, uint8_t *out_bound);
uint8_t tkga_resource_rgb_readback(tkga_device *device, uint16_t handle,
    uint8_t *out_rgb, uint32_t capacity, uint32_t *out_length);

/* PC4 host logical composition, explicit base, no PRESENT/event/snapshot publication. */
uint8_t tkga_composed_readback(tkga_device *device, uint16_t base_handle,
    uint8_t *out_indexed, uint32_t indexed_capacity, uint32_t *out_indexed_length,
    uint8_t *out_rgb, uint32_t rgb_capacity, uint32_t *out_rgb_length);

/* PC5 host diagnostic: topmost selected sprite IDs, descending(priority,id). */
uint8_t tkga_scanline_survivors(tkga_device *device, uint16_t base_handle,
    uint16_t scanline, uint16_t *out_ids, uint16_t capacity, uint16_t *out_count);

/* PC7 host-only backend obligations: opaque tickets, never public ABI epochs. */
uint8_t tkga_backend_read_begin(tkga_device *, uint8_t pending, uint64_t *out_token);
uint8_t tkga_backend_read_ack(tkga_device *, uint64_t token);
uint8_t tkga_backend_write_hold(tkga_device *, uint8_t hold);
uint8_t tkga_backend_write_ack(tkga_device *, uint64_t token);
/* Host-only snapshot metadata. This struct is not a wire packet. */
typedef struct tkga_frame_info {
    uint8_t valid;
    uint8_t format;
    uint8_t role;
    uint16_t base_handle;
    uint16_t width;
    uint16_t height;
    uint16_t tag;
    uint32_t indexed_length;
    uint32_t rgb_length;
} tkga_frame_info;
uint8_t tkga_get_frame_info(const tkga_device *device, uint8_t pending,
    tkga_frame_info *out_info);
/* PC6 deterministic host scheduling/readback hooks; no new wire selectors. */
uint8_t tkga_backend_ready(tkga_device *, uint8_t ready);
uint8_t tkga_boundary_begin(tkga_device *);
uint8_t tkga_boundary_end(tkga_device *, uint8_t concurrent_ack_valid, uint16_t concurrent_ack_tag);
uint8_t tkga_logical_source(tkga_device *, uint8_t *out_source);
uint8_t tkga_frame_readback(tkga_device *, uint8_t pending, uint8_t *indexed,
    uint32_t indexed_capacity, uint32_t *indexed_length, uint8_t *rgb,
    uint32_t rgb_capacity, uint32_t *rgb_length, uint16_t *out_tag);
#ifdef __cplusplus
}
#endif
#endif
