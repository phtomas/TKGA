#include "core_state.hpp"
#include <algorithm>
#include <new>

void tkga_finish_write(tkga_device &d,uint16_t handle,const tkga_write &w) {
    const auto it=d.resources.find(handle);
    if(it==d.resources.end() || it->second.identity!=w.identity) return;
    if(w.session!=d.session && !d.reset_active) return;
    auto &r=it->second;r.bytes[w.offset]=w.value;r.coverage[w.offset]=1;
    if(w.session==d.session) d.data_retired=w.serial;
}
void tkga_retire_scenes(tkga_device &d) {
    for(auto i=d.retiring_scenes.begin();i!=d.retiring_scenes.end();) {
        const auto sequence=(*i)->sequence;
        const bool readers=std::any_of(d.read_jobs.begin(),d.read_jobs.end(),[sequence](const auto &j){return j.second.second==sequence;});
        if(readers) {++i;continue;}
        for(auto h:(*i)->handles) --d.resources.at(h).read_leases;
        i=d.retiring_scenes.erase(i);
    }
}
uint8_t tkga_reset_begin(tkga_device &d,uint8_t scope) {
    try {d.retiring_scenes.reserve(d.retiring_scenes.size()+2);} catch(const std::bad_alloc &) {return 5;}
    // Caller has completed full packet preflight, at queue head. No suffix executes.
    d.reset_active=true;d.reset_scope=scope;++d.session;
    d.last_error=0;d.error_classes=0;
    d.commands.clear();d.cmd_used=0;d.rx.clear();d.discard_remaining=0;
    // Preserve dynamic read epoch/cursor (D05); terminate only ACK/control staging.
    d.ack_low=0;d.write_cursor=d.selected==TKGA_REG_FRAME_ACK?2:0;
    d.frame_event=false;d.last_presented=0;d.fence_valid=false;d.completed_fence=0;
    tkga_mode_reset_begin(d);
    d.reset_detached=!d.published;
    if(d.pending) d.retiring_scenes.push_back(std::move(d.pending));
    if(tkga_upload_active(d)) {
        d.resources.at(d.upload.handle).valid=false;
        d.reset_upload_handle=d.upload.handle;
        d.reset_writes=std::move(d.upload.outstanding);
    }
    d.upload={}; // Non-issued bytes discarded; issued writes owned by reset until ACK.
    for(const auto &l:d.layers) if(l.enabled) {--d.resources.at(l.atlas).layer_leases;--d.resources.at(l.map).layer_leases;}
    for(const auto &s:d.sprites) if(s.enabled) --d.resources.at(s.handle).sprite_leases;
    std::fill(d.layers.begin(),d.layers.end(),tkga_layer{});
    std::fill(d.sprites.begin(),d.sprites.end(),tkga_sprite{});
    d.targets.fill(0);d.target_valid.fill(false);
    for(auto &bank:d.palettes) std::fill(bank.begin(),bank.end(),0);
    d.clip_enabled=false;d.clip_x=0;d.clip_y=0;d.clip_w=0;d.clip_h=0;
    tkga_retire_scenes(d);
    return 0;
}
void tkga_reset_tick(tkga_device &d) {
    while(d.write_auto_ack && !d.reset_writes.empty() && d.reset_writes.front().retire_step<=d.step) {
        auto w=d.reset_writes.front();d.reset_writes.pop_front();tkga_finish_write(d,d.reset_upload_handle,w);
    }
    tkga_retire_scenes(d);
    if(!d.reset_detached || d.published || !d.retiring_scenes.empty() || !d.read_jobs.empty() || !d.reset_writes.empty()) return;
    if(d.reset_scope==1) d.resources.clear();
    d.data_admitted=0;d.data_retired=0;d.reset_upload_handle=0;
    tkga_mode_reset_complete(d);d.reset_active=false;
    // Do not clear errors here: every post-cutpoint error survives completion.
}
uint8_t tkga_ack_epoch(tkga_device &d,uint64_t admitted_session,uint16_t tag) {
    if(admitted_session!=d.session) return 0; // Old admitted operation, not a newly received wire ACK.
    return tkga_ack(d,tag);
}
extern "C" uint8_t tkga_backend_read_begin(tkga_device *d,uint8_t pending,uint64_t *token) {
    if(!d || !token || pending>1) return TKGA_HOST_INVALID_ARGUMENT;
    const auto *s=pending?d->pending.get():d->published.get();
    if(d->reset_active || !s) return TKGA_HOST_REJECTED;
    try {const auto id=d->next_job;d->read_jobs.emplace(id,std::make_pair(d->session,s->sequence));++d->next_job;*token=id;return 0;}
    catch(const std::bad_alloc &) {return TKGA_HOST_ALLOCATION_FAILED;}
}
extern "C" uint8_t tkga_backend_read_ack(tkga_device *d,uint64_t token) {
    if(!d) return TKGA_HOST_INVALID_ARGUMENT;
    d->read_jobs.erase(token);tkga_retire_scenes(*d);return 0;
}
extern "C" uint8_t tkga_backend_write_hold(tkga_device *d,uint8_t hold) {
    if(!d || hold>1) return TKGA_HOST_INVALID_ARGUMENT;
    d->write_auto_ack=hold==0;return 0;
}
extern "C" uint8_t tkga_backend_write_ack(tkga_device *d,uint64_t token) {
    if(!d) return TKGA_HOST_INVALID_ARGUMENT;
    auto finish=[&](std::deque<tkga_write> &jobs,uint16_t h) {
        auto it=std::find_if(jobs.begin(),jobs.end(),[token](const auto &w){return w.token==token;});
        if(it==jobs.end()) return false;
        // This reference backend serializes write ACKs; do not advance watermark out of order.
        if(it!=jobs.begin()) return true;
        auto w=*it;jobs.erase(it);tkga_finish_write(*d,h,w);return true;
    };
    if(!finish(d->reset_writes,d->reset_upload_handle)) finish(d->upload.outstanding,d->upload.handle);
    return 0;
}
