#include "core_state.hpp"
#include <algorithm>
#include <cstdint>
#include <limits>
#include <new>
#include <utility>

uint32_t pitch(const tkga_resource &r) {
    return r.format == 2 ? r.width : (static_cast<uint32_t>(r.width) + 1U) / 2U;
}
uint8_t tkga_pixel(const tkga_resource &r, int64_t x, int64_t y) {
    const auto ux = static_cast<uint32_t>(x), uy = static_cast<uint32_t>(y);
    const uint8_t value = r.bytes[6U + uy * pitch(r) + (r.format == 2 ? ux : ux / 2U)];
    return r.format == 2 ? value : static_cast<uint8_t>((value >> ((ux & 1U) ? 0U : 4U)) & 15U);
}
void tkga_put(tkga_resource &r, int64_t x, int64_t y, uint8_t value) {
    const auto ux = static_cast<uint32_t>(x), uy = static_cast<uint32_t>(y);
    auto &dest = r.bytes[6U + uy * pitch(r) + (r.format == 2 ? ux : ux / 2U)];
    if (r.format == 2)
        dest = value;
    else if (ux & 1U)
        dest = static_cast<uint8_t>((dest & 240U) | value);
    else
        dest = static_cast<uint8_t>((dest & 15U) | (static_cast<uint32_t>(value) << 4U));
}

namespace {
struct region {
    int64_t x0, y0, x1, y1;
    bool empty() const { return x0 >= x1 || y0 >= y1; }
};
struct point {
    int64_t x, y;
};
region intersect(region a, region b) {
    return {std::max(a.x0, b.x0), std::max(a.y0, b.y0), std::min(a.x1, b.x1), std::min(a.y1, b.y1)};
}
region bounds(const tkga_resource &r) { return {0, 0, r.width, r.height}; }
region effective(const tkga_device &d, const tkga_resource &r, region box) {
    box = intersect(box, bounds(r));
    if (d.clip_enabled)
        box = intersect(box, {d.clip_x, d.clip_y, static_cast<int64_t>(d.clip_x) + d.clip_w,
                              static_cast<int64_t>(d.clip_y) + d.clip_h});
    return box;
}
region rectangle(const std::vector<uint8_t> &b, unsigned o) {
    const int64_t x = tkga_s16(b, o), y = tkga_s16(b, o + 2);
    return {x, y, x + tkga_u16(b, o + 4), y + tkga_u16(b, o + 6)};
}
uint32_t color(const std::vector<uint8_t> &b, unsigned o) {
    return (static_cast<uint32_t>(b[o]) << 16U) | (static_cast<uint32_t>(b[o + 1]) << 8U) |
           b[o + 2];
}
uint8_t find_color(const tkga_device &d, const tkga_resource &r, uint32_t rgb, uint8_t &out) {
    if (d.palettes.empty())
        return 7;
    const unsigned limit =
        std::min<unsigned>(r.format == 1 ? 16U : 256U, d.profile.palette_entries);
    for (unsigned i = 0; i < limit; ++i)
        if (d.palettes[0][i] == rgb) {
            out = static_cast<uint8_t>(i);
            return 0;
        }
    return 3;
}
uint8_t role_parameter(uint8_t role) { return role > 2 ? 3 : 0; }
uint8_t role_capability(const tkga_device &d, uint8_t role) {
    return (!(d.profile.features & 1U) || !(d.profile.target_mask & (1U << role))) ? 4 : 0;
}
uint8_t target_identity(tkga_device &d, uint8_t role, tkga_resource *&out) {
    out = nullptr;
    if (!d.target_valid[role])
        return 0; // absence is phase9, after identity of evaluable operands
    const auto found = d.resources.find(d.targets[role]);
    if (found == d.resources.end())
        return 6;
    out = &found->second;
    return out->kind != 4 ? 3 : 0;
}
uint8_t image_state(const tkga_device &d, const tkga_resource *r, bool writable, uint16_t handle) {
    if (!r || !r->defined || !r->valid)
        return 7;
    if (tkga_upload_active(d) && d.upload.handle == handle)
        return 7;
    if (writable && r->read_leases)
        return 7;
    return 0;
}
int64_t floor_div(int64_t numerator, int64_t denominator) {
    int64_t q = numerator / denominator;
    if (numerator % denominator < 0)
        --q;
    return q;
}
std::vector<point> line(const tkga_device &d, const tkga_resource &r,
                        const std::vector<uint8_t> &b) {
    int64_t x0 = tkga_s16(b, 5), y0 = tkga_s16(b, 7), x1 = tkga_s16(b, 9), y1 = tkga_s16(b, 11);
    const int64_t dx = x1 - x0, dy = y1 - y0;
    const int64_t ax = dx < 0 ? -dx : dx, ay = dy < 0 ? -dy : dy;
    const int64_t major = std::max(ax, ay);
    const region clip = effective(d, r, bounds(r));
    std::vector<point> points;
    auto add = [&](int64_t x, int64_t y) {
        if (x >= clip.x0 && x < clip.x1 && y >= clip.y0 && y < clip.y1)
            points.push_back({x, y});
    };
    if (!major) {
        add(x0, y0);
        return points;
    }
    if (ax >= ay) {
        if (x0 > x1) {
            std::swap(x0, x1);
            std::swap(y0, y1);
        }
        for (int64_t i = 0; i <= major; ++i)
            add(x0 + i, y0 + floor_div(2 * i * (y1 - y0) + major, 2 * major));
    } else {
        if (y0 > y1) {
            std::swap(x0, x1);
            std::swap(y0, y1);
        }
        for (int64_t i = 0; i <= major; ++i)
            add(x0 + floor_div(2 * i * (x1 - x0) + major, 2 * major), y0 + i);
    }
    return points;
}
// Directional traversal protects translation sources, including INDEX4 packed bytes.
template <class Function>
void visit(region box, bool reverse_x, bool reverse_y, Function operation) {
    if (box.empty())
        return;
    for (int64_t row = 0; row < box.y1 - box.y0; ++row) {
        const int64_t y = reverse_y ? box.y1 - 1 - row : box.y0 + row;
        for (int64_t col = 0; col < box.x1 - box.x0; ++col) {
            const int64_t x = reverse_x ? box.x1 - 1 - col : box.x0 + col;
            operation(x, y);
        }
    }
}
uint8_t palette_command(tkga_device &d, const std::vector<uint8_t> &b) {
    if (!(d.profile.features & 16U))
        return 4;
    const uint8_t op = b[0];
    const unsigned bank = b[4];
    if (bank >= d.profile.palette_banks)
        return 8;
    if (op == 0x22) {
        std::fill(d.palettes[bank].begin(), d.palettes[bank].end(), color(b, 5));
        return 0;
    }
    const unsigned source = op == 0x21 ? b[5] : bank;
    if (source >= d.profile.palette_banks)
        return 8;
    const unsigned start = b[op == 0x21 ? 6 : 5], count = b[op == 0x21 ? 7 : 6];
    if (start + count > d.profile.palette_entries)
        return 8;
    if (op == 0x20)
        for (unsigned i = 0; i < count; ++i)
            d.palettes[bank][start + i] = color(b, 7 + 3 * i);
    else
        for (unsigned i = 0; i < count; ++i)
            d.palettes[bank][start + i] = d.palettes[source][start + i];
    return 0;
}
uint8_t bind_command(tkga_device &d, const std::vector<uint8_t> &b) {
    const uint8_t role = b[4];
    const uint16_t handle = tkga_u16(b, 5);
    if (role_parameter(role) || b[7])
        return 3;
    if (role_capability(d, role))
        return 4;
    const auto found = d.resources.find(handle);
    if (found == d.resources.end())
        return 6;
    auto &r = found->second;
    if (r.kind != 4)
        return 3;
    if (r.defined && !(d.profile.formats & (1U << (r.format - 1U))))
        return 4;
    if (r.defined &&
        (!r.width || !r.height || r.width > d.profile.max_width || r.height > d.profile.max_height))
        return 8;
    if (r.read_leases || image_state(d, &r, false, handle))
        return 7;
    for (unsigned i = 0; i < 3; ++i)
        if (i != role && d.target_valid[i] && d.targets[i] == handle)
            return 7;
    d.targets[role] = handle;
    d.target_valid[role] = true;
    return 0;
}
uint8_t copy_command(tkga_device &d, const std::vector<uint8_t> &b) {
    const bool fb = b[0] == 0x33, keyed = b[0] == 0x61;
    const uint8_t dest_role = b[fb ? 5 : 6];
    const uint8_t source_role = fb ? b[4] : 0;
    const uint8_t flags = b[fb ? 18 : 19];
    if ((fb && role_parameter(source_role)) || role_parameter(dest_role) || flags)
        return 3;
    if (!(d.profile.features & 8U))
        return 4;
    if ((fb && role_capability(d, source_role)) || role_capability(d, dest_role))
        return 4;
    tkga_resource *dest = nullptr, *source = nullptr;
    uint8_t error = 0;
    const uint16_t source_handle = fb ? d.targets[source_role] : tkga_u16(b, 4);
    // FB source is a structural target; BLIT only consumes source for visible writes.
    if (fb && (error = target_identity(d, source_role, source)))
        return error;
    if ((error = target_identity(d, dest_role, dest)))
        return error;
    const unsigned o = fb ? 6U : 7U;
    const int64_t sx = fb ? tkga_s16(b, o) : tkga_u16(b, o),
                  sy = fb ? tkga_s16(b, o + 2) : tkga_u16(b, o + 2);
    const int64_t dx = tkga_s16(b, o + 4), dy = tkga_s16(b, o + 6);
    const int64_t w = tkga_u16(b, o + 8), h = tkga_u16(b, o + 10);
    region area =
        dest && dest->defined ? effective(d, *dest, {dx, dy, dx + w, dy + h}) : region{0, 0, 0, 0};
    if (!fb && w && h && (!area.empty() || !dest || !dest->defined)) {
        const auto found = d.resources.find(source_handle);
        if (found == d.resources.end())
            return 6;
        source = &found->second;
        if (source->kind != 1 && source->kind != 4)
            return 3;
    }
    if (source && dest && source->defined && dest->defined && source->format != dest->format)
        return 3;
    if (keyed && source && source->defined && b[20] >= (source->format == 1 ? 16U : 256U)) {
        const region paired =
            intersect(area, {dx - sx, dy - sy, dx - sx + source->width, dy - sy + source->height});
        // PC3-AQ01 HUMAN RATIFIED: key range applies only to geometrically
        // consumable source texels after paired clipping, before pixel reads.
        if (!paired.empty())
            return 8;
    }
    if ((error = image_state(d, dest, true, d.targets[dest_role])))
        return error;
    if (fb && (error = image_state(d, source, false, source_handle)))
        return error;
    if (area.empty())
        return 0;
    if ((error = image_state(d, source, false, source_handle)))
        return error;
    area = intersect(area, {dx - sx, dy - sy, dx - sx + source->width, dy - sy + source->height});
    if (area.empty())
        return 0;
    const bool alias = source == dest;
    visit(area, alias && dx > sx, alias && dy > sy, [&](int64_t x, int64_t y) {
        const uint8_t index = tkga_pixel(*source, x - dx + sx, y - dy + sy);
        if (!keyed || index != b[20])
            tkga_put(*dest, x, y, index);
    });
    return 0;
}
uint8_t raster_command(tkga_device &d, const std::vector<uint8_t> &b) {
    const uint8_t op = b[0], role = b[4];
    if (role_parameter(role) || (op == 0x63 && b[16] > 1))
        return 3;
    if (op >= 0x62 && !(d.profile.features & 8U))
        return 4;
    if (role_capability(d, role))
        return 4;
    tkga_resource *r = nullptr;
    uint8_t error = target_identity(d, role, r);
    if (error)
        return error;
    if ((error = image_state(d, r, true, d.targets[role])))
        return error;
    region original = op == 0x31 || op == 0x62 ? bounds(*r) : rectangle(b, 5);
    region area = op == 0x31 ? bounds(*r) : effective(d, *r, original);
    if (area.empty())
        return 0;
    uint8_t index = 0;
    if (op == 0x62) {
        const auto points = line(d, *r, b);
        if (points.empty())
            return 0;
        if ((error = find_color(d, *r, color(b, 13), index)))
            return error;
        for (const auto &p : points)
            tkga_put(*r, p.x, p.y, index);
        return 0;
    }
    if (op == 0x64) {
        const int64_t delta_x = tkga_s16(b, 13), delta_y = tkga_s16(b, 15);
        if (!delta_x && !delta_y)
            return 0;
        const region source_region = intersect(original, bounds(*r));
        const region copied = {source_region.x0 + delta_x, source_region.y0 + delta_y,
                               source_region.x1 + delta_x, source_region.y1 + delta_y};
        const region covered = intersect(area, copied);
        const bool exposed = covered.x0 != area.x0 || covered.y0 != area.y0 ||
                             covered.x1 != area.x1 || covered.y1 != area.y1;
        if (exposed && (error = find_color(d, *r, color(b, 17), index)))
            return error;
        visit(area, delta_x > 0, delta_y > 0, [&](int64_t x, int64_t y) {
            const int64_t qx = x - delta_x, qy = y - delta_y;
            const bool inside = qx >= source_region.x0 && qx < source_region.x1 &&
                                qy >= source_region.y0 && qy < source_region.y1;
            tkga_put(*r, x, y, inside ? tkga_pixel(*r, qx, qy) : index);
        });
        return 0;
    }
    const bool outline = op == 0x63 && b[16] == 0;
    if (outline && area.x0 > original.x0 && area.x1 < original.x1 && area.y0 > original.y0 &&
        area.y1 < original.y1)
        return 0;
    if ((error = find_color(d, *r, color(b, op == 0x31 ? 5U : 13U), index)))
        return error;
    visit(area, false, false, [&](int64_t x, int64_t y) {
        if (!outline || x == original.x0 || x == original.x1 - 1 || y == original.y0 ||
            y == original.y1 - 1)
            tkga_put(*r, x, y, index);
    });
    return 0;
}
} // namespace

uint8_t tkga_graphics_command(tkga_device &d, const std::vector<uint8_t> &b) {
    const uint8_t op = b[0];
    try {
        if (op >= 0x20 && op <= 0x22)
            return palette_command(d, b);
        if (op == 0x30)
            return bind_command(d, b);
        if (op == 0x33 || op == 0x60 || op == 0x61)
            return copy_command(d, b);
        if (op == 0x31 || op == 0x32 || (op >= 0x62 && op <= 0x64))
            return raster_command(d, b);
        return 254;
    } catch (const std::bad_alloc &) {
        return 5;
    } // No writes precede allocation-dependent preflight.
}
extern "C" uint8_t tkga_target_handle(tkga_device *d, uint8_t role, uint16_t *out_handle,
                                      uint8_t *out_bound) {
    if (!d || role > 2 || !out_handle || !out_bound)
        return TKGA_HOST_INVALID_ARGUMENT;
    *out_bound = d->target_valid[role] ? 1 : 0;
    *out_handle = d->target_valid[role] ? d->targets[role] : 0;
    return TKGA_HOST_OK;
}
extern "C" uint8_t tkga_resource_rgb_readback(tkga_device *d, uint16_t handle, uint8_t *out_rgb,
                                              uint32_t capacity, uint32_t *out_length) {
    if (!d || !out_length || !out_rgb)
        return TKGA_HOST_INVALID_ARGUMENT;
    const auto found = d->resources.find(handle);
    if (found == d->resources.end())
        return TKGA_HOST_INVALID_ARGUMENT;
    const auto &r = found->second;
    const uint64_t length = static_cast<uint64_t>(r.width) * r.height * 3U;
    if (!r.valid || !r.defined || r.kind == 3 || d->palettes.empty() ||
        length > std::numeric_limits<uint32_t>::max())
        return TKGA_HOST_INVALID_ARGUMENT;
    *out_length = static_cast<uint32_t>(length);
    if (capacity < length)
        return TKGA_HOST_INVALID_ARGUMENT;
    // Validate every palette index before output, including reduced software profiles.
    for (unsigned y = 0; y < r.height; ++y)
        for (unsigned x = 0; x < r.width; ++x)
            if (tkga_pixel(r, x, y) >= d->profile.palette_entries)
                return TKGA_HOST_INVALID_ARGUMENT;
    uint32_t offset = 0;
    for (unsigned y = 0; y < r.height; ++y)
        for (unsigned x = 0; x < r.width; ++x) {
            const uint32_t rgb = d->palettes[0][tkga_pixel(r, x, y)];
            out_rgb[offset++] = static_cast<uint8_t>((rgb >> 16U) & 255U);
            out_rgb[offset++] = static_cast<uint8_t>((rgb >> 8U) & 255U);
            out_rgb[offset++] = static_cast<uint8_t>(rgb & 255U);
        }
    return TKGA_HOST_OK;
}
