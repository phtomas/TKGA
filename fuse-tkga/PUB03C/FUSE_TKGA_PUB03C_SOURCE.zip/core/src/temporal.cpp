#include "core_state.hpp"
#include <algorithm>
#include <new>

bool tkga_serial_reached(uint16_t current, uint16_t target) {
    return static_cast<uint16_t>(current - target) < 32768U;
}
bool tkga_busy(const tkga_device &d) {
    return d.reset_active || !d.retiring_scenes.empty() || !d.commands.empty() || !d.upload.queued.empty() || !d.upload.outstanding.empty() ||
           d.upload.state == 2 || d.upload.state == 3 || d.pending || d.mode_pending_valid;
}
uint8_t tkga_ack(tkga_device &d, uint16_t tag) {
    if (d.reset_active || !d.frame_event || tag != d.last_presented) {
        tkga_error(d, 7);
        return 7;
    }
    d.frame_event = false;
    return 0;
}
void tkga_mode_reset_begin(tkga_device &d) { d.mode_pending_valid = false; }
void tkga_mode_reset_complete(tkga_device &d) { d.mode_active = 0; }
uint8_t tkga_temporal_command(tkga_device &d, const tkga_packet &packet) {
    const auto &b = packet.bytes;
    if (b[0] == 1) {
        if (b[5] || b[4] > 2)
            return 3;
        if (b[4] == 2 || (b[4] == 1 && (!d.profile.present || !(d.profile.target_mask & 3U))))
            return 4;
        if (d.mode_pending_valid)
            return 7;
        if (b[4] != d.mode_active) {
            d.mode_pending_valid = true;
            d.mode_pending_value = b[4];
        }
        return 0;
    }
    if (b[0] == 3) {
        const uint16_t tag = tkga_u16(b, 4);
        const uint16_t delta = static_cast<uint16_t>(tag - d.completed_fence);
        if (d.fence_valid && (!delta || delta >= 32768U))
            return 3;
        if (d.data_retired < packet.data_watermark)
            return 255;
        d.completed_fence = tag;
        d.fence_valid = true;
        return 0;
    }
    if (b[0] != 4)
        return 254;
    if (b[6])
        return 3;
    if (!d.profile.present || !(d.profile.target_mask & 3U))
        return 4;
    const uint8_t role = (d.profile.target_mask & 2U) ? 1 : 0;
    if (!d.target_valid[role])
        return 7;
    const uint16_t handle = d.targets[role];
    const auto it = d.resources.find(handle);
    if (it == d.resources.end())
        return 6;
    if (it->second.kind != 4)
        return 3;
    // Complete scene consumption preflight, before pending ownership/state effects.
    const auto preflight = tkga_scene_preflight(d, d.layers, d.sprites, handle);
    if (preflight) return preflight;
    if (d.pending || d.frame_event) return 7;
    try {
        auto scene = std::make_unique<tkga_scene>();
        const auto error =
            tkga_compose_scene(d, d.layers, d.sprites, handle, scene->indexed, scene->rgb);
        if (error)
            return error;
        scene->tag = tkga_u16(b, 4);
        scene->handle = handle;
        scene->role = role;
        scene->format = it->second.format;
        scene->width = it->second.width;
        scene->height = it->second.height;
        scene->bindings = d.targets;
        scene->binding_valid = d.target_valid;
        scene->layers = d.layers;
        scene->sprites = d.sprites;
        scene->palettes = d.palettes;
        scene->clip = {d.clip_x, d.clip_y, d.clip_w, d.clip_h};
        scene->clip_enabled = d.clip_enabled;
        scene->handles.insert(handle);
        for (const auto &l : d.layers)
            if (l.enabled) {
                scene->handles.insert(l.atlas);
                scene->handles.insert(l.map);
            }
        for (const auto &s : d.sprites)
            if (s.enabled)
                scene->handles.insert(s.handle);
        // Software convenience: only consumed resources are copied for diagnostics.
        // Architecture requires captured metadata + lease semantics, not these copies.
        for (auto h : scene->handles)
            scene->resources.emplace(h, d.resources.at(h));
        scene->sequence = d.present_sequence + 1;
        for (auto h : scene->handles)
            ++d.resources.at(h).read_leases;
        ++d.present_sequence;
        d.pending = std::move(scene);
        return 0;
    } catch (const std::bad_alloc &) {
        return 5;
    }
}
extern "C" uint8_t tkga_backend_ready(tkga_device *d, uint8_t ready) {
    if (!d || ready > 1)
        return TKGA_HOST_INVALID_ARGUMENT;
    d->backend_ready = ready != 0;
    return 0;
}
extern "C" uint8_t tkga_boundary_begin(tkga_device *d) {
    if (!d || d->boundary_open)
        return TKGA_HOST_INVALID_ARGUMENT;
    d->boundary_open = true;
    d->boundary_session=d->session;
    d->boundary_present = d->pending ? d->pending->sequence : 0;
    d->boundary_mode = d->mode_pending_valid;
    d->boundary_mode_value = d->mode_pending_value;
    d->boundary_ready = d->backend_ready;
    return 0;
}
extern "C" uint8_t tkga_boundary_end(tkga_device *d, uint8_t ack_valid, uint16_t ack_tag) {
    if (!d || !d->boundary_open || ack_valid > 1)
        return TKGA_HOST_INVALID_ARGUMENT;
    if(d->boundary_session!=d->session) {d->boundary_open=false;return ack_valid && tkga_ack_epoch(*d,d->boundary_session,ack_tag) ? TKGA_HOST_REJECTED : TKGA_HOST_OK;}
    if(d->reset_active) {
        if(ack_valid) tkga_ack(*d,ack_tag);
        d->reset_detached=true;
        if(d->published) d->retiring_scenes.push_back(std::move(d->published));
        tkga_retire_scenes(*d);d->boundary_open=false;
        return ack_valid ? TKGA_HOST_REJECTED : TKGA_HOST_OK;
    }
    try {d->retiring_scenes.reserve(d->retiring_scenes.size()+1);} catch(const std::bad_alloc &) {return TKGA_HOST_ALLOCATION_FAILED;}
    // ACK evaluates the live pre-transition event; publication then wins this instant.
    const uint8_t ack_error = ack_valid ? tkga_ack(*d, ack_tag) : 0;
    if (d->boundary_mode) {
        d->mode_active = d->boundary_mode_value;
        d->mode_pending_valid = false;
    }
    if (d->boundary_present && d->boundary_ready && d->pending &&
        d->pending->sequence == d->boundary_present) {
        auto old = std::move(d->published);
        d->published = std::move(d->pending);
        d->last_presented = d->published->tag;
        d->frame_event = true;
        // Synchronous software readbacks have no outstanding readers. Replacement
        // installs B first, then retires A here; never at acceptance/commit of B.
        if(old) d->retiring_scenes.push_back(std::move(old));
        tkga_retire_scenes(*d);
    }
    d->boundary_open = false;
    return ack_error ? TKGA_HOST_REJECTED : TKGA_HOST_OK;
}
extern "C" uint8_t tkga_logical_source(tkga_device *d, uint8_t *source) {
    if (!d || !source)
        return TKGA_HOST_INVALID_ARGUMENT;
    *source = (d->mode_active == 1 && d->published) ? 1 : 0;
    return 0;
}
extern "C" uint8_t tkga_frame_readback(tkga_device *d, uint8_t pending, uint8_t *indexed,
                                       uint32_t indexed_capacity, uint32_t *indexed_length,
                                       uint8_t *rgb, uint32_t rgb_capacity, uint32_t *rgb_length,
                                       uint16_t *tag) {
    if (!d || pending > 1 || !indexed_length || !rgb_length || !tag)
        return TKGA_HOST_INVALID_ARGUMENT;
    const auto *s = pending ? d->pending.get() : d->published.get();
    if (!s)
        return TKGA_HOST_REJECTED;
    *indexed_length = static_cast<uint32_t>(s->indexed.size());
    *rgb_length = static_cast<uint32_t>(s->rgb.size());
    *tag = s->tag;
    if (!indexed || !rgb || indexed_capacity < s->indexed.size() || rgb_capacity < s->rgb.size())
        return TKGA_HOST_INVALID_ARGUMENT;
    std::copy(s->indexed.begin(), s->indexed.end(), indexed);
    std::copy(s->rgb.begin(), s->rgb.end(), rgb);
    return 0;
}

extern "C" uint8_t tkga_get_frame_info(const tkga_device *d, uint8_t pending,
                                       tkga_frame_info *out_info) {
    if (!d || pending > 1 || !out_info)
        return TKGA_HOST_INVALID_ARGUMENT;
    *out_info = tkga_frame_info{};
    const auto *s = pending ? d->pending.get() : d->published.get();
    if (!s)
        return TKGA_HOST_OK;
    out_info->valid = 1;
    out_info->format = s->format;
    out_info->role = s->role;
    out_info->base_handle = s->handle;
    out_info->width = s->width;
    out_info->height = s->height;
    out_info->tag = s->tag;
    out_info->indexed_length = static_cast<uint32_t>(s->indexed.size());
    out_info->rgb_length = static_cast<uint32_t>(s->rgb.size());
    return TKGA_HOST_OK;
}
