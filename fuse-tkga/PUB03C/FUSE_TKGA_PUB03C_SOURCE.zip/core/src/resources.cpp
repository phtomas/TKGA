#include "core_state.hpp"
#include <algorithm>
#include <new>

bool tkga_upload_active(const tkga_device &d) {
    return d.upload.state >= 1 && d.upload.state <= 3;
}
namespace {
uint8_t validate_object(tkga_device &d,tkga_resource &r) {
    if (std::find(r.coverage.begin(),r.coverage.end(),0)!=r.coverage.end()) return 7;
    if(r.kind==3) return 0;
    if(r.bytes.size()<6) return 3;
    const auto &b=r.bytes;
    if(b[0]!=1 || (b[1]!=1 && b[1]!=2)) return 3;
    if(!(d.profile.formats & (1U << (b[1]-1)))) return 4;
    const uint16_t w=tkga_u16(b,2),h=tkga_u16(b,4);
    if(!w || !h || w>d.profile.max_width || h>d.profile.max_height) return 8;
    const uint32_t pitch=b[1]==2 ? w : (static_cast<uint32_t>(w)+1)/2;
    if(6U+pitch*h!=b.size()) return 8;
    if(r.defined && (r.format!=b[1] || r.width!=w || r.height!=h)) return 7;
    if(b[1]==1 && (w&1)) {
        for(uint32_t y=0;y<h;++y) if(b[6+y*pitch+pitch-1]&15U) return 3;
    }
    // Commit definition only after CRC success, in tick().
    return 0;
}
}
void tkga_upload_tick(tkga_device &d) {
    auto &u=d.upload;
    if(!tkga_upload_active(d)) return;
    auto found=d.resources.find(u.handle);
    if(found==d.resources.end()) return;
    auto &r=found->second;
    while(d.write_auto_ack && !u.outstanding.empty() && u.outstanding.front().retire_step<=d.step) {
        const auto write=u.outstanding.front(); u.outstanding.pop_front();
        tkga_finish_write(d,u.handle,write);
    }
    if(!u.queued.empty()) {
        u.outstanding.push_back({u.offset+u.issued,u.queued.front(),d.step+2,u.data_base+u.issued+1,d.session,r.identity,d.next_job++});
        u.queued.pop_front(); ++u.issued;
    }
    if(u.state==2 && u.queued.empty() && u.outstanding.empty()) {
        if(u.abort) {d.data_retired=u.data_base+u.admitted;u.state=5; return;}
        const uint8_t error=validate_object(d,r);
        if(error) {tkga_error(d,error);u.state=6;return;}
        if(u.verify) {u.state=3;return;}
        if(r.kind!=3) {r.format=r.bytes[1];r.width=tkga_u16(r.bytes,2);r.height=tkga_u16(r.bytes,4);}
        r.defined=true;r.valid=true;u.state=4;
    } else if(u.state==3) {
        if((u.crc^UINT32_C(0xffffffff))!=u.expected_crc) {tkga_error(d,11);u.state=6;return;}
        if(r.kind!=3) {r.format=r.bytes[1];r.width=tkga_u16(r.bytes,2);r.height=tkga_u16(r.bytes,4);}
        r.defined=true;r.valid=true;u.state=4;
    }
}
uint8_t tkga_resource_command(tkga_device &d,const std::vector<uint8_t> &b) {
    const uint8_t op=b[0];
    if(op<0x10 || op>0x14) return 254;
    const uint16_t handle=tkga_u16(b,4);
    auto found=d.resources.find(handle);
    if(op==0x10) {
        const uint8_t kind=b[6];const uint32_t size=tkga_u32(b,8);
        if((kind!=1 && kind!=3 && kind!=4) || b[7]) return 3;
        if((kind==3 && !(d.profile.features&2)) || (kind==4 && !(d.profile.features&1))) return 4;
        if(!handle) return 6;
        if(!size || size>d.profile.max_resource_bytes) return 8;
        if(found!=d.resources.end()) return 7;
        if(d.resources.size()>=d.profile.max_handles) return 5;
        try {
            tkga_resource r;r.identity=d.next_identity;r.kind=kind;r.bytes.resize(size);r.coverage.resize(size);
            d.resources.emplace(handle,std::move(r));
            ++d.next_identity;
        } catch(const std::bad_alloc &) {return 5;}
        return 0;
    }
    if(op==0x12) {
        const uint32_t offset=tkga_u32(b,6),length=tkga_u32(b,10);
        if((b[14]&0xfeU) || !length) return 3;
        if(found==d.resources.end()) return 6;
        auto &r=found->second;
        if(offset>r.bytes.size() || length>r.bytes.size()-offset) return 8;
        if(tkga_upload_active(d)) return 7;
        if(r.read_leases || r.layer_leases || r.sprite_leases) return 7;
        if(!r.defined && (offset!=0 || length!=r.bytes.size())) return 7;
        if(r.defined && r.kind!=3 && offset<6 && !(offset==0 && length==r.bytes.size())) return 7;
        tkga_upload session;session.state=1;session.handle=handle;session.offset=offset;
        session.length=length;session.verify=(b[14]&1U)!=0;
        session.data_base=d.data_admitted;d.upload=std::move(session);r.valid=false;
        return 0;
    }
    if(op==0x13) {
        const uint32_t crc=tkga_u32(b,6);
        if(tkga_upload_active(d) && !d.upload.verify && crc!=0) return 3;
        if(found==d.resources.end()) return 6;
        auto &u=d.upload;
        if(u.waiting_command) return tkga_upload_active(d) ? 255 : 0;
        if(u.state!=1 || u.handle!=handle || u.admitted!=u.length) return 7;
        u.expected_crc=crc;u.state=2;u.waiting_command=true;
        return 255;
    }
    if(found==d.resources.end()) return 6;
    if(op==0x11) {
        if(tkga_upload_active(d) && d.upload.handle==handle) return 7;
        if(found->second.read_leases || found->second.layer_leases || found->second.sprite_leases) return 7;
        for(unsigned i=0;i<3;++i) if(d.target_valid[i] && d.targets[i]==handle) return 7;
        for(auto &l:d.layers) {
            if(l.atlas_bound && l.atlas==handle) l.atlas_bound=false;
            if(l.map_bound && l.map==handle) l.map_bound=false;
        }
        for(auto &s:d.sprites) if(s.atlas_bound && s.handle==handle) s.atlas_bound=false;
        d.resources.erase(found);return 0;
    }
    if(op==0x14) {
        auto &u=d.upload;
        if(u.waiting_command) return tkga_upload_active(d) ? 255 : 0;
        if(!tkga_upload_active(d)) return 0;
        if(u.handle!=handle || u.state!=1) return 7;
        u.queued.clear();u.abort=true;u.state=2;u.waiting_command=true;
        return 255;
    }
    return 254;
}
extern "C" uint8_t tkga_resource_readback(tkga_device *d,uint16_t handle,
    uint8_t *out_bytes,uint32_t capacity,uint32_t *out_length,uint8_t *out_valid) {
    if(!d || !out_length || !out_valid) return TKGA_HOST_INVALID_ARGUMENT;
    const auto found=d->resources.find(handle);
    if(found==d->resources.end()) return TKGA_HOST_INVALID_ARGUMENT;
    const auto &r=found->second;*out_length=static_cast<uint32_t>(r.bytes.size());
    *out_valid=r.valid ? 1 : 0;
    if(capacity<r.bytes.size() || !out_bytes) return TKGA_HOST_INVALID_ARGUMENT;
    std::copy(r.bytes.begin(),r.bytes.end(),out_bytes);return TKGA_HOST_OK;
}
