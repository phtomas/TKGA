#include "core_state.hpp"
#include <algorithm>
#include <new>
#include <tuple>

uint8_t tkga_sprite_validate(const tkga_device &d, const tkga_sprite &s,
                             const tkga_resource *base) {
    const auto it = s.atlas_bound ? d.resources.find(s.handle) : d.resources.end();
    const auto *a = it == d.resources.end() ? nullptr : &it->second;
    if (s.atlas_bound && !a)
        return 6;
    if (a && a->kind != 1)
        return 3;
    if (a && a->defined && base && base->defined && a->format != base->format)
        return 3;
    if (!s.w || !s.h || s.w > d.profile.max_sprite_width || s.h > d.profile.max_sprite_height)
        return 8;
    if (a && a->defined) {
        if (s.src_x >= a->width || s.src_y >= a->height)
            return 8;
        const uint32_t cols = (a->width - s.src_x) / s.w, rows = (a->height - s.src_y) / s.h;
        if (!cols || !rows || s.frame >= cols * rows)
            return 8;
        if (s.transparent_index >= (a->format == 1 ? 16U : 256U))
            return 8;
    }
    if (!s.defined || !s.atlas_bound || !a || !a->defined || !a->valid ||
        (tkga_upload_active(d) && d.upload.handle == s.handle))
        return 7;
    return 0;
}
uint8_t tkga_sprite_command(tkga_device &d, const std::vector<uint8_t> &b) {
    const auto op = b[0];
    if (op < 0x50 || op > 0x55)
        return 254;
    if (op == 0x53 && ((tkga_u16(b, 6) & 0xfff0U) || b[8]))
        return 3;
    if (op == 0x55 && b[6] > 1)
        return 3;
    if (!(d.profile.features & 4U))
        return 4;
    const auto id = tkga_u16(b, 4);
    // DEFINE carries a resource identity; D11 identity/type precedes ID range.
    if (op == 0x50) {
        const auto it = d.resources.find(tkga_u16(b, 6));
        if (it == d.resources.end())
            return 6;
        if (it->second.kind != 1)
            return 3;
    } else if (id < d.sprites.size() && d.sprites[id].atlas_bound) {
        const auto it = d.resources.find(d.sprites[id].handle);
        if (it == d.resources.end())
            return 6;
        if (it->second.kind != 1)
            return 3;
    }
    if (id >= d.profile.max_sprites)
        return 8;
    auto &old = d.sprites[id];
    auto next = old;
    if (op == 0x50) {
        next = {};
        next.defined = true;
        next.atlas_bound = true;
        next.handle = tkga_u16(b, 6);
        next.src_x = tkga_u16(b, 8);
        next.src_y = tkga_u16(b, 10);
        next.w = tkga_u16(b, 12);
        next.h = tkga_u16(b, 14);
        next.flags = 8;
    } else if (op == 0x51) {
        next.x = tkga_s16(b, 6);
        next.y = tkga_s16(b, 8);
    } else if (op == 0x52)
        next.frame = tkga_u16(b, 6);
    else if (op == 0x53) {
        next.flags = tkga_u16(b, 6);
        next.palette = b[8];
        next.transparent_index = b[9];
    } else if (op == 0x54)
        next.priority = b[6];
    else
        next.enabled = b[6] != 0;
    if (op != 0x50 && !old.defined)
        return 7;
    const auto error = tkga_sprite_validate(d, next);
    if (error)
        return error;
    // PC5-AQ01 HUMAN RATIFIED: framebuffer/format checks belong to consumption.
    if (old.enabled && (!next.enabled || old.handle != next.handle))
        --d.resources.at(old.handle).sprite_leases;
    if (next.enabled && (!old.enabled || old.handle != next.handle))
        ++d.resources.at(next.handle).sprite_leases;
    old = next;
    return 0;
}
std::vector<uint16_t> tkga_sprite_survivors(const tkga_profile &p,
                                            const std::vector<tkga_sprite> &sprites, uint16_t width,
                                            uint16_t height, uint16_t line) {
    std::vector<uint16_t> ids;
    if (line >= height)
        return ids;
    for (size_t i = 0; i < sprites.size(); ++i) {
        const auto &s = sprites[i];
        if (s.defined && s.atlas_bound && s.enabled && s.y <= line &&
            static_cast<int64_t>(s.y) + s.h > line && s.x < width &&
            static_cast<int64_t>(s.x) + s.w > 0)
            ids.push_back(static_cast<uint16_t>(i));
    }
    std::sort(ids.begin(), ids.end(), [&](uint16_t a, uint16_t b) {
        return std::tie(sprites[a].priority, a) > std::tie(sprites[b].priority, b);
    });
    if (ids.size() > p.sprites_per_line)
        ids.resize(p.sprites_per_line);
    return ids;
}

extern "C" uint8_t tkga_scanline_survivors(tkga_device *d, uint16_t base, uint16_t line,
                                           uint16_t *out_ids, uint16_t capacity,
                                           uint16_t *out_count) {
    if (!d || !out_ids || !out_count)
        return TKGA_HOST_INVALID_ARGUMENT;
    const auto it = d->resources.find(base);
    if (it == d->resources.end() || it->second.kind != 4 || !it->second.valid ||
        !it->second.defined)
        return TKGA_HOST_REJECTED;
    for (const auto &s : d->sprites)
        if (s.enabled && tkga_sprite_validate(*d, s, &it->second))
            return TKGA_HOST_REJECTED;
    try {
        const auto ids = tkga_sprite_survivors(d->profile, d->sprites, it->second.width,
                                               it->second.height, line);
        *out_count = static_cast<uint16_t>(ids.size());
        if (capacity < ids.size())
            return TKGA_HOST_INVALID_ARGUMENT;
        std::copy(ids.begin(), ids.end(), out_ids);
        return TKGA_HOST_OK;
    } catch (const std::bad_alloc &) {
        return TKGA_HOST_ALLOCATION_FAILED;
    }
}
