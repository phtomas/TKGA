#include "core_state.hpp"
#include <algorithm>
#include <limits>
#include <new>
#include <tuple>

namespace {
const tkga_resource *resource(const tkga_device &d, uint16_t h) {
    const auto it = d.resources.find(h);
    return it == d.resources.end() ? nullptr : &it->second;
}
bool busy(const tkga_device &d, uint16_t h) {
    return tkga_upload_active(d) && d.upload.handle == h;
}
uint32_t count(const tkga_resource &a, const tkga_layer &l) {
    return (static_cast<uint32_t>(a.width) / l.tile_w) * (a.height / l.tile_h);
}
// Explicit object-dependent phases; composition uses the same read-only checks.
uint8_t identities(const tkga_device &d, const tkga_layer &l,
                   const tkga_resource *base = nullptr) {
    const auto *a = l.atlas_bound ? resource(d, l.atlas) : nullptr;
    const auto *m = l.map_bound ? resource(d, l.map) : nullptr;
    if ((l.atlas_bound && !a) || (l.map_bound && !m)) return 6;
    if ((a && a->kind != 1) || (m && m->kind != 3)) return 3;
    if (a && a->defined && base && base->defined && a->format != base->format) return 3;
    return 0;
}
uint8_t geometry(const tkga_device &d, const tkga_layer &l) {
    const auto *a = l.atlas_bound ? resource(d, l.atlas) : nullptr;
    const auto *m = l.map_bound ? resource(d, l.map) : nullptr;
    if (a && a->defined && (!l.tile_w || !l.tile_h ||
        a->width % l.tile_w || a->height % l.tile_h || !count(*a, l) || count(*a, l) > 256)) return 8;
    if (m && m->bytes.size() != static_cast<uint32_t>(l.map_w) * l.map_h) return 8;
    return 0;
}
uint8_t layer_state(const tkga_device &d, const tkga_layer &l, bool complete) {
    const auto *a = l.atlas_bound ? resource(d, l.atlas) : nullptr;
    const auto *m = l.map_bound ? resource(d, l.map) : nullptr;
    if (complete && (!l.atlas_bound || !l.map_bound)) return 7;
    if ((a && (!a->valid || !a->defined || busy(d, l.atlas))) ||
        (m && (!m->valid || !m->defined || busy(d, l.map)))) return 7;
    return 0;
}
uint8_t validate(const tkga_device &d, const tkga_layer &l, bool complete,
                 const tkga_resource *base = nullptr,
                 const std::vector<uint8_t> *candidate = nullptr) {
    auto e = identities(d, l, base); if (e) return e;
    e = geometry(d, l); if (e) return e;
    const auto *a = l.atlas_bound ? resource(d, l.atlas) : nullptr;
    const auto *m = l.map_bound ? resource(d, l.map) : nullptr;
    if (a && a->defined && m) {
        const auto &data = candidate ? *candidate : m->bytes;
        for (auto t : data) if (t >= count(*a, l)) return 3;
    }
    return layer_state(d, l, complete);
}
int64_t euclidean(int64_t x, int64_t n) {
    const auto r = x % n;
    return r < 0 ? r + n : r;
}
} // namespace
uint8_t tkga_layer_command(tkga_device &d, const std::vector<uint8_t> &b) {
    const uint8_t op = b[0];
    if (op < 0x40 || op > 0x45)
        return 254;
    const auto id = b[4];
    // Phase5: only literal payload flags/enums, independent of objects/IDs.
    if (op == 0x40 &&
        ((b[7] != 8 && b[7] != 16) || b[7] != b[8] || (b[9] != 4 && b[9] != 8) || b[10]))
        return 3;
    if (op == 0x42 && ((tkga_u16(b, 6) & 0xfff8U) || b[8]))
        return 3;
    if (op == 0x44 && b[5] > 1)
        return 3;
    // Phase6: capability precedes resource identity and the layer-ID range.
    if (!(d.profile.features & 2U))
        return 4;
    if (op == 0x40 && !(d.profile.tile_geometries & (b[7] == 8 ? 1U : 2U)))
        return 4;
    // Phase7: incoming resource identity/type is evaluable even for an
    // out-of-range layer ID. Frozen incompatible-kind error remains3.
    const tkga_resource *incoming = nullptr;
    if (op == 0x40 || op == 0x41) {
        incoming = resource(d, tkga_u16(b, 5));
        if (!incoming)
            return 6;
        if (incoming->kind != (op == 0x40 ? 1 : 3))
            return 3;
    }
    // Phase8: the frozen layer-ID exception is error3, not a payload enum.
    if (id >= d.profile.max_layers)
        return 3;
    auto &old = d.layers[id];
    auto next = old;
    uint8_t error = 0;
    if (op == 0x40 || op == 0x41) {
        const auto h = tkga_u16(b, 5);
        const auto *r = incoming;
        if (op == 0x40) {
            if (r->defined && b[9] != (r->format == 1 ? 4 : 8))
                return 3;
            next.atlas_bound = true;
            next.atlas = h;
            next.tile_w = b[7];
            next.tile_h = b[8];
        } else {
            next.map_w = tkga_u16(b, 7);
            next.map_h = tkga_u16(b, 9);
            next.map_bound = true;
            next.map = h;
            if ((error = identities(d, next))) return error;
            if (!next.map_w || !next.map_h || next.map_w > d.profile.map_max_width ||
                next.map_h > d.profile.map_max_height)
                return 8;
        }
        if ((error = validate(d, next, false)))
            return error;
        if (old.enabled)
            return 7;
    } else if (op == 0x42) {
        next.priority = b[5];
        next.flags = tkga_u16(b, 6);
        next.palette = b[8];
        if (next.enabled && (error = validate(d, next, true)))
            return error;
    } else if (op == 0x43) {
        next.scroll_x = tkga_s16(b, 5);
        next.scroll_y = tkga_s16(b, 7);
        if (next.enabled && (error = validate(d, next, true)))
            return error;
    } else if (op == 0x44) {
        next.enabled = b[5] != 0;
        if (next.enabled) {
            // PC4-AQ01 HUMAN RATIFIED: enable validates only layer-local
            // dependencies. Concrete base/format is validated by composition.
            if ((error = validate(d, next, true)))
                return error;
        }
        if (next.enabled != old.enabled) {
            auto &a = d.resources.at(old.atlas);
            auto &m = d.resources.at(old.map);
            if (next.enabled) {
                ++a.layer_leases;
                ++m.layer_leases;
            } else {
                --a.layer_leases;
                --m.layer_leases;
            }
        }
    } else {
        const uint32_t x = tkga_u16(b, 5), y = tkga_u16(b, 7), w = tkga_u16(b, 9),
                       h = tkga_u16(b, 11);
        const auto *a = old.atlas_bound ? resource(d, old.atlas) : nullptr;
        const auto *m = old.map_bound ? resource(d, old.map) : nullptr;
        if ((old.atlas_bound && !a) || (old.map_bound && !m))
            return 6;
        if ((a && a->kind != 1) || (m && m->kind != 3))
            return 3;
        for (const auto &peer : d.layers) {
            if (&peer != &old &&
                !(peer.enabled && peer.map_bound && old.map_bound && peer.map == old.map))
                continue;
            const auto *atlas = peer.atlas_bound ? resource(d, peer.atlas) : nullptr;
            if (peer.atlas_bound && !atlas)
                return 6;
            if (atlas && atlas->kind != 1)
                return 3;
        }
        if (old.map_bound && (x + w > old.map_w || y + h > old.map_h))
            return 8;
        // Phase8: validate all shared geometries and virtual candidate entries
        // without allocation. This keeps state/lease failures ahead of capacity.
        auto shares = [&](const tkga_layer &peer) {
            return &peer == &old || (peer.enabled && peer.map_bound && old.map_bound && peer.map == old.map);
        };
        for (const auto &peer : d.layers)
            if (shares(peer) && (error = geometry(d, peer))) return error;
        if (m) {
            for (const auto &peer : d.layers) {
                if (!shares(peer)) continue;
                const auto *atlas = peer.atlas_bound ? resource(d, peer.atlas) : nullptr;
                if (!atlas || !atlas->defined) continue;
                for (size_t i = 0; i < m->bytes.size(); ++i) {
                    const auto row = i / old.map_w, col = i % old.map_w;
                    const auto t = row >= y && row < y + h && col >= x && col < x + w
                        ? b[13U + (row-y)*w + col-x] : m->bytes[i];
                    if (t >= count(*atlas, peer)) return 3;
                }
            }
        }
        // Phase9: no binding/validity/lease effect, and no allocation yet.
        for (const auto &peer : d.layers)
            if (shares(peer) && (error = layer_state(d, peer, true))) return error;
        if (m->read_leases) return 7;
        // Phase10: capacity. Successful preflight commits all bytes once.
        try {
            auto candidate = m->bytes;
            for (uint32_t row = 0; row < h; ++row)
                for (uint32_t col = 0; col < w; ++col)
                    candidate[(y + row) * old.map_w + x + col] = b[13U + row * w + col];
            d.resources.at(old.map).bytes.swap(candidate);
            return 0;
        } catch (const std::bad_alloc &) { return 5; }
    }
    old = next;
    return 0;
}
uint8_t tkga_scene_preflight(const tkga_device &d, const std::vector<tkga_layer> &layers,
                            const std::vector<tkga_sprite> &sprites, uint16_t handle) {
    const auto *base = resource(d, handle);
    if (!base)
        return 6;
    if (base->kind != 4)
        return 3;
    for (const auto &l : layers)
        if (l.enabled) {
            const auto e = validate(d, l, true, base);
            if (e)
                return e;
        }
    for (const auto &sprite : sprites)
        if (sprite.enabled) {
            const auto e = tkga_sprite_validate(d, sprite, base);
            if (e)
                return e;
        }
    if (!base->valid || !base->defined || busy(d, handle) || d.palettes.empty())
        return 7;
    if (static_cast<uint64_t>(base->width) * base->height * 3U >
        std::numeric_limits<uint32_t>::max())
        return 8;
    return 0;
}
// Explicit immutable logical view: later G09 can supply captured layer metadata
// and a captured device/resource view. This routine has no publication side effect.
uint8_t tkga_compose_scene(const tkga_device &d, const std::vector<tkga_layer> &layers,
                           const std::vector<tkga_sprite> &sprites, uint16_t handle,
                           std::vector<uint8_t> &indexed, std::vector<uint8_t> &rgb) {
    const auto error = tkga_scene_preflight(d, layers, sprites, handle);
    if (error) return error;
    const auto *base = resource(d, handle);
    try {
        tkga_resource output = *base;
        std::vector<std::vector<uint16_t>> survivors(base->height);
        for (uint16_t y = 0; y < base->height; ++y)
            survivors[y] = tkga_sprite_survivors(d.profile, sprites, base->width, base->height, y);
        std::vector<std::tuple<uint8_t, uint8_t, size_t>> order;
        for (size_t i = 0; i < layers.size(); ++i)
            if (layers[i].enabled)
                order.emplace_back(layers[i].priority, 0, i);
        for (size_t i = 0; i < sprites.size(); ++i)
            if (sprites[i].enabled)
                order.emplace_back(sprites[i].priority, 1, i);
        std::sort(order.begin(), order.end());
        for (const auto &item : order) {
            const auto id = std::get<2>(item);
            if (std::get<1>(item) == 1) {
                const auto &sprite = sprites[id];
                const auto &a = d.resources.at(sprite.handle);
                const uint32_t columns = (a.width - sprite.src_x) / sprite.w;
                const int64_t origin_x = sprite.src_x + (sprite.frame % columns) * sprite.w;
                const int64_t origin_y = sprite.src_y + (sprite.frame / columns) * sprite.h;
                const int64_t x0 = std::max<int64_t>(0, sprite.x),
                              y0 = std::max<int64_t>(0, sprite.y);
                const int64_t x1 =
                    std::min<int64_t>(base->width, static_cast<int64_t>(sprite.x) + sprite.w);
                const int64_t y1 =
                    std::min<int64_t>(base->height, static_cast<int64_t>(sprite.y) + sprite.h);
                for (int64_t y = y0; y < y1; ++y) {
                    const auto &line = survivors[static_cast<size_t>(y)];
                    if (std::find(line.begin(), line.end(), static_cast<uint16_t>(id)) ==
                        line.end())
                        continue;
                    for (int64_t x = x0; x < x1; ++x) {
                        if ((sprite.flags & 4U) && d.clip_enabled &&
                            (x < d.clip_x || y < d.clip_y ||
                             x >= static_cast<int64_t>(d.clip_x) + d.clip_w ||
                             y >= static_cast<int64_t>(d.clip_y) + d.clip_h))
                            continue;
                        const int64_t u = x - sprite.x, v = y - sprite.y;
                        const auto raw =
                            tkga_pixel(a, origin_x + ((sprite.flags & 1U) ? sprite.w - 1 - u : u),
                                       origin_y + ((sprite.flags & 2U) ? sprite.h - 1 - v : v));
                        if ((sprite.flags & 8U) && raw == sprite.transparent_index)
                            continue;
                        tkga_put(output, x, y, raw);
                    }
                }
                continue;
            }
            const auto &l = layers[id];
            const auto &a = d.resources.at(l.atlas), &m = d.resources.at(l.map);
            const int64_t mw = static_cast<int64_t>(l.map_w) * l.tile_w;
            const int64_t mh = static_cast<int64_t>(l.map_h) * l.tile_h;
            const uint32_t cols = a.width / l.tile_w;
            for (int64_t y = 0; y < base->height; ++y)
                for (int64_t x = 0; x < base->width; ++x) {
                    int64_t qx = x + l.scroll_x, qy = y + l.scroll_y;
                    if (l.flags & 1U)
                        qx = euclidean(qx, mw);
                    if (l.flags & 2U)
                        qy = euclidean(qy, mh);
                    if (qx < 0 || qy < 0 || qx >= mw || qy >= mh)
                        continue;
                    const auto tile = m.bytes[static_cast<size_t>(qy / l.tile_h) * l.map_w +
                                              static_cast<size_t>(qx / l.tile_w)];
                    const int64_t sx = (tile % cols) * l.tile_w + qx % l.tile_w;
                    const int64_t sy = (tile / cols) * l.tile_h + qy % l.tile_h;
                    const auto raw = tkga_pixel(a, sx, sy);
                    if (raw || !(l.flags & 4U))
                        tkga_put(output, x, y, raw);
                }
        }
        std::vector<uint8_t> out_rgb;
        out_rgb.reserve(static_cast<size_t>(base->width) * base->height * 3U);
        for (int64_t y = 0; y < base->height; ++y)
            for (int64_t x = 0; x < base->width; ++x) {
                const auto index = tkga_pixel(output, x, y);
                if (index >= d.profile.palette_entries)
                    return 7;
                const auto c = d.palettes[0][index];
                out_rgb.push_back(static_cast<uint8_t>(c >> 16U));
                out_rgb.push_back(static_cast<uint8_t>((c >> 8U) & 255U));
                out_rgb.push_back(static_cast<uint8_t>(c & 255U));
            }
        std::vector<uint8_t> out(output.bytes.begin() + 6, output.bytes.end());
        indexed.swap(out);
        rgb.swap(out_rgb);
        return 0;
    } catch (const std::bad_alloc &) {
        return 5;
    }
}
uint8_t tkga_compose(const tkga_device &d, const std::vector<tkga_layer> &layers, uint16_t handle,
                     std::vector<uint8_t> &indexed, std::vector<uint8_t> &rgb) {
    return tkga_compose_scene(d, layers, d.sprites, handle, indexed, rgb);
}
extern "C" uint8_t tkga_composed_readback(tkga_device *d, uint16_t base, uint8_t *raw,
                                          uint32_t raw_capacity, uint32_t *raw_length, uint8_t *rgb,
                                          uint32_t rgb_capacity, uint32_t *rgb_length) {
    if (!d || !raw || !rgb || !raw_length || !rgb_length)
        return TKGA_HOST_INVALID_ARGUMENT;
    std::vector<uint8_t> a, b;
    const auto e = tkga_compose(*d, d->layers, base, a, b);
    if (e)
        return TKGA_HOST_REJECTED;
    *raw_length = static_cast<uint32_t>(a.size());
    *rgb_length = static_cast<uint32_t>(b.size());
    if (raw_capacity < a.size() || rgb_capacity < b.size())
        return TKGA_HOST_INVALID_ARGUMENT;
    std::copy(a.begin(), a.end(), raw);
    std::copy(b.begin(), b.end(), rgb);
    return TKGA_HOST_OK;
}
