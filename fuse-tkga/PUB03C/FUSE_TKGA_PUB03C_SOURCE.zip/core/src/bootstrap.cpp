#include "tkga/tkga.h"
#include "core_state.hpp"
#include <new>

namespace {
constexpr tkga_register_info registers[] = {
#define TKGA_ABI(id, name, width, access, snapshot) {id, width, access, snapshot},
#include "tkga/abi.def"
#undef TKGA_ABI
};
static_assert(sizeof(registers) / sizeof(registers[0]) == 39, "RC1.1 has 39 fields");
bool valid_profile(const tkga_profile &p) {
    if ((p.features & 0xffe0U) || (p.formats & 0xfcU) ||
        (p.target_mask & 0xf8U) || (p.tile_geometries & 0xfcU) || (p.present & 0xfeU)) return false;
    if (p.cmd_capacity < 4 || p.data_capacity == 0 ||
        p.max_cmd_payload > static_cast<uint32_t>(p.cmd_capacity) - 4U) return false;
    if (p.max_handles == 0 || p.max_resource_bytes == 0 || p.formats == 0 ||
        p.max_width == 0 || p.max_height == 0) return false;
    if ((p.features & 1U) && p.target_mask == 0) return false;
    if (p.present && (!(p.features & 1U) || !(p.target_mask & 3U))) return false;
    if (!(p.features & 2U) && (p.max_layers || p.tile_geometries || p.map_max_width || p.map_max_height)) return false;
    if ((p.features & 2U) && (!p.max_layers || !p.tile_geometries || !p.map_max_width || !p.map_max_height)) return false;
    if (!(p.features & 4U) && (p.max_sprites || p.sprites_per_line || p.max_sprite_width || p.max_sprite_height)) return false;
    if ((p.features & 4U) && (!p.max_sprites || !p.sprites_per_line ||
        p.sprites_per_line > p.max_sprites || !p.max_sprite_width || !p.max_sprite_height)) return false;
    if (!(p.features & 16U) && (p.palette_banks || p.palette_entries)) return false;
    if ((p.features & 16U) && (!p.palette_banks || !p.palette_entries)) return false;
    if ((p.features & 1U) && (!(p.features & 16U) ||
        ((p.formats & 1U) && p.palette_entries < 16) ||
        ((p.formats & 2U) && p.palette_entries < 256))) return false;
    /* Largest command: PALETTE 3+3*255; TILEMAP_UPDATE 9+w*h.
       A configurable profile is rejected if it cannot admit its own supported envelope. */
    // Always-supported resource upload needs11; absent features must not
    // impose the envelope of their unsupported commands on a small profile.
    uint32_t largest = 11;
    if (p.features & (1U | 4U)) largest = 12;
    if (p.features & 8U) largest = 17;
    if ((p.features & 16U) && largest < 768) largest = 768;
    if (p.features & 2U) {
        uint32_t tile_payload = 9U + static_cast<uint32_t>(p.map_max_width) * p.map_max_height;
        if (tile_payload > largest) largest = tile_payload;
    }
    return largest <= p.max_cmd_payload;
}
uint32_t constant_value(const tkga_profile &p, uint8_t selector) {
    switch (selector) {
    case TKGA_REG_ID_SIGNATURE: return UINT32_C(0x41474b54);
    case TKGA_REG_IF_VERSION: return TKGA_IF_VERSION;
    case TKGA_REG_CMDSET_VERSION: return TKGA_CMDSET_VERSION;
    case TKGA_REG_CAPS_FEATURES: return p.features;
    case TKGA_REG_CAPS_FORMATS: return p.formats;
    case TKGA_REG_CAPS_MAX_HANDLES: return p.max_handles;
    case TKGA_REG_CAPS_MAX_RESOURCE_BYTES: return p.max_resource_bytes;
    case TKGA_REG_CMD_CAPACITY: return p.cmd_capacity;
    case TKGA_REG_DATA_CAPACITY: return p.data_capacity;
    case TKGA_REG_MAX_CMD_PAYLOAD: return p.max_cmd_payload;
    case TKGA_REG_CAPS_MAX_WIDTH: return p.max_width;
    case TKGA_REG_CAPS_MAX_HEIGHT: return p.max_height;
    case TKGA_REG_CAPS_MAX_SPRITES: return p.max_sprites;
    case TKGA_REG_CAPS_SPRITES_PER_LINE: return p.sprites_per_line;
    case TKGA_REG_CAPS_MAX_LAYERS: return p.max_layers;
    case TKGA_REG_CAPS_PALETTE_BANKS: return p.palette_banks;
    case TKGA_REG_CAPS_PALETTE_ENTRIES: return p.palette_entries;
    case TKGA_REG_CAPS_DESCRIPTOR_VERSION: return 1;
    case TKGA_REG_CAPS_DESCRIPTOR_SIZE: return 6;
    case TKGA_REG_CAPS_TARGET_MASK: return p.target_mask;
    case TKGA_REG_CAPS_TILE_GEOMETRIES: return p.tile_geometries;
    case TKGA_REG_CAPS_MAP_MAX_WIDTH: return p.map_max_width;
    case TKGA_REG_CAPS_MAP_MAX_HEIGHT: return p.map_max_height;
    case TKGA_REG_CAPS_MAX_SPRITE_WIDTH: return p.max_sprite_width;
    case TKGA_REG_CAPS_MAX_SPRITE_HEIGHT: return p.max_sprite_height;
    case TKGA_REG_CAPS_PRESENT: return p.present;
    default: return 0;
    }
}
}

extern "C" {
uint8_t tkga_default_profile(tkga_profile *out_profile) {
    if (!out_profile) return TKGA_HOST_INVALID_ARGUMENT;
    /* VIS capacities, with transport enlarged to fit advertised map update.
       Quantitative software profile, not an architecture minimum. */
    *out_profile = {31, 3, 16, 1048576, 8192, 64, 8188, 256, 256,
                   32, 8, 3, 1, 256, 7, 3, 64, 64, 64, 64, 1};
    return TKGA_HOST_OK;
}
uint8_t tkga_get_register_info(uint8_t selector, tkga_register_info *out_info) {
    if (!out_info) return TKGA_HOST_INVALID_ARGUMENT;
    for (const auto &info : registers) {
        if (info.selector == selector) { *out_info = info; return TKGA_HOST_OK; }
    }
    *out_info = {selector, 0, 0, 0};
    return TKGA_HOST_INVALID_ARGUMENT;
}
uint8_t tkga_create(const tkga_profile *profile, tkga_device **out_device) {
    if (!out_device) return TKGA_HOST_INVALID_ARGUMENT;
    *out_device = nullptr;
    if (!profile || !valid_profile(*profile)) return TKGA_HOST_INVALID_ARGUMENT;
    try { *out_device = new (std::nothrow) tkga_device(*profile); }
    catch (const std::bad_alloc &) { return TKGA_HOST_ALLOCATION_FAILED; }
    return *out_device ? TKGA_HOST_OK : TKGA_HOST_ALLOCATION_FAILED;
}
void tkga_destroy(tkga_device *device) { delete device; }
uint8_t tkga_reg_select8(tkga_device *device, uint8_t selector) {
    if (!device) return TKGA_HOST_INVALID_ARGUMENT;
    tkga_register_info info{};
    if (device->selected == TKGA_REG_FRAME_ACK && device->write_cursor == 1) tkga_error(*device,2);
    if (tkga_get_register_info(selector, &info) == TKGA_HOST_OK && info.dynamic_snapshot &&
        (selector == TKGA_REG_STATUS || !device->snapshot_valid)) tkga_capture(*device);
    device->selected = selector;
    device->cursor = 0;
    device->write_cursor = 0;
    return TKGA_HOST_OK;
}
uint8_t tkga_reg_read8(tkga_device *device, uint8_t *out_value) {
    if (!device || !out_value) return TKGA_HOST_INVALID_ARGUMENT;
    tkga_register_info info{};
    *out_value = 0;
    if (tkga_get_register_info(device->selected, &info) != TKGA_HOST_OK || info.writable)
        return TKGA_HOST_OK;
    if (device->cursor < info.width_bytes) {
        const uint32_t value = info.dynamic_snapshot ? device->snapshot[device->selected] : constant_value(device->profile, device->selected);
        *out_value = static_cast<uint8_t>((value >>
            (8U * device->cursor)) & 0xffU);
        ++device->cursor;
    }
    return TKGA_HOST_OK;
}
}
