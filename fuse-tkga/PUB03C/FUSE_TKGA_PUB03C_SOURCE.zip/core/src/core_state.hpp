#ifndef TKGA_CORE_STATE_HPP
#define TKGA_CORE_STATE_HPP
#include "tkga/tkga.h"
#include <array>
#include <deque>
#include <map>
#include <memory>
#include <set>
#include <vector>
struct tkga_resource {
    uint64_t identity = 0;
    uint8_t kind = 0;
    bool valid = false;
    bool defined = false;
    uint8_t format = 0;
    uint16_t width = 0;
    uint16_t height = 0;
    std::vector<uint8_t> bytes;
    std::vector<uint8_t> coverage;
    uint32_t sprite_leases = 0;
    uint32_t layer_leases = 0; // Enabled working consumers; map updates remain allowed.
    uint32_t read_leases = 0;  // Write veto; snapshot producers belong to PC6.
};
struct tkga_layer {
    bool atlas_bound = false, map_bound = false, enabled = false;
    uint16_t atlas = 0, map = 0, map_w = 0, map_h = 0;
    uint8_t tile_w = 0, tile_h = 0, priority = 0, palette = 0;
    uint16_t flags = 0;
    int32_t scroll_x = 0, scroll_y = 0;
};
struct tkga_sprite {
    bool defined = false, atlas_bound = false, enabled = false;
    uint16_t handle = 0, src_x = 0, src_y = 0, w = 0, h = 0, frame = 0;
    int32_t x = 0, y = 0;
    uint16_t flags = 0;
    uint8_t priority = 0, palette = 0, transparent_index = 0;
};
struct tkga_write {
    uint32_t offset;
    uint8_t value;
    uint32_t retire_step;
    uint64_t serial;
    uint64_t session=0,identity=0,token=0;
};
struct tkga_upload {
    uint8_t state = 0;
    uint16_t handle = 0;
    uint32_t offset = 0;
    uint32_t length = 0;
    uint32_t admitted = 0;
    uint32_t issued = 0;
    uint32_t crc = UINT32_C(0xffffffff);
    uint32_t expected_crc = 0;
    bool verify = false;
    bool abort = false;
    bool waiting_command = false;
    uint64_t data_base = 0;
    std::deque<uint8_t> queued;
    std::deque<tkga_write> outstanding;
};
struct tkga_packet {
    std::vector<uint8_t> bytes;
    uint64_t data_watermark = 0;
};
struct tkga_scene {
    uint16_t tag = 0, handle = 0;
    uint8_t role = 0, format = 0;
    uint16_t width = 0, height = 0;
    uint64_t sequence = 0;
    std::array<uint16_t, 3> bindings{};
    std::array<bool, 3> binding_valid{};
    std::vector<tkga_layer> layers;
    std::vector<tkga_sprite> sprites;
    std::vector<std::vector<uint32_t>> palettes;
    std::array<int64_t, 4> clip{};
    bool clip_enabled = false;
    std::set<uint16_t> handles;
    std::map<uint16_t, tkga_resource> resources;
    std::vector<uint8_t> indexed, rgb;
};
struct tkga_device {
    tkga_profile profile;
    uint64_t session=0,next_identity=1,next_job=1,boundary_session=0;
    bool reset_active=false,reset_detached=false,write_auto_ack=true;
    uint8_t reset_scope=0;
    uint16_t reset_upload_handle=0;
    std::deque<tkga_write> reset_writes;
    std::map<uint64_t,std::pair<uint64_t,uint64_t>> read_jobs;
    std::vector<std::unique_ptr<const tkga_scene>> retiring_scenes;
    uint64_t data_admitted = 0, data_retired = 0;
    bool fence_valid = false;
    uint16_t completed_fence = 0;
    std::unique_ptr<const tkga_scene> pending, published;
    uint64_t present_sequence = 0;
    bool frame_event = false, backend_ready = true;
    uint16_t last_presented = 0;
    uint8_t mode_active = 0, mode_pending_value = 0;
    bool mode_pending_valid = false, boundary_open = false;
    uint64_t boundary_present = 0;
    bool boundary_mode = false, boundary_ready = false;
    uint8_t boundary_mode_value = 0;
    uint8_t selected = 0;
    uint8_t cursor = 0;
    uint8_t write_cursor = 0;
    uint8_t ack_low = 0;
    uint8_t last_error = 0;
    uint16_t error_classes = 0;
    uint16_t cmd_used = 0;
    uint32_t discard_remaining = 0;
    std::vector<uint8_t> rx;
    std::deque<tkga_packet> commands;
    bool snapshot_valid = false;
    std::array<uint32_t, 256> snapshot{};
    int32_t clip_x = 0;
    int32_t clip_y = 0;
    uint32_t clip_w = 0;
    uint32_t clip_h = 0;
    bool clip_enabled = false;
    uint32_t step = 0;
    std::map<uint16_t, tkga_resource> resources;
    tkga_upload upload;
    std::array<uint16_t, 3> targets{};
    std::array<bool, 3> target_valid{};
    std::vector<tkga_layer> layers;
    std::vector<tkga_sprite> sprites;
    std::vector<std::vector<uint32_t>> palettes;
    explicit tkga_device(const tkga_profile &p)
        : profile(p), layers(p.max_layers), sprites(p.max_sprites),
          palettes(p.palette_banks, std::vector<uint32_t>(p.palette_entries, 0)) {}
};
uint8_t tkga_temporal_command(tkga_device &, const tkga_packet &);
bool tkga_serial_reached(uint16_t, uint16_t);
bool tkga_busy(const tkga_device &);
uint8_t tkga_ack(tkga_device &, uint16_t);
void tkga_mode_reset_begin(tkga_device &);
void tkga_mode_reset_complete(tkga_device &);
uint8_t tkga_reset_begin(tkga_device &,uint8_t);
void tkga_reset_tick(tkga_device &);
void tkga_retire_scenes(tkga_device &);
void tkga_finish_write(tkga_device &,uint16_t,const tkga_write &);
uint8_t tkga_ack_epoch(tkga_device &,uint64_t,uint16_t);
void tkga_error(tkga_device &device, uint8_t code);
void tkga_capture(tkga_device &device);
uint16_t tkga_u16(const std::vector<uint8_t> &bytes, unsigned offset);
uint32_t tkga_u32(const std::vector<uint8_t> &bytes, unsigned offset);
int32_t tkga_s16(const std::vector<uint8_t> &bytes, unsigned offset);
uint8_t tkga_resource_command(tkga_device &device, const std::vector<uint8_t> &bytes);
void tkga_upload_tick(tkga_device &device);
bool tkga_upload_active(const tkga_device &device);
uint8_t tkga_graphics_command(tkga_device &device, const std::vector<uint8_t> &bytes);
uint8_t tkga_layer_command(tkga_device &, const std::vector<uint8_t> &);
uint8_t tkga_pixel(const tkga_resource &, int64_t, int64_t);
void tkga_put(tkga_resource &, int64_t, int64_t, uint8_t);
uint8_t tkga_compose(const tkga_device &, const std::vector<tkga_layer> &, uint16_t,
                     std::vector<uint8_t> &, std::vector<uint8_t> &);
uint8_t tkga_sprite_command(tkga_device &, const std::vector<uint8_t> &);
uint8_t tkga_sprite_validate(const tkga_device &, const tkga_sprite &,
                             const tkga_resource * = nullptr);
std::vector<uint16_t> tkga_sprite_survivors(const tkga_profile &, const std::vector<tkga_sprite> &,
                                            uint16_t, uint16_t, uint16_t);
uint8_t tkga_scene_preflight(const tkga_device &, const std::vector<tkga_layer> &,
                            const std::vector<tkga_sprite> &, uint16_t);
uint8_t tkga_compose_scene(const tkga_device &, const std::vector<tkga_layer> &,
                           const std::vector<tkga_sprite> &, uint16_t, std::vector<uint8_t> &,
                           std::vector<uint8_t> &);
#endif
