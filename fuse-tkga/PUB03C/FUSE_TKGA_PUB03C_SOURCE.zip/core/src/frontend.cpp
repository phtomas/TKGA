#include "core_state.hpp"
#include <utility>

uint16_t tkga_u16(const std::vector<uint8_t> &b, unsigned o) {
    return static_cast<uint16_t>(static_cast<uint16_t>(b[o]) | (static_cast<uint16_t>(b[o+1]) << 8U));
}
uint32_t tkga_u32(const std::vector<uint8_t> &b, unsigned o) {
    return static_cast<uint32_t>(tkga_u16(b,o)) | (static_cast<uint32_t>(tkga_u16(b,o+2)) << 16U);
}
int32_t tkga_s16(const std::vector<uint8_t> &b, unsigned o) {
    const uint16_t raw = tkga_u16(b,o);
    return raw < 32768U ? static_cast<int32_t>(raw) : static_cast<int32_t>(raw) - 65536;
}
void tkga_error(tkga_device &d, uint8_t code) {
    constexpr uint8_t classes[] = {0,0,0,1,2,2,3,4,1,5,5,6};
    d.last_error = code;
    d.error_classes = static_cast<uint16_t>(d.error_classes | (1U << classes[code]));
}
void tkga_capture(tkga_device &d) {
    const uint16_t cmd_free = d.reset_active ? 0 : static_cast<uint16_t>(d.profile.cmd_capacity - d.cmd_used);
    const uint16_t data_free = d.reset_active ? 0 : static_cast<uint16_t>(d.profile.data_capacity-d.upload.queued.size());
    uint16_t status = d.reset_active ? 0 : 1;
    if (tkga_busy(d)) status |= 2;
    if (d.commands.empty()) status |= 4;
    if (d.frame_event) status |= 256;
    if (!d.upload.queued.empty() || !d.upload.outstanding.empty() || d.upload.state==2 || d.upload.state==3) status |= 2;
    if (tkga_upload_active(d)) status |= 128;
    if (!cmd_free) status |= 8;
    if (!data_free) status |= 16;
    if (d.error_classes) status |= 32;
    if (!d.rx.empty() || d.discard_remaining) status |= 64;
    d.snapshot.fill(0);
    d.snapshot[TKGA_REG_STATUS] = status;
    d.snapshot[TKGA_REG_CMD_FREE] = cmd_free;
    d.snapshot[TKGA_REG_DATA_FREE] = data_free;
    d.snapshot[TKGA_REG_LAST_ERROR_CODE] = d.last_error;
    d.snapshot[TKGA_REG_ERROR_CLASSES] = d.error_classes;
    d.snapshot[TKGA_REG_UPLOAD_STATE] = d.upload.state;
    d.snapshot[TKGA_REG_UPLOAD_HANDLE] = d.upload.handle;
    d.snapshot[TKGA_REG_UPLOAD_REMAINING] = tkga_upload_active(d) ? d.upload.length-d.upload.admitted : 0;
    d.snapshot[TKGA_REG_COMPLETED_FENCE]=d.completed_fence;
    d.snapshot[TKGA_REG_LAST_PRESENTED]=d.last_presented;
    d.snapshot[TKGA_REG_MODE_ACTIVE]=d.mode_active;
    d.snapshot_valid = true;
}
namespace {
int fixed_length(uint8_t opcode) {
    switch (opcode) {
    case 0x01: return 2; case 0x02: return 8; case 0x03: return 2;
    case 0x04: return 3; case 0x05: return 1; case 0x06: return 2;
    case 0x10: return 8; case 0x11: return 2; case 0x12: return 11;
    case 0x13: return 6; case 0x14: return 2; case 0x20: return -2;
    case 0x21: return 4; case 0x22: return 4; case 0x30: return 4;
    case 0x31: return 4; case 0x32: return 12; case 0x33: return 15;
    case 0x40: return 7; case 0x41: return 7; case 0x42: return 5;
    case 0x43: return 5; case 0x44: return 2; case 0x45: return -3;
    case 0x50: return 12; case 0x51: return 6; case 0x52: return 4;
    case 0x53: return 6; case 0x54: return 3; case 0x55: return 3;
    case 0x60: return 16; case 0x61: return 17; case 0x62: return 12;
    case 0x63: return 13; case 0x64: return 16;
    default: return -1;
    }
}
}
extern "C" {
uint8_t tkga_cmd_write8(tkga_device *device, uint8_t value) {
    if (!device) return TKGA_HOST_INVALID_ARGUMENT;
    auto &d = *device;
    if (d.reset_active || d.cmd_used == d.profile.cmd_capacity) {
        tkga_error(d,9); return TKGA_HOST_REJECTED;
    }
    if (d.discard_remaining) { --d.discard_remaining; return TKGA_HOST_OK; }
    d.rx.push_back(value); ++d.cmd_used;
    if (d.rx.size() >= 4) {
        const uint16_t length = tkga_u16(d.rx,2);
        if (length > d.profile.max_cmd_payload) {
            tkga_error(d,2);
            d.discard_remaining = length;
            d.cmd_used = static_cast<uint16_t>(d.cmd_used - d.rx.size());
            d.rx.clear();
        } else if (d.rx.size() == static_cast<unsigned>(length) + 4U) {
            d.commands.push_back({std::move(d.rx),d.data_admitted});
            d.rx.clear();
        }
    }
    return TKGA_HOST_OK;
}
uint8_t tkga_data_write8(tkga_device *device, uint8_t value) {
    if (!device) return TKGA_HOST_INVALID_ARGUMENT;
    auto &u=device->upload;
    if(device->reset_active || u.state!=1 || u.admitted==u.length || u.queued.size()==device->profile.data_capacity) {
        tkga_error(*device,10);return TKGA_HOST_REJECTED;
    }
    u.queued.push_back(value);++u.admitted;++device->data_admitted;
    u.crc^=value;
    for(unsigned i=0;i<8;++i) u.crc=(u.crc>>1U)^((u.crc&1U)?UINT32_C(0xedb88320):0U);
    return TKGA_HOST_OK;
}
uint8_t tkga_reg_write8(tkga_device *device, uint8_t value) {
    if (!device) return TKGA_HOST_INVALID_ARGUMENT;
    auto &d = *device;
    if (d.selected == TKGA_REG_RX_CANCEL && d.write_cursor == 0) {
        if (value & 0xfeU) { tkga_error(d,3); return TKGA_HOST_REJECTED; }
        ++d.write_cursor;
        if (value & 1U) {
            d.cmd_used = static_cast<uint16_t>(d.cmd_used - d.rx.size());
            d.rx.clear(); d.discard_remaining = 0;
        }
        return TKGA_HOST_OK;
    }
    if (d.selected == TKGA_REG_FRAME_ACK && d.write_cursor < 2) {
        if (d.write_cursor == 0) { d.ack_low = value; ++d.write_cursor; return TKGA_HOST_OK; }
        ++d.write_cursor;
        const auto tag=static_cast<uint16_t>(d.ack_low | (static_cast<uint16_t>(value)<<8U));
        return tkga_ack(d,tag) ? TKGA_HOST_REJECTED : TKGA_HOST_OK;
    }
    tkga_error(d,3); return TKGA_HOST_REJECTED;
}
uint8_t tkga_step(tkga_device *device) {
    if (!device) return TKGA_HOST_INVALID_ARGUMENT;
    auto &d = *device;
    if(d.reset_active) {tkga_reset_tick(d);++d.step;return TKGA_HOST_OK;}
    tkga_retire_scenes(d);
    const bool reset_at_head=!d.commands.empty() && d.commands.front().bytes.size()==5 &&
        d.commands.front().bytes[0]==5 && d.commands.front().bytes[1]==0 &&
        tkga_u16(d.commands.front().bytes,2)==1 && d.commands.front().bytes[4]<2;
    if(!reset_at_head) tkga_upload_tick(d);
    if (d.commands.empty()) { ++d.step; return TKGA_HOST_OK; }
    const auto &b = d.commands.front().bytes;
    uint8_t error = 0;
    const int expected = fixed_length(b[0]);
    const uint16_t length = tkga_u16(b,2);
    if (expected == -1) error = 1;
    else if (b[1]) error = 3;
    else if (expected >= 0 && length != expected) error = 2;
    else if (expected == -2 && (length < 3 || length != 3U + 3U * b[6])) error = 2;
    else if (expected == -3 && (length < 9 || !tkga_u16(b,9) || !tkga_u16(b,11) || length != 9U +
        static_cast<uint32_t>(tkga_u16(b,9)) * tkga_u16(b,11))) error = 2;
    if (error) tkga_error(d,error);
    else if (b[0] == TKGA_CMD_CLEAR_ERROR) {
        const uint16_t mask = tkga_u16(b,4);
        if (mask & 0xff80U) tkga_error(d,3);
        else {
            d.error_classes = static_cast<uint16_t>(d.error_classes & ~mask);
            if (!d.error_classes) d.last_error = 0;
        }
    } else if(b[0]==TKGA_CMD_ENGINE_RESET) {
        if(b[4]>1) tkga_error(d,3);
        else {const auto scope=b[4];const auto reset_error=tkga_reset_begin(d,scope);
            if(reset_error) tkga_error(d,reset_error);else {++d.step;return TKGA_HOST_OK;}}
    } else if (b[0] == TKGA_CMD_SET_GLOBAL_CLIP) {
        d.clip_x = tkga_s16(b,4); d.clip_y = tkga_s16(b,6);
        d.clip_w = tkga_u16(b,8); d.clip_h = tkga_u16(b,10); d.clip_enabled = true;
    } else {
        /* Preserve packet until a later gate implements its executor. No fake
           UNSUPPORTED wire failure for commands promised by the profile. */
        uint8_t result=tkga_temporal_command(d,d.commands.front());
        if(result==254) result=tkga_resource_command(d,b);
        if(result==254) result=tkga_graphics_command(d,b);
        if(result==254) result=tkga_layer_command(d,b);
        if(result==254) result=tkga_sprite_command(d,b);
        if(result==254) return TKGA_HOST_NOT_IMPLEMENTED;
        if(result==255) {++d.step;return TKGA_HOST_OK;}
        if(result) tkga_error(d,result);
        if(d.upload.waiting_command) d.upload.waiting_command=false;
    }
    d.cmd_used = static_cast<uint16_t>(d.cmd_used - b.size());
    d.commands.pop_front(); ++d.step;
    return TKGA_HOST_OK;
}
}
