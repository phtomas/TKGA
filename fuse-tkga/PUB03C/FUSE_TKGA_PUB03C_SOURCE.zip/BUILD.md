# Build Win32 da extensão

Consulte [REPRODUZIR](REPRODUZIR.md) para a sequência e dependências. tools/prepare.py aplica patches com **patch -p1** nesta ordem:

1. patches/fuse-tkga-dp01.patch, os 21 arquivos do DP01.
2. patches/fuse-pub03b-build-deps.patch, limpeza de três espelhos .txt.
3. patches/fuse-pub03c-modification-notices.patch, avisos por arquivo. A terceira etapa preserva o código efetivo e os avisos upstream.

VERIFICACAO_COMBINACAO.json encadeia a saída dos 21 arquivos antes e depois das sobreposições. O preparador preserva os nove arquivos gerados do tarball fora da árvore ativa. Autotools, Perl, os geradores Win32 e os geradores de opcodes refazem os produtos necessários. O teste mantém as fontes upstream intactas no tarball e exclui membros .rom/.sna/.z80 da extração.

O alvo z80/coretest.exe lê z80/tests/tests.in do Fuse extraído. Compare sua saída com z80/tests/tests.expected, normalizando apenas CRLF para LF; o arquivo bruto permanece uma evidência separada. Classic, Hello e FirstFrame exercitam a mesma aplicação recém-compilada. Os snapshots de teste são gerados dos exemplos ASM desta seleção e ficam na pasta de teste. O script de montagem mantém os executáveis e runtimes no diretório de trabalho.
