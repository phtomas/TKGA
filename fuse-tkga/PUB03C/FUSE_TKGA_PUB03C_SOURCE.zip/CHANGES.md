# Alterações

- PUB03C, 16/11/2026. Revisão de fontes com copyleft, avisos de alterações por arquivo, Core por 12 SHA e reprodução a partir dos pacotes upstream oficiais. Removidos os espelhos documentais .txt da dependência de build.
- DP01. Extensão experimental de transporte e render em Win32 dependente do Core PC10. Hello e FirstFrame saem das fontes da linha de exemplos DP01. ROM e snapshots ficam fora da seleção.
